
  # PROTOTYPE ARSAA V1

  This is a code bundle for PROTOTYPE ARSAA V1. The original project is available at https://www.figma.com/design/XmtTFvvxHsKvukvb8Lmj0R/PROTOTYPE-ARSAA-V1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  