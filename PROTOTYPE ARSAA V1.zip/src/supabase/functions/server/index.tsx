import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Property database for AI to reference
const PROPERTY_DATABASE = [
  {
    id: "prop_001",
    name: "Premium Villa Serpong",
    location: "BSD City, Tangerang Selatan",
    price: 4800000000,
    type: "Villa",
    bedrooms: 4,
    bathrooms: 3,
    area: 250,
    landSize: 400,
    features: ["Private Pool", "Garden", "Garage", "Security"],
    roi: 12.5,
    yearBuilt: 2020,
    description: "Luxury villa with modern design in prestigious BSD City"
  },
  {
    id: "prop_002", 
    name: "Smart Home BSD",
    location: "BSD City, Tangerang Selatan",
    price: 4200000000,
    type: "House",
    bedrooms: 3,
    bathrooms: 2,
    area: 180,
    landSize: 200,
    features: ["Smart Home System", "Solar Panel", "EV Charging"],
    roi: 11.8,
    yearBuilt: 2021,
    description: "Eco-friendly smart home with advanced automation"
  },
  {
    id: "prop_003",
    name: "Garden Residence",
    location: "Alam Sutera, Tangerang Selatan",
    price: 3900000000,
    type: "House",
    bedrooms: 3,
    bathrooms: 2,
    area: 170,
    landSize: 180,
    features: ["Garden View", "Club House", "Swimming Pool"],
    roi: 13.2,
    yearBuilt: 2019,
    description: "Peaceful residence with beautiful garden surroundings"
  },
  {
    id: "prop_004",
    name: "SCBD Luxury Apartment",
    location: "SCBD, Jakarta Selatan",
    price: 8500000000,
    type: "Apartment",
    bedrooms: 2,
    bathrooms: 2,
    area: 120,
    features: ["City View", "Gym", "Concierge", "Sky Garden"],
    roi: 15.7,
    yearBuilt: 2022,
    description: "Premium apartment in Jakarta's business district"
  },
  {
    id: "prop_005",
    name: "Kemang Modern House",
    location: "Kemang, Jakarta Selatan",
    price: 6800000000,
    type: "House",
    bedrooms: 4,
    bathrooms: 3,
    area: 200,
    landSize: 250,
    features: ["Modern Design", "Rooftop", "Parking"],
    roi: 14.3,
    yearBuilt: 2020,
    description: "Contemporary house in trendy Kemang area"
  }
];

// Market data for AI analysis
const MARKET_DATA = {
  "BSD City": {
    avgGrowth: 12.5,
    demand: "High",
    infrastructure: "Excellent",
    futureProjects: ["MRT Extension", "New Shopping Mall"],
    priceRange: { min: 3000000000, max: 8000000000 }
  },
  "Alam Sutera": {
    avgGrowth: 13.2,
    demand: "Very High", 
    infrastructure: "Good",
    futureProjects: ["Business District Expansion"],
    priceRange: { min: 2500000000, max: 6000000000 }
  },
  "SCBD": {
    avgGrowth: 15.7,
    demand: "Premium",
    infrastructure: "World Class",
    futureProjects: ["New Office Towers", "Transit Hub"],
    priceRange: { min: 5000000000, max: 15000000000 }
  },
  "Kemang": {
    avgGrowth: 14.3,
    demand: "High",
    infrastructure: "Good",
    futureProjects: ["Road Improvements", "Cultural District"],
    priceRange: { min: 4000000000, max: 10000000000 }
  }
};

// Advanced AI Chat endpoint with OpenAI integration
app.post("/make-server-58f5cb12/ai-chat", async (c) => {
  try {
    const { message, chatHistory = [] } = await c.req.json();
    
    if (!message) {
      return c.json({ error: "Message is required" }, 400);
    }

    console.log(`AI Chat request: ${message}`);

    // Enhanced property search based on user query
    const searchResults = searchProperties(message);
    const marketInsights = getMarketInsights(message);
    
    // Generate contextual AI response
    const aiResponse = await generateAIResponse(message, searchResults, marketInsights, chatHistory);
    
    // Store chat history in KV store
    const timestamp = new Date().toISOString();
    await kv.set(`chat_${timestamp}`, {
      message,
      response: aiResponse,
      timestamp,
      searchResults,
      marketInsights
    });

    return c.json({
      response: aiResponse,
      searchResults,
      marketInsights,
      timestamp: new Date().toLocaleTimeString()
    });

  } catch (error) {
    console.error("AI Chat error:", error);
    return c.json({ 
      error: "Failed to process AI request",
      details: error.message 
    }, 500);
  }
});

// Advanced property search function
function searchProperties(query) {
  const queryLower = query.toLowerCase();
  const results = [];

  // Extract search criteria from natural language
  const priceMatch = query.match(/under\s+(\d+\.?\d*)([bmk])?/i);
  const locationMatch = query.match(/(bsd|alam sutera|scbd|kemang|jakarta|tangerang)/i);
  const typeMatch = query.match(/(villa|house|apartment|luxury)/i);
  const bedroomMatch = query.match(/(\d+)\s+bedroom/i);

  let maxPrice = Infinity;
  if (priceMatch) {
    let price = parseFloat(priceMatch[1]);
    const unit = priceMatch[2]?.toLowerCase();
    if (unit === 'b') price *= 1000000000;
    else if (unit === 'm') price *= 1000000;
    else if (unit === 'k') price *= 1000;
    maxPrice = price;
  }

  for (const property of PROPERTY_DATABASE) {
    let score = 0;

    // Price filter
    if (property.price <= maxPrice) score += 30;

    // Location matching
    if (locationMatch && property.location.toLowerCase().includes(locationMatch[1])) {
      score += 40;
    }

    // Type matching
    if (typeMatch && property.type.toLowerCase().includes(typeMatch[1])) {
      score += 20;
    }

    // Bedroom matching
    if (bedroomMatch && property.bedrooms >= parseInt(bedroomMatch[1])) {
      score += 10;
    }

    // General relevance
    if (queryLower.includes('luxury') && property.price > 5000000000) score += 15;
    if (queryLower.includes('investment') && property.roi > 12) score += 15;

    if (score > 0) {
      results.push({ ...property, relevanceScore: score });
    }
  }

  return results
    .sort((a, b) => b.relevanceScore - a.relevanceScore)
    .slice(0, 5);
}

// Market insights function
function getMarketInsights(query) {
  const insights = [];
  const queryLower = query.toLowerCase();

  for (const [area, data] of Object.entries(MARKET_DATA)) {
    if (queryLower.includes(area.toLowerCase())) {
      insights.push({
        area,
        growth: data.avgGrowth,
        demand: data.demand,
        infrastructure: data.infrastructure,
        futureProjects: data.futureProjects,
        priceRange: data.priceRange
      });
    }
  }

  // If no specific area mentioned, provide general insights
  if (insights.length === 0 && (queryLower.includes('invest') || queryLower.includes('roi'))) {
    const topAreas = Object.entries(MARKET_DATA)
      .sort(([,a], [,b]) => b.avgGrowth - a.avgGrowth)
      .slice(0, 3);
    
    for (const [area, data] of topAreas) {
      insights.push({
        area,
        growth: data.avgGrowth,
        demand: data.demand,
        recommendation: "High growth potential"
      });
    }
  }

  return insights;
}

// Generate AI response using OpenAI or fallback to smart responses
async function generateAIResponse(message, searchResults, marketInsights, chatHistory) {
  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  
  if (openaiKey) {
    try {
      const systemPrompt = `You are ARSAN, an advanced AI property navigator for ARSAA DIMENSION, specializing in South Tangerang and Jakarta real estate. You provide personalized property recommendations, market analysis, and investment insights. 

Context:
- Search Results: ${JSON.stringify(searchResults)}
- Market Insights: ${JSON.stringify(marketInsights)}
- Chat History: ${JSON.stringify(chatHistory.slice(-3))}

Respond professionally with specific data, ROI analysis, and actionable recommendations. Keep responses conversational but informative.`;

      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${openaiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: message }
          ],
          max_tokens: 300,
          temperature: 0.7
        })
      });

      if (response.ok) {
        const data = await response.json();
        return data.choices[0].message.content;
      }
    } catch (error) {
      console.error("OpenAI API error:", error);
    }
  }

  // Fallback to intelligent response generation
  return generateSmartResponse(message, searchResults, marketInsights);
}

// Smart fallback response generator
function generateSmartResponse(message, searchResults, marketInsights) {
  const messageLower = message.toLowerCase();
  
  if (searchResults.length > 0) {
    const topProperty = searchResults[0];
    const formattedPrice = (topProperty.price / 1000000000).toFixed(1);
    
    return `Based on your criteria, I found ${searchResults.length} matching properties. The top recommendation is **${topProperty.name}** in ${topProperty.location} for Rp ${formattedPrice}B with ${topProperty.roi}% projected ROI. This ${topProperty.type.toLowerCase()} features ${topProperty.features.slice(0,2).join(', ')} and shows strong investment potential. Would you like detailed analysis on any specific property?`;
  }

  if (marketInsights.length > 0) {
    const topInsight = marketInsights[0];
    return `${topInsight.area} shows excellent investment potential with ${topInsight.growth}% average annual growth. The area has ${topInsight.demand.toLowerCase()} demand and ${topInsight.infrastructure.toLowerCase()} infrastructure. ${topInsight.futureProjects ? `Upcoming projects include ${topInsight.futureProjects.slice(0,2).join(' and ')}.` : ''} I can provide specific property recommendations in this area.`;
  }

  // General AI responses
  if (messageLower.includes('hello') || messageLower.includes('hi')) {
    return "Hello! I'm ARSAN, your AI property navigator. I can help you find properties, analyze investment opportunities, and provide market insights for South Tangerang and Jakarta areas. What kind of property are you looking for?";
  }

  if (messageLower.includes('thank')) {
    return "You're welcome! I'm here to help you navigate the property market with data-driven insights. Feel free to ask about specific locations, investment analysis, or property recommendations.";
  }

  return "I understand you're interested in property information. I can help with property searches, market analysis, ROI calculations, and investment recommendations for South Tangerang and Jakarta. Could you provide more specific details about what you're looking for?";
}

// Property recommendations endpoint
app.get("/make-server-58f5cb12/recommendations", async (c) => {
  try {
    const budget = c.req.query("budget");
    const location = c.req.query("location");
    const type = c.req.query("type");

    let filtered = PROPERTY_DATABASE;

    if (budget) {
      filtered = filtered.filter(p => p.price <= parseInt(budget));
    }
    if (location) {
      filtered = filtered.filter(p => p.location.toLowerCase().includes(location.toLowerCase()));
    }
    if (type) {
      filtered = filtered.filter(p => p.type.toLowerCase() === type.toLowerCase());
    }

    // Sort by ROI descending
    filtered.sort((a, b) => b.roi - a.roi);

    return c.json({
      recommendations: filtered.slice(0, 6),
      total: filtered.length,
      criteria: { budget, location, type }
    });

  } catch (error) {
    console.error("Recommendations error:", error);
    return c.json({ error: "Failed to get recommendations" }, 500);
  }
});

// Market analysis endpoint
app.get("/make-server-58f5cb12/market-analysis/:area", async (c) => {
  try {
    const area = c.req.param("area");
    const marketData = MARKET_DATA[area];

    if (!marketData) {
      return c.json({ error: "Area not found" }, 404);
    }

    // Get properties in this area
    const areaProperties = PROPERTY_DATABASE.filter(p => 
      p.location.toLowerCase().includes(area.toLowerCase())
    );

    const analysis = {
      area,
      marketData,
      properties: areaProperties,
      avgPrice: areaProperties.reduce((sum, p) => sum + p.price, 0) / areaProperties.length,
      avgROI: areaProperties.reduce((sum, p) => sum + p.roi, 0) / areaProperties.length,
      totalProperties: areaProperties.length
    };

    return c.json(analysis);

  } catch (error) {
    console.error("Market analysis error:", error);
    return c.json({ error: "Failed to analyze market" }, 500);
  }
});

// Health check endpoint
app.get("/make-server-58f5cb12/health", (c) => {
  return c.json({ 
    status: "ok",
    ai: "enabled",
    database: "connected",
    features: ["chat", "search", "recommendations", "market-analysis"]
  });
});

Deno.serve(app.fetch);