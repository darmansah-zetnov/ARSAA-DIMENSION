import React from "react";
import { motion } from "motion/react";
import { MapPin, Bed, Bath, Square, Eye } from "lucide-react";

const SAMPLE_PROPERTIES = [
  {
    id: "1",
    title: "Premium Villa Serpong",
    location: "BSD City, Tangerang Selatan",
    price: "Rp 4.8B",
    beds: 5,
    baths: 4,
    sqft: "420m²",
    type: "Villa",
    featured: true,
  },
  {
    id: "2",
    title: "Luxury Apartment Alam Sutera",
    location: "Alam Sutera, Tangerang Selatan",
    price: "Rp 2.9B",
    beds: 3,
    baths: 2,
    sqft: "145m²",
    type: "Apartment",
  },
  {
    id: "3",
    title: "Smart Home BSD City",
    location: "BSD City, Tangerang Selatan",
    price: "Rp 5.2B",
    beds: 4,
    baths: 3,
    sqft: "380m²",
    type: "House",
    featured: true,
  },
  {
    id: "4",
    title: "Executive Penthouse SCBD",
    location: "SCBD, Jakarta Selatan",
    price: "Rp 12.5B",
    beds: 4,
    baths: 4,
    sqft: "285m²",
    type: "Penthouse",
  },
];

export default function SimplePropertyShowcase() {
  return (
    <section className="py-20 px-6 relative">
      {/* Simple Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0D00FF]/2 to-transparent" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-4xl md:text-5xl font-bold">
            Featured Properties
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            Prime real estate opportunities in South Tangerang and Jakarta
          </p>
        </motion.div>

        {/* Properties Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SAMPLE_PROPERTIES.map((property, index) => (
            <motion.div
              key={property.id}
              className="relative rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300 overflow-hidden group"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              {/* Property Image Placeholder */}
              <div className="relative h-48 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-[#0D00FF]/20 flex items-center justify-center">
                    <Eye className="w-8 h-8 text-[#0D00FF]" />
                  </div>
                  <p className="text-gray-400 text-sm">AR View Available</p>
                </div>
                
                {/* Featured Badge */}
                {property.featured && (
                  <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-[#0D00FF]/20 border border-[#0D00FF]/50 text-[#0D00FF] text-sm font-medium">
                    Featured
                  </div>
                )}
              </div>

              {/* Property Details */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-[#0D00FF] transition-colors duration-300">
                      {property.title}
                    </h3>
                    <div className="flex items-center gap-2 text-gray-400 mb-3">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{property.location}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent">
                      {property.price}
                    </div>
                    <div className="text-sm text-gray-400">{property.type}</div>
                  </div>
                </div>

                {/* Property Stats */}
                <div className="flex items-center gap-6 text-sm text-gray-400 mb-4">
                  <div className="flex items-center gap-1">
                    <Bed className="w-4 h-4" />
                    <span>{property.beds}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Bath className="w-4 h-4" />
                    <span>{property.baths}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Square className="w-4 h-4" />
                    <span>{property.sqft}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <button className="flex-1 py-2 px-4 rounded-xl bg-[#0D00FF]/20 text-[#0D00FF] hover:bg-[#0D00FF]/30 transition-all duration-300 text-sm font-medium">
                    View in AR
                  </button>
                  <button className="flex-1 py-2 px-4 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300 text-sm font-medium">
                    Details
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All Button */}
        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <button className="px-8 py-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 hover:border-[#0D00FF]/50 transition-all duration-300 font-medium">
            View All Properties
          </button>
        </motion.div>
      </div>
    </section>
  );
}