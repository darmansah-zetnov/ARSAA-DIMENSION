import React from "react";
import { motion } from "motion/react";
import { TrendingUp, Users, Building, Globe, DollarSign, BarChart3 } from "lucide-react";

const METRICS_DATA = [
  {
    title: "Total Asset Value",
    value: "Rp 2.8T",
    change: "+24.3%",
    trend: "up",
    icon: DollarSign,
    description: "Combined property portfolio value",
  },
  {
    title: "Active Users",
    value: "45,200+",
    change: "+18.7%",
    trend: "up",
    icon: Users,
    description: "Verified investors and buyers",
  },
  {
    title: "Properties Listed",
    value: "1,850",
    change: "+12.4%",
    trend: "up",
    icon: Building,
    description: "Premium properties in portfolio",
  },
  {
    title: "Market Coverage",
    value: "8 Districts",
    change: "+2 new",
    trend: "up",
    icon: Globe,
    description: "Jakarta & South Tangerang focus",
  },
  {
    title: "Average ROI",
    value: "14.2%",
    change: "+2.1%",
    trend: "up",
    icon: TrendingUp,
    description: "Annual return on investment",
  },
  {
    title: "Transaction Volume",
    value: "Rp 125B",
    change: "+31.8%",
    trend: "up",
    icon: BarChart3,
    description: "Monthly transaction value",
  },
];

export default function InvestorMetrics() {
  return (
    <section className="py-16 px-6 relative">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0D00FF]/5 via-transparent to-[#0D00FF]/5" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2
            className="text-3xl sm:text-4xl lg:text-5xl text-display mb-6 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent"
          >
            Market Performance
          </motion.h2>
          
          <motion.p
            className="text-gray-300 max-w-3xl mx-auto text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            Real-time analytics from Indonesia's fastest-growing proptech platform
          </motion.p>
        </motion.div>

        {/* Metrics Grid */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {METRICS_DATA.map((metric, index) => (
            <motion.div
              key={metric.title}
              className="relative p-6 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300 group overflow-hidden"
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.02, y: -5 }}
            >
              {/* Background Glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#0D00FF]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              {/* Animated Border */}
              <motion.div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  background: `conic-gradient(from 0deg, transparent, rgba(13, 0, 255, 0.3), transparent)`,
                  padding: "1px",
                }}
                animate={{ rotate: 360 }}
                transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
              />

              <div className="relative z-10">
                {/* Icon and Trend */}
                <div className="flex items-center justify-between mb-4">
                  <motion.div
                    className="w-12 h-12 rounded-xl bg-[#0D00FF]/20 group-hover:bg-[#0D00FF]/30 flex items-center justify-center transition-all duration-300"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    <metric.icon className="w-6 h-6 text-[#0D00FF] group-hover:text-white transition-colors duration-300" />
                  </motion.div>
                  
                  <motion.div
                    className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-semibold ${
                      metric.trend === 'up' 
                        ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                        : 'bg-red-500/20 text-red-400 border border-red-500/30'
                    }`}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.1 + 0.5 }}
                  >
                    <TrendingUp className="w-3 h-3" />
                    {metric.change}
                  </motion.div>
                </div>

                {/* Value */}
                <motion.div
                  className="mb-2"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                >
                  <h3 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent">
                    {metric.value}
                  </h3>
                </motion.div>

                {/* Title */}
                <motion.h4
                  className="font-semibold text-white mb-2 group-hover:text-[#0D00FF] transition-colors duration-300"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 + 0.4 }}
                >
                  {metric.title}
                </motion.h4>

                {/* Description */}
                <motion.p
                  className="text-gray-400 text-sm group-hover:text-gray-300 transition-colors duration-300"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 + 0.5 }}
                >
                  {metric.description}
                </motion.p>

                {/* Progress Indicator */}
                <motion.div
                  className="mt-4 h-1 bg-white/10 rounded-full overflow-hidden"
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 1, delay: index * 0.1 + 0.8 }}
                >
                  <motion.div
                    className="h-full bg-gradient-to-r from-[#0D00FF] to-blue-400"
                    initial={{ width: "0%" }}
                    animate={{ width: "85%" }}
                    transition={{ duration: 1.5, delay: index * 0.1 + 1 }}
                  />
                </motion.div>
              </div>

              {/* Corner Accent */}
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-[#0D00FF]/10 to-transparent rounded-tr-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </motion.div>
          ))}
        </motion.div>

        {/* Additional Insights */}
        <motion.div
          className="mt-12 p-8 rounded-3xl bg-gradient-to-r from-[#0D00FF]/10 via-white/5 to-[#0D00FF]/10 backdrop-blur-md border border-white/20"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <div className="text-center">
            <h3 className="text-xl font-semibold text-white mb-4">
              Institutional Investment Opportunity
            </h3>
            <p className="text-gray-300 max-w-4xl mx-auto leading-relaxed">
              ARSAA DIMENSION represents a unique opportunity to invest in Indonesia's rapidly growing proptech sector. 
              With South Tangerang experiencing 15.8% annual property value growth and Jakarta maintaining its position 
              as Southeast Asia's financial hub, our platform is positioned to capture significant market share in the 
              $47B Indonesian real estate market.
            </p>
            
            <motion.div
              className="flex flex-wrap justify-center gap-8 mt-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              {[
                "Series A: $25M Target",
                "Projected 5x ROI",
                "200% User Growth",
                "Regional Expansion Ready"
              ].map((item, index) => (
                <motion.div
                  key={item}
                  className="px-4 py-2 rounded-full bg-white/10 border border-[#0D00FF]/30 text-[#0D00FF] font-semibold text-sm"
                  whileHover={{ scale: 1.05, y: -2 }}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 1 + index * 0.1 }}
                >
                  {item}
                </motion.div>
              ))}
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}