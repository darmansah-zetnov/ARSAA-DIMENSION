import React from "react";
import { motion } from "motion/react";
import ARSAALogo from "./ARSAALogo";

export default function LogoShowcase() {
  return (
    <section className="py-20 px-6 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0D00FF]/3 to-transparent" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex justify-center mb-6">
            <ARSAALogo size="xl" variant="animated" showText={true} />
          </div>
          <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-3xl md:text-4xl font-bold">
            Clean Logo Branding
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            Clean white logo design optimized for professional presentation and brand consistency.
          </p>
        </motion.div>

        {/* Logo Variations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {/* Default Logo */}
          <motion.div
            className="p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            whileHover={{ y: -5 }}
          >
            <div className="flex justify-center mb-4">
              <ARSAALogo size="lg" variant="default" showText={true} />
            </div>
            <h3 className="text-white font-semibold mb-2">Clean Default</h3>
            <p className="text-gray-400 text-sm">Pure white logo, no background</p>
          </motion.div>

          {/* Glow Effect */}
          <motion.div
            className="p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            whileHover={{ y: -5 }}
          >
            <div className="flex justify-center mb-4">
              <ARSAALogo size="lg" variant="glow" showText={true} />
            </div>
            <h3 className="text-white font-semibold mb-2">Subtle Glow</h3>
            <p className="text-gray-400 text-sm">Enhanced with neon accent</p>
          </motion.div>

          {/* Animated */}
          <motion.div
            className="p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            whileHover={{ y: -5 }}
          >
            <div className="flex justify-center mb-4">
              <ARSAALogo size="lg" variant="animated" showText={true} />
            </div>
            <h3 className="text-white font-semibold mb-2">Clean Animated</h3>
            <p className="text-gray-400 text-sm">Smooth motion effects</p>
          </motion.div>

          {/* Minimal Icon Only */}
          <motion.div
            className="p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            whileHover={{ y: -5 }}
          >
            <div className="flex justify-center mb-4">
              <ARSAALogo size="lg" variant="minimal" showText={false} />
            </div>
            <h3 className="text-white font-semibold mb-2">Minimal Icon</h3>
            <p className="text-gray-400 text-sm">Ultra-clean, icon only</p>
          </motion.div>
        </div>

        {/* Size Variations */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <h3 className="text-2xl font-bold text-white mb-8">Size Variations</h3>
          <div className="flex flex-wrap justify-center items-end gap-8 p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
            <div className="text-center">
              <ARSAALogo size="sm" variant="glow" showText={true} />
              <p className="text-gray-400 text-xs mt-2">Small</p>
            </div>
            <div className="text-center">
              <ARSAALogo size="md" variant="glow" showText={true} />
              <p className="text-gray-400 text-xs mt-2">Medium</p>
            </div>
            <div className="text-center">
              <ARSAALogo size="lg" variant="glow" showText={true} />
              <p className="text-gray-400 text-xs mt-2">Large</p>
            </div>
            <div className="text-center">
              <ARSAALogo size="xl" variant="glow" showText={true} />
              <p className="text-gray-400 text-xs mt-2">Extra Large</p>
            </div>
          </div>
        </motion.div>

        {/* Brand Guidelines */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-4 gap-6"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-white" />
              Logo
            </h4>
            <p className="text-gray-400 text-sm mb-2">Clean White Design</p>
            <p className="text-gray-500 text-xs">Pure white logo with transparent background</p>
          </div>

          <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-[#0D00FF]" />
              Accent Color
            </h4>
            <p className="text-gray-400 text-sm mb-2">Neon Blue #0D00FF</p>
            <p className="text-gray-500 text-xs">For interactive elements and highlights</p>
          </div>

          <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-[#0B0C10] border border-white/20" />
              Background
            </h4>
            <p className="text-gray-400 text-sm mb-2">Dark #0B0C10</p>
            <p className="text-gray-500 text-xs">Primary background for contrast</p>
          </div>

          <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-gradient-to-r from-transparent to-white/10 border border-white/10" />
              Effects
            </h4>
            <p className="text-gray-400 text-sm mb-2">Minimal Enhancements</p>
            <p className="text-gray-500 text-xs">Subtle glows and clean animations</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}