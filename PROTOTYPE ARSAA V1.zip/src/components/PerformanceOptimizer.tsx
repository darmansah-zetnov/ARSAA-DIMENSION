import { useEffect } from 'react';

export default function PerformanceOptimizer() {
  useEffect(() => {
    // Detect device capabilities
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    const isLowEnd = navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4;
    const hasSlowConnection = navigator.connection && (navigator.connection as any).effectiveType === '2g';
    
    // Apply performance optimizations
    const optimizations = {
      // Reduce animation complexity on mobile
      reducedMotion: isMobile || isLowEnd || hasSlowConnection,
      
      // Optimize canvas rendering
      canvasScale: isMobile ? 0.75 : 1,
      
      // Throttle scroll events
      scrollThrottle: isMobile ? 100 : 16,
      
      // Lazy load images
      lazyLoading: true,
      
      // Reduce particle count
      particleCount: isMobile ? 30 : isLowEnd ? 50 : 80,
    };

    // Store optimizations in global object for components to use
    (window as any).__ARSAA_OPTIMIZATIONS = optimizations;

    // Add meta viewport for mobile optimization
    if (isMobile) {
      let viewport = document.querySelector('meta[name="viewport"]');
      if (!viewport) {
        viewport = document.createElement('meta');
        viewport.setAttribute('name', 'viewport');
        document.head.appendChild(viewport);
      }
      viewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
    }

    // Preload critical fonts
    const fontPreload = document.createElement('link');
    fontPreload.rel = 'preload';
    fontPreload.as = 'font';
    fontPreload.type = 'font/woff2';
    fontPreload.crossOrigin = 'anonymous';
    document.head.appendChild(fontPreload);

    // Add passive event listeners for better scrolling performance
    const style = document.createElement('style');
    style.textContent = `
      * {
        scroll-behavior: smooth;
      }
      
      @media (prefers-reduced-motion: reduce) {
        * {
          animation-duration: 0.01ms !important;
          animation-iteration-count: 1 !important;
          transition-duration: 0.01ms !important;
          scroll-behavior: auto !important;
        }
      }
      
      /* Mobile-specific optimizations */
      @media (max-width: 768px) {
        .transform-gpu {
          transform: translateZ(0);
          will-change: transform;
        }
        
        /* Reduce blur effects on mobile for performance */
        .backdrop-blur-xl {
          backdrop-filter: blur(8px);
        }
        
        .backdrop-blur-md {
          backdrop-filter: blur(4px);
        }
        
        /* Optimize shadows for mobile */
        .shadow-lg {
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
      }
      
      /* High-performance mode for low-end devices */
      @media (max-width: 768px) and (max-device-pixel-ratio: 1.5) {
        .complex-animation {
          animation: none !important;
        }
        
        .backdrop-blur-xl,
        .backdrop-blur-md {
          backdrop-filter: none;
          background: rgba(0, 0, 0, 0.8);
        }
      }
      
      /* iOS Safari optimizations */
      @supports (-webkit-touch-callout: none) {
        .ios-fix {
          -webkit-transform: translateZ(0);
          -webkit-perspective: 1000;
          -webkit-backface-visibility: hidden;
        }
      }
    `;
    document.head.appendChild(style);

    // Intersection Observer for lazy loading
    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      }, {
        rootMargin: '50px',
        threshold: 0.1
      });

      // Observe all lazy-load elements
      document.querySelectorAll('[data-lazy]').forEach((el) => {
        observer.observe(el);
      });
    }

    // Memory management for mobile
    if (isMobile) {
      let memoryWarning = false;
      
      // Monitor memory usage
      const checkMemory = () => {
        if ((performance as any).memory) {
          const memInfo = (performance as any).memory;
          const memoryUsage = memInfo.usedJSHeapSize / memInfo.jsHeapSizeLimit;
          
          if (memoryUsage > 0.8 && !memoryWarning) {
            memoryWarning = true;
            // Reduce quality for memory-constrained devices
            document.body.classList.add('low-memory-mode');
          }
        }
      };

      setInterval(checkMemory, 5000);
    }

    // Cleanup function
    return () => {
      // Clean up any intervals or observers if needed
    };
  }, []);

  return null; // This component doesn't render anything
}