import React, { useEffect, useRef, useState } from "react";
import { motion } from "motion/react";

const PARTNERS = [
  { name: "PropTech Indonesia", logo: "PTI" },
  { name: "Blockchain Realty", logo: "BCR" },
  { name: "AR Solutions Asia", logo: "ASA" },
  { name: "Smart Estates ID", logo: "SEI" },
  { name: "Future Homes", logo: "FH" },
  { name: "MetaProperty", logo: "MP" },
];

const STATS = [
  { label: "Properti Terdaftar", value: 50000, suffix: "+" },
  { label: "Klien Puas", value: 25000, suffix: "+" },
  { label: "Pengalaman AR", value: 1000000, suffix: "+" },
  { label: "Transaksi Sukses", value: 15000, suffix: "+" },
];

export default function PartnersSection() {
  const [animatedStats, setAnimatedStats] = useState(STATS.map(() => 0));
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true);
          // Animate numbers
          STATS.forEach((stat, index) => {
            let current = 0;
            const increment = stat.value / 100;
            const timer = setInterval(() => {
              current += increment;
              if (current >= stat.value) {
                current = stat.value;
                clearInterval(timer);
              }
              setAnimatedStats(prev => {
                const newStats = [...prev];
                newStats[index] = Math.floor(current);
                return newStats;
              });
            }, 20);
          });
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, [isVisible]);

  return (
    <section ref={sectionRef} className="py-20 px-6 relative">
      {/* Background Glow */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#0D00FF]/5 to-transparent" />
      
      <div className="max-w-7xl mx-auto">
        {/* Stats Section */}
        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {STATS.map((stat, index) => (
            <motion.div
              key={stat.label}
              className="text-center p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300 group"
              whileHover={{ scale: 1.05, y: -5 }}
            >
              <div className="relative">
                {/* Glow Effect */}
                <div className="absolute inset-0 bg-[#0D00FF]/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                <motion.div
                  className="relative z-10 mb-2"
                  style={{ fontSize: "2.5rem", fontWeight: "bold" }}
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <span className="bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent">
                    {animatedStats[index].toLocaleString()}{stat.suffix}
                  </span>
                </motion.div>
                
                <p className="text-gray-400 group-hover:text-white transition-colors duration-300">
                  {stat.label}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Trusted By Section */}
        <div className="text-center mb-12">
          <motion.h2
            className="mb-12 text-gray-400"
            style={{ fontSize: "1.5rem" }}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            Dipercaya oleh Partner Terdepan
          </motion.h2>
        </div>

        {/* Partners Grid */}
        <motion.div
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, staggerChildren: 0.1 }}
        >
          {PARTNERS.map((partner, index) => (
            <motion.div
              key={partner.name}
              className="group cursor-pointer"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ scale: 1.1, y: -10 }}
            >
              <div className="relative p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 group-hover:border-[#0D00FF]/70 transition-all duration-300 text-center">
                {/* Hover Glow */}
                <div className="absolute inset-0 rounded-2xl shadow-[0_0_30px_rgba(13,0,255,0.3)] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Logo */}
                <div className="relative z-10 mb-4">
                  <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-gray-600 to-gray-800 group-hover:from-[#0D00FF] group-hover:to-[#0D00FF]/70 flex items-center justify-center transition-all duration-300">
                    <span 
                      className="text-white group-hover:text-white/90"
                      style={{ fontWeight: "bold" }}
                    >
                      {partner.logo}
                    </span>
                  </div>
                </div>

                {/* Company Name */}
                <p 
                  className="text-gray-400 group-hover:text-white transition-colors duration-300"
                  style={{ fontSize: "0.9rem" }}
                >
                  {partner.name}
                </p>

                {/* Neon Glow Ring */}
                <div className="absolute inset-0 rounded-2xl ring-1 ring-transparent group-hover:ring-[#0D00FF]/50 transition-all duration-300" />
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Floating Particles */}
        <div className="absolute top-1/2 left-10 w-4 h-4 rounded-full bg-[#0D00FF]/30 animate-bounce" />
        <div className="absolute top-1/4 right-10 w-3 h-3 rounded-full bg-[#0D00FF]/40 animate-pulse" />
        <div className="absolute bottom-1/4 left-1/4 w-5 h-5 rounded-full bg-[#0D00FF]/20 animate-ping" />
      </div>
    </section>
  );
}