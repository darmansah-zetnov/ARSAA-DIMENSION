import React from "react";
import { motion } from "motion/react";
import { Star, Quote } from "lucide-react";
import ARSAALogo from "./ARSAALogo";

const TESTIMONIALS = [
  {
    id: 1,
    name: "Budi Santoso",
    role: "Property Investor",
    company: "Jakarta Investment Group",
    avatar: "BS",
    rating: 5,
    text: "ARSAA DIMENSION mengubah cara saya berinvestasi properti. AI ARSAN memberikan analisis ROI yang akurat.",
  },
  {
    id: 2,
    name: "Sari Dewi",
    role: "First-time Buyer",
    company: "Marketing Executive",
    avatar: "SD",
    rating: 5,
    text: "Fitur AR membantu saya visualisasi rumah impian sebelum membeli. Platform yang sangat inovatif.",
  },
  {
    id: 3,
    name: "Ahmad Rahman",
    role: "Property Agent",
    company: "Premium Realty",
    avatar: "AR",
    rating: 5,
    text: "Closing rate meningkat 40% sejak menggunakan ARSAA DIMENSION. Klien sangat terkesan dengan AR tours.",
  },
];

export default function SimpleTestimonialsSection() {
  return (
    <section className="py-20 px-6 relative">
      {/* Simple Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#0D00FF]/3 to-transparent" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-4xl md:text-5xl font-bold">
            User Testimonials
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            Real experiences from users who transformed their property journey
          </p>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              className="relative p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300 group"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              {/* Quote Icon */}
              <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-[#0D00FF]/20 flex items-center justify-center">
                <Quote className="w-4 h-4 text-[#0D00FF]" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#0D00FF] text-[#0D00FF]" />
                ))}
              </div>

              {/* Testimonial Text */}
              <blockquote className="text-gray-300 leading-relaxed mb-6 group-hover:text-white transition-colors duration-300">
                "{testimonial.text}"
              </blockquote>

              {/* Author Info */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0D00FF] to-blue-400 flex items-center justify-center">
                  <span className="text-white font-semibold text-sm">
                    {testimonial.avatar}
                  </span>
                </div>
                <div>
                  <h4 className="text-white font-semibold group-hover:text-[#0D00FF] transition-colors duration-300">
                    {testimonial.name}
                  </h4>
                  <p className="text-gray-400 text-sm">
                    {testimonial.role}
                  </p>
                  <p className="text-gray-500 text-xs">
                    {testimonial.company}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Simple CTA */}
        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <p className="text-gray-400 mb-4">Join thousands of satisfied users</p>
          <button className="px-8 py-4 rounded-xl bg-[#0D00FF] hover:bg-[#0D00FF]/90 transition-all duration-300 font-medium">
            Start Your Journey
          </button>
        </motion.div>
      </div>
    </section>
  );
}