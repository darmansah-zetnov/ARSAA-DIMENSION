import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Heart, Share, MapPin, Bed, Bath, Square, Eye, Bookmark, TrendingUp } from "lucide-react";

interface PropertyCardProps {
  property: {
    id: string;
    title: string;
    location: string;
    price: string;
    beds: number;
    baths: number;
    sqft: string;
    image: string;
    type: string;
    featured?: boolean;
    district?: string;
    nearbyLandmarks?: string;
  };
  index: number;
}

export default function Enhanced3DPropertyCard({ property, index }: PropertyCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  return (
    <motion.div
      className="group relative"
      initial={{ opacity: 0, y: 50, rotateY: -15 }}
      whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay: index * 0.1 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      whileHover={!isMobile ? { 
        scale: 1.02, 
        y: -10,
        rotateY: 5,
        rotateX: 5,
      } : { scale: 1.01, y: -2 }}
      style={{
        transformStyle: "preserve-3d",
        perspective: "1000px",
      }}
    >
      {/* 3D Card Container */}
      <div className="relative rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 group-hover:border-[#0D00FF]/50 transition-all duration-500 overflow-hidden">
        
        {/* 3D Shadow Effect */}
        <div className="absolute inset-0 rounded-3xl bg-black/20 transform translate-y-2 translate-x-2 -z-10 group-hover:translate-y-4 group-hover:translate-x-4 transition-transform duration-300" />
        
        {/* Neon Glow Effect */}
        <div className="absolute inset-0 rounded-3xl shadow-[0_0_40px_rgba(13,0,255,0.1)] group-hover:shadow-[0_0_60px_rgba(13,0,255,0.3)] transition-all duration-500" />

        {/* Property Image */}
        <div className="relative h-64 overflow-hidden rounded-t-3xl">
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-[#0D00FF]/20 to-transparent"
            animate={{
              opacity: isHovered ? 1 : 0,
            }}
            transition={{ duration: 0.3 }}
          />
          
          {/* Placeholder for property image */}
          <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#0D00FF]/20 flex items-center justify-center">
                <MapPin className="w-8 h-8 text-[#0D00FF]" />
              </div>
              <p className="text-gray-400 text-sm">Property Image</p>
            </div>
          </div>

          {/* Floating Action Buttons */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <motion.button
              onClick={() => setIsLiked(!isLiked)}
              className={`w-10 h-10 rounded-full backdrop-blur-md border transition-all duration-300 flex items-center justify-center ${
                isLiked
                  ? "bg-red-500/20 border-red-500/50 text-red-400"
                  : "bg-white/10 border-white/20 text-gray-400 hover:text-red-400"
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
            >
              <Heart className={`w-5 h-5 ${isLiked ? "fill-current" : ""}`} />
            </motion.button>

            <motion.button
              onClick={() => setIsBookmarked(!isBookmarked)}
              className={`w-10 h-10 rounded-full backdrop-blur-md border transition-all duration-300 flex items-center justify-center ${
                isBookmarked
                  ? "bg-[#0D00FF]/20 border-[#0D00FF]/50 text-[#0D00FF]"
                  : "bg-white/10 border-white/20 text-gray-400 hover:text-[#0D00FF]"
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.1 + 0.3 }}
            >
              <Bookmark className={`w-5 h-5 ${isBookmarked ? "fill-current" : ""}`} />
            </motion.button>
          </div>

          {/* Property Type Badge */}
          <div className="absolute top-4 left-4">
            <motion.div
              className="px-3 py-1 rounded-full bg-[#0D00FF]/20 backdrop-blur-md border border-[#0D00FF]/50 text-[#0D00FF] text-xs font-semibold"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 + 0.1 }}
            >
              {property.type}
            </motion.div>
          </div>

          {/* AR View Button */}
          <motion.div
            className="absolute bottom-4 left-4 right-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: isHovered ? 1 : 0, y: isHovered ? 0 : 20 }}
            transition={{ duration: 0.3 }}
          >
            <motion.button
              className="w-full py-2 px-4 rounded-xl bg-[#0D00FF]/20 backdrop-blur-md border border-[#0D00FF]/50 text-[#0D00FF] text-sm font-semibold hover:bg-[#0D00FF]/30 transition-all duration-300 flex items-center justify-center gap-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Eye className="w-4 h-4" />
              View in AR
            </motion.button>
          </motion.div>
        </div>

        {/* Property Details */}
        <div className="p-6 relative">
          {/* Price */}
          <motion.div
            className="mb-4"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
          >
            <h3 className="text-2xl font-bold bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent">
              {property.price}
            </h3>
          </motion.div>

          {/* Title and Location */}
          <motion.div
            className="mb-4"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 + 0.4 }}
          >
            <h4 className="text-lg font-semibold text-white mb-2 group-hover:text-[#0D00FF] transition-colors duration-300">
              {property.title}
            </h4>
            <p className="text-gray-400 flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              {property.location}
            </p>
          </motion.div>

          {/* District and Landmarks */}
          {property.district && (
            <motion.div
              className="mb-3"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 + 0.45 }}
            >
              <p className="text-[#0D00FF] text-sm font-medium">{property.district}</p>
              {property.nearbyLandmarks && (
                <p className="text-gray-500 text-xs mt-1">Near: {property.nearbyLandmarks}</p>
              )}
            </motion.div>
          )}

          {/* Property Features */}
          <motion.div
            className="flex items-center gap-4 sm:gap-6 text-sm text-gray-400 flex-wrap"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 + 0.5 }}
          >
            <div className="flex items-center gap-2">
              <Bed className="w-4 h-4 text-[#0D00FF]" />
              <span>{property.beds} Beds</span>
            </div>
            <div className="flex items-center gap-2">
              <Bath className="w-4 h-4 text-[#0D00FF]" />
              <span>{property.baths} Baths</span>
            </div>
            <div className="flex items-center gap-2">
              <Square className="w-4 h-4 text-[#0D00FF]" />
              <span>{property.sqft}</span>
            </div>
          </motion.div>

          {/* Interactive Elements */}
          <motion.div
            className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 + 0.6 }}
          >
            <motion.button
              className="text-[#0D00FF] hover:text-white transition-colors duration-300 text-sm font-semibold"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              View Details
            </motion.button>
            
            <motion.button
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-[#0D00FF]/20 border border-white/20 hover:border-[#0D00FF]/50 flex items-center justify-center transition-all duration-300"
              whileHover={{ scale: 1.1, rotate: 15 }}
              whileTap={{ scale: 0.9 }}
            >
              <Share className="w-4 h-4 text-gray-400 hover:text-[#0D00FF]" />
            </motion.button>
          </motion.div>

          {/* Holographic Accent */}
          <motion.div
            className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-[#0D00FF]/10 to-transparent rounded-tr-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
            animate={{
              background: isHovered 
                ? "linear-gradient(135deg, rgba(13,0,255,0.2), transparent)" 
                : "linear-gradient(135deg, rgba(13,0,255,0.1), transparent)"
            }}
          />
        </div>

        {/* 3D Corner Accents */}
        <div className="absolute bottom-0 left-0 w-20 h-20 bg-gradient-to-tr from-[#0D00FF]/8 to-transparent rounded-bl-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

        {/* Animated Border */}
        <motion.div
          className="absolute inset-0 rounded-3xl pointer-events-none"
          style={{
            background: `conic-gradient(from 0deg, transparent, rgba(13, 0, 255, 0.3), transparent)`,
            padding: "1px",
            opacity: isHovered ? 1 : 0,
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
        />
      </div>

      {/* Floating Particles */}
      <motion.div
        className="absolute -top-2 -right-2 w-4 h-4 rounded-full bg-[#0D00FF]/40 blur-sm"
        animate={{
          scale: [1, 1.5, 1],
          opacity: [0.4, 0.8, 0.4],
          y: [-5, 5, -5],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
          delay: index * 0.2,
        }}
      />
    </motion.div>
  );
}