import React from "react";
import { motion } from "motion/react";
import { Mail, Phone, MapPin, Twitter, Linkedin, Github } from "lucide-react";
import ARSAALogo from "./ARSAALogo";

export default function SimpleFooter() {
  return (
    <footer className="py-16 px-6 relative border-t border-white/10">
      {/* Simple Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0D00FF]/5 to-transparent" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="mb-4">
              <ARSAALogo size="md" variant="glow" showText={true} />
            </div>
            <p className="text-gray-400 leading-relaxed">
              Masa depan real estate Indonesia dengan teknologi AR, AI, dan blockchain.
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h3 className="text-white font-semibold mb-4">Menu Utama</h3>
            <div className="space-y-2">
              {["Fitur", "Properti", "Tentang", "Kontak"].map((link, index) => {
                const hrefs = ["features", "properties", "about", "contact"];
                return (
                <a
                  key={link}
                  href={`#${hrefs[index]}`}
                  className="block text-gray-400 hover:text-[#0D00FF] transition-colors duration-300"
                >
                  {link}
                </a>
              )})}
            </div>
          </motion.div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-white font-semibold mb-4">Layanan</h3>
            <div className="space-y-2">
              {["Tur AR", "Navigasi AI", "Blockchain", "Analitik"].map((service) => (
                <div key={service} className="text-gray-400">
                  {service}
                </div>
              ))}
            </div>
          </motion.div>

          {/* Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h3 className="text-white font-semibold mb-4">Kontak</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-400">
                <Mail className="w-4 h-4" />
                <span className="text-sm">jamaludindarmansah.work@gmail.com</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <Phone className="w-4 h-4" />
                <span className="text-sm">+62 83866672100</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">Jakarta, Indonesia</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Bottom Section */}
        <motion.div
          className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="text-gray-400 text-sm">
            © 2024 ARSAA DIMENSION. All rights reserved.
          </div>
          
          <div className="flex items-center gap-4">
            {[
              { icon: Twitter, href: "#" },
              { icon: Linkedin, href: "#" },
              { icon: Github, href: "#" },
            ].map(({ icon: Icon, href }, index) => (
              <motion.a
                key={index}
                href={href}
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-[#0D00FF]/20 flex items-center justify-center transition-all duration-300"
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.9 }}
              >
                <Icon className="w-4 h-4 text-gray-400 hover:text-[#0D00FF] transition-colors duration-300" />
              </motion.a>
            ))}
          </div>
        </motion.div>
      </div>
    </footer>
  );
}