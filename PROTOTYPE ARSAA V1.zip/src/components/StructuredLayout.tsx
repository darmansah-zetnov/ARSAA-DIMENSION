import React from "react";
import { motion } from "motion/react";

interface SectionWrapperProps {
  id: string;
  children: React.ReactNode;
  className?: string;
  backgroundVariant?: "default" | "gradient" | "mesh" | "particles";
}

export function SectionWrapper({ 
  id, 
  children, 
  className = "", 
  backgroundVariant = "default" 
}: SectionWrapperProps) {
  return (
    <section 
      id={id} 
      className={`relative min-h-fit py-20 ${className}`}
    >
      {/* Dynamic Background Variants */}
      {backgroundVariant === "gradient" && (
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0D00FF]/3 to-transparent" />
      )}
      
      {backgroundVariant === "mesh" && (
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-full h-full opacity-5"
            style={{
              backgroundImage: `
                radial-gradient(circle at 25% 25%, #0D00FF 2px, transparent 2px),
                radial-gradient(circle at 75% 75%, #0D00FF 2px, transparent 2px)
              `,
              backgroundSize: '50px 50px'
            }}
          />
        </div>
      )}
      
      {backgroundVariant === "particles" && (
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-[#0D00FF]/30 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [-20, -40, -20],
                opacity: [0.3, 0.8, 0.3]
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
                ease: "easeInOut"
              }}
            />
          ))}
        </div>
      )}
      
      <div className="relative z-10">
        {children}
      </div>
    </section>
  );
}

interface FeatureGroupProps {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  className?: string;
}

export function FeatureGroup({ title, subtitle, children, className = "" }: FeatureGroupProps) {
  return (
    <div className={`max-w-7xl mx-auto px-6 ${className}`}>
      <motion.div
        className="text-center mb-16"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-4xl md:text-5xl font-bold">
          {title}
        </h2>
        {subtitle && (
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            {subtitle}
          </p>
        )}
      </motion.div>
      {children}
    </div>
  );
}

interface ContentCardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
}

export function ContentCard({ children, className = "", hover = true, glow = false }: ContentCardProps) {
  return (
    <motion.div
      className={`relative p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 transition-all duration-300 ${
        hover ? "hover:border-[#0D00FF]/50 hover:bg-white/10" : ""
      } ${className}`}
      whileHover={hover ? { y: -5 } : {}}
      transition={{ duration: 0.3 }}
    >
      {glow && (
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-transparent via-[#0D00FF]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
      )}
      {children}
    </motion.div>
  );
}

export default { SectionWrapper, FeatureGroup, ContentCard };