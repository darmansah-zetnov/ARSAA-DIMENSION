import React, { useEffect, useRef } from "react";
import { motion } from "motion/react";
import planetImage from "figma:asset/3f7f8be851758fb329970cee2518071c6d62a06a.png";

export default function Enhanced3DBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Device detection for performance optimization
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    const isLowEnd = navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4;
    
    // Set canvas size with device pixel ratio consideration
    const resizeCanvas = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      
      canvas.width = rect.width * (isMobile ? Math.min(dpr, 2) : dpr);
      canvas.height = rect.height * (isMobile ? Math.min(dpr, 2) : dpr);
      canvas.style.width = rect.width + 'px';
      canvas.style.height = rect.height + 'px';
      
      ctx.scale(isMobile ? Math.min(dpr, 2) : dpr, isMobile ? Math.min(dpr, 2) : dpr);
    };
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // 3D Particle system with adaptive count based on device
    const particles: Array<{
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
      vz: number;
      size: number;
      opacity: number;
      hue: number;
      trail: Array<{ x: number; y: number; opacity: number }>;
    }> = [];

    // Adaptive particle count for performance
    const particleCount = isMobile ? 30 : isLowEnd ? 50 : 80;
    
    // Create particles with 3D properties
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        z: Math.random() * 1000,
        vx: (Math.random() - 0.5) * 1,
        vy: (Math.random() - 0.5) * 1,
        vz: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        opacity: Math.random() * 0.7 + 0.3,
        hue: 240 + Math.random() * 60, // Blue to cyan range
        trail: [],
      });
    }

    // Mouse tracking for 3D interaction
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = {
        x: e.clientX,
        y: e.clientY,
      };
    };
    window.addEventListener("mousemove", handleMouseMove);

    let time = 0;

    // Animation loop with 3D effects
    const animate = () => {
      time += 0.02;
      ctx.fillStyle = "rgba(11, 12, 16, 0.1)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach((particle, index) => {
        // Update particle position with 3D movement
        particle.x += particle.vx;
        particle.y += particle.vy;
        particle.z += particle.vz;

        // Add orbital motion
        particle.x += Math.sin(time + index * 0.1) * 0.5;
        particle.y += Math.cos(time + index * 0.1) * 0.3;

        // 3D mouse interaction
        const dx = mouseRef.current.x - particle.x;
        const dy = mouseRef.current.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 150) {
          const force = (150 - distance) / 150;
          particle.vx += dx * force * 0.0001;
          particle.vy += dy * force * 0.0001;
          particle.z += force * 10;
        }

        // Wrap around edges with 3D depth
        if (particle.x < 0) particle.x = canvas.width;
        if (particle.x > canvas.width) particle.x = 0;
        if (particle.y < 0) particle.y = canvas.height;
        if (particle.y > canvas.height) particle.y = 0;
        if (particle.z < 0) particle.z = 1000;
        if (particle.z > 1000) particle.z = 0;

        // Calculate 3D perspective
        const perspective = 1000;
        const scale = perspective / (perspective + particle.z);
        const projectedSize = particle.size * scale;
        const projectedOpacity = particle.opacity * scale;

        // Update trail (reduced for mobile performance)
        const trailLength = isMobile ? 2 : 5;
        particle.trail.push({ 
          x: particle.x, 
          y: particle.y, 
          opacity: projectedOpacity 
        });
        if (particle.trail.length > trailLength) {
          particle.trail.shift();
        }

        // Draw particle trail
        particle.trail.forEach((point, trailIndex) => {
          const trailOpacity = (point.opacity * (trailIndex + 1)) / particle.trail.length;
          const trailSize = projectedSize * ((trailIndex + 1) / particle.trail.length);
          
          ctx.beginPath();
          ctx.arc(point.x, point.y, trailSize * 0.5, 0, Math.PI * 2);
          ctx.fillStyle = `hsla(${particle.hue}, 100%, 70%, ${trailOpacity * 0.3})`;
          ctx.fill();
        });

        // Draw main particle with 3D glow
        const gradient = ctx.createRadialGradient(
          particle.x, particle.y, 0,
          particle.x, particle.y, projectedSize * 3
        );
        gradient.addColorStop(0, `hsla(${particle.hue}, 100%, 70%, ${projectedOpacity})`);
        gradient.addColorStop(0.5, `hsla(${particle.hue}, 100%, 50%, ${projectedOpacity * 0.5})`);
        gradient.addColorStop(1, `hsla(${particle.hue}, 100%, 30%, 0)`);

        ctx.beginPath();
        ctx.arc(particle.x, particle.y, projectedSize, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();

        // Draw connections with 3D depth
        particles.forEach((otherParticle, otherIndex) => {
          if (index >= otherIndex) return;
          
          const dx2 = particle.x - otherParticle.x;
          const dy2 = particle.y - otherParticle.y;
          const dz2 = particle.z - otherParticle.z;
          const distance3D = Math.sqrt(dx2 * dx2 + dy2 * dy2 + dz2 * dz2);

          if (distance3D < 120) {
            const connectionOpacity = (1 - distance3D / 120) * 0.2;
            const avgZ = (particle.z + otherParticle.z) / 2;
            const connectionScale = perspective / (perspective + avgZ);
            
            ctx.beginPath();
            ctx.moveTo(particle.x, particle.y);
            ctx.lineTo(otherParticle.x, otherParticle.y);
            ctx.strokeStyle = `rgba(13, 0, 255, ${connectionOpacity * connectionScale})`;
            ctx.lineWidth = connectionScale;
            ctx.stroke();
          }
        });
      });

      // Add floating 3D geometric shapes (reduced for mobile)
      const numShapes = isMobile ? 2 : 5;
      for (let i = 0; i < numShapes; i++) {
        const shapeTime = time + i * 2;
        const x = canvas.width * 0.5 + Math.sin(shapeTime * 0.5) * 200;
        const y = canvas.height * 0.5 + Math.cos(shapeTime * 0.3) * 150;
        const z = 500 + Math.sin(shapeTime) * 200;
        const scale = 1000 / (1000 + z);
        const size = 30 * scale;
        const rotation = shapeTime;

        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(rotation);
        ctx.scale(scale, scale);

        // Draw 3D wireframe cube
        const cubeSize = size;
        ctx.strokeStyle = `rgba(13, 0, 255, ${0.3 * scale})`;
        ctx.lineWidth = 2;
        
        // Front face
        ctx.strokeRect(-cubeSize/2, -cubeSize/2, cubeSize, cubeSize);
        
        // Back face (perspective effect)
        const offset = cubeSize * 0.3;
        ctx.strokeRect(-cubeSize/2 - offset, -cubeSize/2 - offset, cubeSize, cubeSize);
        
        // Connecting lines
        ctx.beginPath();
        ctx.moveTo(-cubeSize/2, -cubeSize/2);
        ctx.lineTo(-cubeSize/2 - offset, -cubeSize/2 - offset);
        ctx.moveTo(cubeSize/2, -cubeSize/2);
        ctx.lineTo(cubeSize/2 - offset, -cubeSize/2 - offset);
        ctx.moveTo(-cubeSize/2, cubeSize/2);
        ctx.lineTo(-cubeSize/2 - offset, cubeSize/2 - offset);
        ctx.moveTo(cubeSize/2, cubeSize/2);
        ctx.lineTo(cubeSize/2 - offset, cubeSize/2 - offset);
        ctx.stroke();

        ctx.restore();
      }

      requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener("resize", resizeCanvas);
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {/* Glowing Planet Background */}
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 2 }}
      >
        <motion.img
          src={planetImage}
          alt="Futuristic Planet"
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] object-contain opacity-30"
          animate={{
            rotate: 360,
            scale: [1, 1.1, 1],
          }}
          transition={{
            rotate: { duration: 60, repeat: Infinity, ease: "linear" },
            scale: { duration: 8, repeat: Infinity, ease: "easeInOut" },
          }}
        />
      </motion.div>

      {/* Enhanced particle canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 z-10"
      />

      {/* Additional atmospheric effects */}
      <div className="absolute inset-0 z-20">
        {/* Floating light orbs */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-4 h-4 rounded-full bg-[#0D00FF]/40 blur-sm"
            style={{
              left: `${20 + i * 15}%`,
              top: `${30 + (i % 3) * 20}%`,
            }}
            animate={{
              y: [-20, 20, -20],
              x: [-10, 10, -10],
              opacity: [0.4, 0.8, 0.4],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 4 + i,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 0.5,
            }}
          />
        ))}

        {/* Scanning lines effect */}
        <motion.div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `repeating-linear-gradient(
              90deg,
              transparent,
              transparent 100px,
              rgba(13, 0, 255, 0.03) 102px,
              rgba(13, 0, 255, 0.03) 104px
            )`,
          }}
          animate={{
            x: ["-100%", "100%"],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear",
          }}
        />

        {/* Holographic grid */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(rgba(13, 0, 255, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(13, 0, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: "50px 50px",
          }}
        />
      </div>
    </div>
  );
}