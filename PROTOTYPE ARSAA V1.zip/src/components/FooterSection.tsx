import React from "react";
import { motion } from "motion/react";
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, Youtube } from "lucide-react";

const FOOTER_LINKS = {
  platform: [
    { name: "AI Navigator", href: "#" },
    { name: "AR Showcase", href: "#" },
    { name: "Web3 Ledger", href: "#" },
    { name: "Smart Analytics", href: "#" },
  ],
  solutions: [
    { name: "For Buyers", href: "#" },
    { name: "For Investors", href: "#" },
    { name: "For Agents", href: "#" },
    { name: "For Developers", href: "#" },
  ],
  company: [
    { name: "About Us", href: "#" },
    { name: "Careers", href: "#" },
    { name: "Press", href: "#" },
    { name: "Contact", href: "#" },
  ],
  resources: [
    { name: "Help Center", href: "#" },
    { name: "API Docs", href: "#" },
    { name: "Community", href: "#" },
    { name: "Blog", href: "#" },
  ],
};

const SOCIAL_LINKS = [
  { name: "Facebook", icon: Facebook, href: "#" },
  { name: "Twitter", icon: Twitter, href: "#" },
  { name: "Instagram", icon: Instagram, href: "#" },
  { name: "LinkedIn", icon: Linkedin, href: "#" },
  { name: "YouTube", icon: Youtube, href: "#" },
];

export default function FooterSection() {
  return (
    <footer className="relative py-20 px-6 bg-[#0B0C10] border-t border-[#0D00FF]/20">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10] via-[#0D00FF]/5 to-transparent" />
      
      {/* Moving Neon Accents */}
      <motion.div
        className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#0D00FF] to-transparent"
        animate={{
          x: ["-100%", "100%"],
          opacity: [0, 1, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Floating Particles */}
      <div className="absolute top-10 left-20 w-2 h-2 rounded-full bg-[#0D00FF]/40 animate-pulse" />
      <div className="absolute top-32 right-32 w-3 h-3 rounded-full bg-[#0D00FF]/30 animate-bounce" />
      <div className="absolute bottom-20 left-32 w-1 h-1 rounded-full bg-[#0D00FF]/60 animate-ping" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Section */}
          <motion.div
            className="lg:col-span-1"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <motion.div
              className="mb-6"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="mb-4 bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent"
                  style={{ fontSize: "2rem", fontWeight: "bold" }}>
                ARSAA DIMENSION
              </h3>
              
              <p className="text-gray-400 mb-6 leading-relaxed">
                Platform properti masa depan yang menggabungkan teknologi AI, AR, dan Blockchain 
                untuk pengalaman real estate yang revolusioner.
              </p>
            </motion.div>

            {/* Contact Info */}
            <div className="space-y-4">
              {[
                { icon: Mail, text: "hello@arsaadimension.com", href: "mailto:hello@arsaadimension.com" },
                { icon: Phone, text: "+62 21 1234 5678", href: "tel:+6221234567" },
                { icon: MapPin, text: "Jakarta, Indonesia", href: "#" },
              ].map((contact, index) => (
                <motion.a
                  key={contact.text}
                  href={contact.href}
                  className="flex items-center gap-3 text-gray-400 hover:text-[#0D00FF] transition-colors duration-300 group"
                  whileHover={{ x: 5 }}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                >
                  <div className="w-10 h-10 rounded-full bg-white/10 group-hover:bg-[#0D00FF]/20 flex items-center justify-center transition-all duration-300">
                    <contact.icon className="w-4 h-4" />
                  </div>
                  <span className="text-sm">{contact.text}</span>
                </motion.a>
              ))}
            </div>
          </motion.div>

          {/* Links Sections */}
          {Object.entries(FOOTER_LINKS).map(([category, links], categoryIndex) => (
            <motion.div
              key={category}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: categoryIndex * 0.1 }}
            >
              <h4 className="mb-6 text-white capitalize"
                  style={{ fontSize: "1.2rem", fontWeight: "600" }}>
                {category === "platform" ? "Platform" :
                 category === "solutions" ? "Solutions" :
                 category === "company" ? "Company" : "Resources"}
              </h4>
              
              <ul className="space-y-3">
                {links.map((link, linkIndex) => (
                  <motion.li
                    key={link.name}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: linkIndex * 0.05 }}
                  >
                    <motion.a
                      href={link.href}
                      className="text-gray-400 hover:text-[#0D00FF] transition-colors duration-300 text-sm block relative group"
                      whileHover={{ x: 5 }}
                    >
                      {link.name}
                      <div className="absolute left-0 bottom-0 w-0 h-px bg-[#0D00FF] group-hover:w-full transition-all duration-300" />
                    </motion.a>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Newsletter Section */}
        <motion.div
          className="mb-12 p-8 rounded-3xl bg-gradient-to-r from-[#0D00FF]/10 to-transparent border border-[#0D00FF]/30"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <div className="max-w-2xl mx-auto text-center">
            <motion.h4
              className="mb-4 text-white"
              style={{ fontSize: "1.5rem", fontWeight: "600" }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              Stay Connected with the Future
            </motion.h4>
            
            <motion.p
              className="text-gray-400 mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              Get the latest updates on AR, AI, and Web3 innovations in real estate
            </motion.p>

            <motion.div
              className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.7 }}
            >
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 focus:border-[#0D00FF]/50 text-white placeholder-gray-400 outline-none transition-all duration-300"
              />
              <motion.button
                className="px-6 py-3 rounded-xl bg-[#0D00FF] hover:bg-[#0D00FF]/80 text-white transition-all duration-300"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Subscribe
              </motion.button>
            </motion.div>
          </div>
        </motion.div>

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-white/10">
          {/* Social Media Links */}
          <motion.div
            className="flex items-center gap-4 mb-6 md:mb-0"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {SOCIAL_LINKS.map((social, index) => (
              <motion.a
                key={social.name}
                href={social.href}
                className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:border-[#0D00FF]/70 flex items-center justify-center group transition-all duration-300"
                whileHover={{ 
                  scale: 1.1, 
                  y: -2,
                  boxShadow: "0 0 20px rgba(13,0,255,0.5)"
                }}
                whileTap={{ scale: 0.9 }}
                initial={{ opacity: 0, scale: 0 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <social.icon className="w-5 h-5 text-gray-400 group-hover:text-[#0D00FF] transition-colors duration-300" />
                
                {/* Neon Glow Effect */}
                <div className="absolute inset-0 rounded-full bg-[#0D00FF]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </motion.a>
            ))}
          </motion.div>

          {/* Copyright and Links */}
          <motion.div
            className="text-center md:text-right"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <p className="text-gray-400 text-sm mb-2">
              © 2024 ARSAA DIMENSION. All rights reserved.
            </p>
            
            <div className="flex flex-wrap justify-center md:justify-end gap-6 text-sm">
              {["Privacy Policy", "Terms of Service", "Cookie Policy"].map((link, index) => (
                <motion.a
                  key={link}
                  href="#"
                  className="text-gray-400 hover:text-[#0D00FF] transition-colors duration-300 relative group"
                  whileHover={{ y: -1 }}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: 0.5 + index * 0.1 }}
                >
                  {link}
                  <div className="absolute left-0 bottom-0 w-0 h-px bg-[#0D00FF] group-hover:w-full transition-all duration-300" />
                </motion.a>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Final Accent */}
        <motion.div
          className="mt-8 pt-8 border-t border-[#0D00FF]/20 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <motion.p
            className="text-[#0D00FF]/70 text-sm"
            animate={{
              opacity: [0.7, 1, 0.7],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            ✨ Powered by Advanced AI, AR, and Blockchain Technology ✨
          </motion.p>
        </motion.div>
      </div>

      {/* Bottom Neon Line */}
      <motion.div
        className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#0D00FF] to-transparent"
        animate={{
          opacity: [0.3, 1, 0.3],
          scaleX: [0.8, 1, 0.8],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
    </footer>
  );
}