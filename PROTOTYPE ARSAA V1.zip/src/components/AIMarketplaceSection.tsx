import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  ShoppingCart, 
  Heart, 
  Eye, 
  Filter, 
  Zap, 
  BarChart3, 
  MapPin, 
  Star,
  TrendingUp,
  Brain,
  ChevronDown,
  Sparkles,
  Target,
  Loader
} from "lucide-react";
import { projectId, publicAnonKey } from '../utils/supabase/info';

const MARKETPLACE_PROPERTIES = [
  {
    id: "1",
    title: "AI-Optimized Villa Serpong",
    location: "BSD City, Tangerang Selatan",
    price: "Rp 4.8B",
    aiScore: 95,
    predictedROI: "18.5%",
    marketTrend: "rising",
    beds: 5,
    baths: 4,
    sqft: "420m²",
    aiInsights: ["High appreciation potential", "Premium location", "Smart home ready"],
    isRecommended: true,
    isFavorited: false,
  },
  {
    id: "2",
    title: "Smart Investment Apartment",
    location: "Alam Sutera, Tangerang Selatan",
    price: "Rp 2.9B",
    aiScore: 88,
    predictedROI: "15.2%",
    marketTrend: "stable",
    beds: 3,
    baths: 2,
    sqft: "145m²",
    aiInsights: ["Steady rental income", "Growing area", "Good liquidity"],
    isRecommended: false,
    isFavorited: true,
  },
  {
    id: "3",
    title: "Future-Ready Penthouse",
    location: "SCBD, Jakarta Selatan",
    price: "Rp 12.5B",
    aiScore: 92,
    predictedROI: "22.3%",
    marketTrend: "rising",
    beds: 4,
    baths: 4,
    sqft: "285m²",
    aiInsights: ["Luxury market leader", "Business district", "High demand"],
    isRecommended: true,
    isFavorited: false,
  },
];

const AI_FILTERS = [
  { name: "AI Recommended", count: 23, active: true },
  { name: "High ROI (>15%)", count: 18, active: false },
  { name: "Smart Homes", count: 12, active: false },
  { name: "Rising Markets", count: 31, active: false },
];

export default function AIMarketplaceSection() {
  const [properties, setProperties] = useState(MARKETPLACE_PROPERTIES);
  const [realTimeProperties, setRealTimeProperties] = useState([]);
  const [activeFilter, setActiveFilter] = useState("All Properties");
  const [sortBy, setSortBy] = useState("AI Score");
  const [isLoading, setIsLoading] = useState(false);
  const [aiRecommendations, setAiRecommendations] = useState([]);

  // Load real-time property data from AI backend
  useEffect(() => {
    const loadRealTimeData = async () => {
      if (!projectId || !publicAnonKey) {
        console.log('Supabase credentials not available, using static data only');
        return;
      }
      
      setIsLoading(true);
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-58f5cb12/recommendations?budget=8000000000`, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          
          // Transform backend data to match component format
          if (data && data.recommendations && Array.isArray(data.recommendations)) {
            const transformedProperties = data.recommendations.map((prop, index) => ({
              id: prop.id || `prop_${index}`,
              title: `AI-Enhanced ${prop.name || 'Property'}`,
              location: prop.location || 'Location TBD',
              price: `Rp ${((prop.price || 0) / 1000000000).toFixed(1)}B`,
              aiScore: Math.round(85 + ((prop.roi || 0) * 0.8)), // Calculate AI score based on ROI
              predictedROI: `${prop.roi || 0}%`,
              marketTrend: (prop.roi || 0) > 13 ? "rising" : (prop.roi || 0) > 11 ? "stable" : "falling",
              beds: prop.bedrooms || 3,
              baths: prop.bathrooms || 2,
              sqft: `${prop.area || 150}m²`,
              aiInsights: [
                `${prop.roi || 0}% ROI potential`,
                (prop.features && prop.features[0]) || "Premium location",
                "AI-verified data"
              ],
              isRecommended: (prop.roi || 0) > 13,
              isFavorited: false,
              enhanced: true
            }));

            setRealTimeProperties(transformedProperties);
            setAiRecommendations(transformedProperties.filter(p => p.isRecommended));
          }
        }
      } catch (error) {
        console.error('Failed to load real-time data:', error);
        // Fallback to static data only
        setRealTimeProperties([]);
        setAiRecommendations([]);
      } finally {
        setIsLoading(false);
      }
    };

    loadRealTimeData();
  }, [projectId, publicAnonKey]);

  // Combine static and real-time properties
  const allProperties = [
    ...(properties || []), 
    ...(realTimeProperties || [])
  ];

  const toggleFavorite = (id: string) => {
    setProperties(prev => prev.map(prop => 
      prop.id === id ? { ...prop, isFavorited: !prop.isFavorited } : prop
    ));
    setRealTimeProperties(prev => prev.map(prop => 
      prop.id === id ? { ...prop, isFavorited: !prop.isFavorited } : prop
    ));
  };

  const getTrendIcon = (trend: string) => {
    return trend === "rising" ? "📈" : trend === "falling" ? "📉" : "➡️";
  };

  return (
    <section className="py-20 px-6 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0D00FF]/3 to-transparent" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[#0D00FF]/20 flex items-center justify-center">
              <ShoppingCart className="w-8 h-8 text-[#0D00FF]" />
            </div>
          </div>
          
          <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-4xl md:text-5xl font-bold">
            Marketplace Bertenaga AI
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg mb-6">
            Marketplace AI canggih dengan analisis properti real-time, intelijen pasar, dan rekomendasi investasi yang dipersonalisasi.
          </p>
          
          {/* Real-time Stats */}
          <motion.div 
            className="flex justify-center gap-8 mb-8"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <div className="text-center">
              <div className="text-2xl font-bold text-[#0D00FF] flex items-center gap-2">
                {allProperties.length}
                {isLoading && <Loader className="w-4 h-4 animate-spin" />}
              </div>
              <div className="text-gray-400 text-sm">Properti Dianalisis</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">{aiRecommendations.length}</div>
              <div className="text-gray-400 text-sm">AI Recommendations</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#0D00FF]">
                {allProperties.length > 0 ? Math.round(allProperties.reduce((acc, p) => acc + (typeof p.aiScore === 'number' ? p.aiScore : parseFloat(p.aiScore)), 0) / allProperties.length) : 95}
              </div>
              <div className="text-gray-400 text-sm">Avg AI Score</div>
            </div>
          </motion.div>
        </motion.div>

        {/* AI Marketplace Controls */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between">
            {/* AI Filters */}
            <div className="flex flex-wrap gap-3">
              {AI_FILTERS.map((filter) => (
                <motion.button
                  key={filter.name}
                  className={`px-4 py-2 rounded-xl border transition-all duration-300 flex items-center gap-2 ${
                    filter.active
                      ? "bg-[#0D00FF]/20 border-[#0D00FF]/50 text-[#0D00FF]"
                      : "bg-white/5 border-white/20 text-gray-300 hover:border-[#0D00FF]/30"
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Brain className="w-4 h-4" />
                  <span className="text-sm font-medium">{filter.name}</span>
                  <span className="text-xs px-2 py-1 rounded-full bg-white/10">{filter.count}</span>
                </motion.button>
              ))}
            </div>

            {/* Sort Controls */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="appearance-none px-4 py-2 pr-8 rounded-xl bg-white/10 border border-white/20 text-white outline-none cursor-pointer"
                >
                  <option value="AI Score" className="bg-gray-900">AI Score</option>
                  <option value="Price" className="bg-gray-900">Price</option>
                  <option value="ROI" className="bg-gray-900">Predicted ROI</option>
                  <option value="Location" className="bg-gray-900">Location</option>
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400" />
              </div>
              
              <button className="px-4 py-2 rounded-xl bg-white/10 border border-white/20 hover:border-[#0D00FF]/50 transition-all duration-300 flex items-center gap-2">
                <Filter className="w-4 h-4" />
                <span className="text-sm">More Filters</span>
              </button>
            </div>
          </div>
        </motion.div>

        {/* AI Marketplace Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Properties List */}
          <div className="lg:col-span-2 space-y-6">
            {allProperties.map((property, index) => (
              <motion.div
                key={property.id}
                className="relative p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300 group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -2 }}
              >
                {/* AI Badges */}
                <div className="absolute top-4 right-4 flex gap-2">
                  {property.enhanced && (
                    <div className="px-2 py-1 rounded-full bg-green-500/20 border border-green-500/50 text-green-400 text-xs font-medium flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      Live Data
                    </div>
                  )}
                  {property.isRecommended && (
                    <div className="px-3 py-1 rounded-full bg-[#0D00FF]/20 border border-[#0D00FF]/50 text-[#0D00FF] text-sm font-medium flex items-center gap-1">
                      <Zap className="w-3 h-3" />
                      AI Pick
                    </div>
                  )}
                </div>

                <div className="flex flex-col md:flex-row gap-6">
                  {/* Property Image Placeholder */}
                  <div className="w-full md:w-48 h-32 rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center relative overflow-hidden">
                    <div className="text-center">
                      <Eye className="w-8 h-8 mx-auto mb-2 text-[#0D00FF]" />
                      <p className="text-gray-400 text-sm">AR View</p>
                    </div>
                    
                    {/* Favorite Button */}
                    <button
                      onClick={() => toggleFavorite(property.id)}
                      className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center hover:bg-black/70 transition-all duration-300"
                    >
                      <Heart className={`w-4 h-4 ${property.isFavorited ? 'fill-red-500 text-red-500' : 'text-white'}`} />
                    </button>
                  </div>

                  {/* Property Details */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-[#0D00FF] transition-colors duration-300">
                          {property.title}
                        </h3>
                        <div className="flex items-center gap-2 text-gray-400 mb-2">
                          <MapPin className="w-4 h-4" />
                          <span className="text-sm">{property.location}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent">
                          {property.price}
                        </div>
                      </div>
                    </div>

                    {/* AI Metrics */}
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div className="text-center p-3 rounded-xl bg-white/5">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <Brain className="w-4 h-4 text-[#0D00FF]" />
                          <span className="text-sm text-gray-400">AI Score</span>
                        </div>
                        <div className="text-lg font-bold text-[#0D00FF]">{property.aiScore}/100</div>
                      </div>
                      
                      <div className="text-center p-3 rounded-xl bg-white/5">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <TrendingUp className="w-4 h-4 text-green-400" />
                          <span className="text-sm text-gray-400">ROI</span>
                        </div>
                        <div className="text-lg font-bold text-green-400">{property.predictedROI}</div>
                      </div>
                      
                      <div className="text-center p-3 rounded-xl bg-white/5">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <BarChart3 className="w-4 h-4 text-orange-400" />
                          <span className="text-sm text-gray-400">Trend</span>
                        </div>
                        <div className="text-lg">{getTrendIcon(property.marketTrend)}</div>
                      </div>
                    </div>

                    {/* Property Stats */}
                    <div className="flex items-center gap-6 text-sm text-gray-400 mb-4">
                      <span>{property.beds} Beds</span>
                      <span>{property.baths} Baths</span>
                      <span>{property.sqft}</span>
                    </div>

                    {/* AI Insights */}
                    <div className="mb-4">
                      <div className="flex flex-wrap gap-2">
                        {property.aiInsights.map((insight, idx) => (
                          <span key={idx} className="px-3 py-1 rounded-full bg-[#0D00FF]/10 border border-[#0D00FF]/30 text-[#0D00FF] text-xs">
                            {insight}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-3">
                      <button className="flex-1 py-2 px-4 rounded-xl bg-[#0D00FF]/20 text-[#0D00FF] hover:bg-[#0D00FF]/30 transition-all duration-300 text-sm font-medium">
                        View in AR
                      </button>
                      <button className="flex-1 py-2 px-4 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300 text-sm font-medium">
                        AI Analysis
                      </button>
                      <button className="px-4 py-2 rounded-xl bg-[#0D00FF] hover:bg-[#0D00FF]/90 transition-all duration-300 text-sm font-medium">
                        Contact
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* AI Sidebar */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            {/* Market Intelligence */}
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-[#0D00FF]" />
                Market Intelligence
              </h3>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-white/10">
                  <span className="text-gray-400 text-sm">Avg. Price Growth</span>
                  <span className="text-green-400 font-semibold">+12.5%</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-white/10">
                  <span className="text-gray-400 text-sm">Market Demand</span>
                  <span className="text-[#0D00FF] font-semibold">High</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-white/10">
                  <span className="text-gray-400 text-sm">Investment Score</span>
                  <span className="text-white font-semibold">8.9/10</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-400 text-sm">Best ROI Area</span>
                  <span className="text-orange-400 font-semibold">BSD City</span>
                </div>
              </div>
            </div>

            {/* AI Recommendations */}
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Star className="w-5 h-5 text-[#0D00FF]" />
                AI Recommendations
              </h3>
              
              <div className="space-y-3">
                <div className="p-3 rounded-xl bg-[#0D00FF]/10 border border-[#0D00FF]/30">
                  <div className="text-[#0D00FF] font-medium text-sm mb-1">Hot Pick</div>
                  <div className="text-white text-sm">BSD City villas showing 18% ROI potential</div>
                </div>
                
                <div className="p-3 rounded-xl bg-green-500/10 border border-green-500/30">
                  <div className="text-green-400 font-medium text-sm mb-1">Rising Market</div>
                  <div className="text-white text-sm">Alam Sutera apartments gaining momentum</div>
                </div>
                
                <div className="p-3 rounded-xl bg-orange-500/10 border border-orange-500/30">
                  <div className="text-orange-400 font-medium text-sm mb-1">Price Alert</div>
                  <div className="text-white text-sm">SCBD prices expected to rise 15%</div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
              <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
              
              <div className="space-y-3">
                <button className="w-full py-3 px-4 rounded-xl bg-[#0D00FF]/20 text-[#0D00FF] hover:bg-[#0D00FF]/30 transition-all duration-300 text-sm font-medium">
                  Get AI Investment Report
                </button>
                <button className="w-full py-3 px-4 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300 text-sm font-medium">
                  Schedule AI Consultation
                </button>
                <button className="w-full py-3 px-4 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300 text-sm font-medium">
                  Set Price Alerts
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}