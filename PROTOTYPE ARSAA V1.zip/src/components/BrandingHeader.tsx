import React from "react";
import { motion } from "motion/react";
import ARSAALogo from "./ARSAALogo";

export default function BrandingHeader() {
  return (
    <motion.div
      className="fixed top-20 left-6 z-40"
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 1, delay: 1.5 }}
    >
      <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10">
        <ARSAALogo size="sm" variant="glow" showText={false} />
      </div>
    </motion.div>
  );
}