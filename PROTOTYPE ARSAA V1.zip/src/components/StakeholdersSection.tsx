import React from "react";
import { motion } from "motion/react";
import { Home, TrendingUp, Users, Building } from "lucide-react";

const STAKEHOLDERS = [
  {
    title: "Pembeli Properti",
    description: "Eksplorasi properti dengan AR, analisis AI untuk investasi terbaik, dan transparansi Web3 untuk keamanan transaksi.",
    icon: Home,
    gradient: "from-[#0D00FF] to-blue-400",
    benefits: ["AR Virtual Tours", "AI Investment Analysis", "Secure Transactions"],
  },
  {
    title: "Investor Real Estate",
    description: "Analisis ROI prediktif dengan AI, data blockchain untuk transparansi, dan rekomendasi portofolio yang dioptimalkan.",
    icon: TrendingUp,
    gradient: "from-[#0D00FF] to-green-400",
    benefits: ["ROI Analysis", "Market Insights", "Portfolio Optimization"],
  },
  {
    title: "Agen Properti",
    description: "Platform digital terdepan untuk showcase properti, tools AI untuk client matching, dan sistem manajemen terintegrasi.",
    icon: Users,
    gradient: "from-[#0D00FF] to-purple-400",
    benefits: ["Digital Showcase", "Client Matching", "Lead Management"],
  },
  {
    title: "Developer",
    description: "Marketing immersive dengan AR/VR, analytics mendalam untuk project planning, dan blockchain untuk transparansi proyek.",
    icon: Building,
    gradient: "from-[#0D00FF] to-orange-400",
    benefits: ["Immersive Marketing", "Project Analytics", "Transparent Development"],
  },
];

export default function StakeholdersSection() {
  return (
    <section className="py-20 px-6 relative">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#0B0C10] via-[#0D00FF]/3 to-[#0B0C10]" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2
            className="mb-6 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent"
            style={{ fontSize: "3rem", fontWeight: "bold" }}
          >
            Untuk Siapa?
          </motion.h2>
          
          <motion.p
            className="text-gray-300 max-w-3xl mx-auto"
            style={{ fontSize: "1.2rem" }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            Solusi komprehensif untuk semua stakeholder dalam ekosistem properti modern
          </motion.p>
        </motion.div>

        {/* Stakeholders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {STAKEHOLDERS.map((stakeholder, index) => (
            <motion.div
              key={stakeholder.title}
              className="group relative"
              initial={{ opacity: 0, y: 50, rotateY: -15 }}
              whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              whileHover={{ 
                scale: 1.02, 
                y: -8,
                rotateY: 5,
              }}
            >
              {/* Card Container */}
              <div className="relative p-8 rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 group-hover:border-[#0D00FF]/70 transition-all duration-500 overflow-hidden h-full">
                
                {/* Neon Glow Effects */}
                <div className="absolute inset-0 rounded-3xl shadow-[0_0_50px_rgba(13,0,255,0.1)] group-hover:shadow-[0_0_50px_rgba(13,0,255,0.3)] transition-all duration-500" />
                
                {/* Animated Background */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#0D00FF]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl" />
                
                {/* Floating Particles */}
                <motion.div
                  className="absolute top-6 right-6 w-3 h-3 rounded-full bg-[#0D00FF]/40"
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.4, 0.8, 0.4],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: index * 0.3,
                  }}
                />

                {/* 3D Icon */}
                <motion.div
                  className="relative mb-6"
                  whileHover={{ 
                    rotateY: 15,
                    rotateX: 10,
                    scale: 1.1,
                  }}
                  transition={{ duration: 0.6, ease: "easeOut" }}
                >
                  <div className={`relative w-20 h-20 rounded-3xl bg-gradient-to-br ${stakeholder.gradient} p-5 group-hover:shadow-[0_0_40px_rgba(13,0,255,0.4)] transition-all duration-500`}>
                    
                    {/* Icon Highlight */}
                    <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    
                    <stakeholder.icon 
                      className="w-full h-full text-white relative z-10"
                      strokeWidth={1.5}
                    />

                    {/* 3D Shadow Effect */}
                    <div className="absolute inset-0 rounded-3xl bg-black/20 translate-y-1 translate-x-1 -z-10 group-hover:translate-y-2 group-hover:translate-x-2 transition-transform duration-300" />
                  </div>
                </motion.div>

                {/* Content */}
                <div className="relative z-10">
                  <motion.h3
                    className="mb-4 bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent group-hover:from-[#0D00FF] group-hover:to-white transition-all duration-500"
                    style={{ fontSize: "1.5rem", fontWeight: "600" }}
                    initial={{ opacity: 0, x: -30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.1 + 0.2 }}
                  >
                    {stakeholder.title}
                  </motion.h3>

                  <motion.p
                    className="text-gray-300 group-hover:text-white transition-colors duration-300 mb-6 leading-relaxed"
                    initial={{ opacity: 0, x: -30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.1 + 0.3 }}
                  >
                    {stakeholder.description}
                  </motion.p>

                  {/* Benefits List */}
                  <motion.div
                    className="space-y-3"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.1 + 0.4 }}
                  >
                    {stakeholder.benefits.map((benefit, benefitIndex) => (
                      <motion.div
                        key={benefit}
                        className="flex items-center gap-3"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.4, delay: index * 0.1 + 0.5 + benefitIndex * 0.1 }}
                      >
                        <div className="w-2 h-2 rounded-full bg-[#0D00FF] group-hover:shadow-[0_0_10px_rgba(13,0,255,0.8)] transition-all duration-300" />
                        <span className="text-gray-400 group-hover:text-gray-200 transition-colors duration-300 text-sm">
                          {benefit}
                        </span>
                      </motion.div>
                    ))}
                  </motion.div>
                </div>

                {/* Corner Decorations */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-[#0D00FF]/10 to-transparent rounded-tr-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute bottom-0 left-0 w-20 h-20 bg-gradient-to-tr from-[#0D00FF]/8 to-transparent rounded-bl-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                {/* Interactive Border */}
                <motion.div
                  className="absolute inset-0 rounded-3xl ring-1 ring-transparent group-hover:ring-[#0D00FF]/40"
                  whileHover={{
                    scale: [1, 1.02, 1],
                  }}
                  transition={{ duration: 1, repeat: Infinity }}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Value Proposition */}
        <motion.div
          className="text-center mt-16 p-8 rounded-3xl bg-gradient-to-r from-[#0D00FF]/10 via-transparent to-[#0D00FF]/10 border border-[#0D00FF]/20"
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <motion.h3
            className="mb-4 text-[#0D00FF]"
            style={{ fontSize: "1.5rem", fontWeight: "600" }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            Satu Platform, Semua Solusi
          </motion.h3>
          
          <motion.p
            className="text-gray-300 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 1 }}
          >
            Dari eksplorasi virtual hingga analisis investasi cerdas, ARSAA DIMENSION menyatukan teknologi terdepan untuk memberdayakan setiap keputusan properti Anda.
          </motion.p>
        </motion.div>
      </div>
    </section>
  );
}