import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";

export default function LoadingScreen() {
  const [isLoading, setIsLoading] = useState(true);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Simulate loading progress
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setIsLoading(false), 500);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 100);

    return () => clearInterval(interval);
  }, []);

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          className="fixed inset-0 z-[9999] bg-[#0B0C10] flex items-center justify-center"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Animated Background */}
          <div className="absolute inset-0">
            {/* Particle effects */}
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-[#0D00FF]/40 rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                animate={{
                  scale: [0, 1, 0],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.1,
                  ease: "easeInOut",
                }}
              />
            ))}
          </div>

          {/* Loading Content */}
          <div className="relative z-10 text-center">
            {/* Logo Animation */}
            <motion.div
              className="mb-8"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
            >
              <motion.div
                className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-[#0D00FF] to-blue-400 flex items-center justify-center relative overflow-hidden"
                animate={{ rotate: 360 }}
                transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent" />
                <span className="text-white font-bold text-2xl relative z-10">A</span>
                
                {/* Holographic ring */}
                <motion.div
                  className="absolute inset-0 rounded-2xl border-2 border-[#0D00FF]/50"
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.5, 0.8, 0.5],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />
              </motion.div>
            </motion.div>

            {/* Title */}
            <motion.h1
              className="text-3xl sm:text-4xl font-atlantic-bold mb-2 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent tracking-wider"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
            >
              ARSAA DIMENSION
            </motion.h1>

            <motion.p
              className="text-gray-400 mb-8 text-lg"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
            >
              Initializing Future of Real Estate
            </motion.p>

            {/* Progress Bar */}
            <motion.div
              className="w-64 h-2 bg-white/10 rounded-full mx-auto mb-4 overflow-hidden"
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 0.8, delay: 0.9 }}
            >
              <motion.div
                className="h-full bg-gradient-to-r from-[#0D00FF] to-blue-400 rounded-full"
                style={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </motion.div>

            {/* Progress Text */}
            <motion.div
              className="text-[#0D00FF] font-semibold"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 1.1 }}
            >
              {Math.round(progress)}%
            </motion.div>

            {/* Loading States */}
            <motion.div
              className="mt-6 text-gray-500 text-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 1.3 }}
            >
              {progress < 30 && "Loading AR Engine..."}
              {progress >= 30 && progress < 60 && "Connecting to Blockchain..."}
              {progress >= 60 && progress < 90 && "Preparing AI Navigator..."}
              {progress >= 90 && "Almost Ready..."}
            </motion.div>
          </div>

          {/* Corner Elements */}
          <motion.div
            className="absolute top-8 left-8 w-8 h-8 border-l-2 border-t-2 border-[#0D00FF]/50"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 1.5 }}
          />
          <motion.div
            className="absolute top-8 right-8 w-8 h-8 border-r-2 border-t-2 border-[#0D00FF]/50"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 1.7 }}
          />
          <motion.div
            className="absolute bottom-8 left-8 w-8 h-8 border-l-2 border-b-2 border-[#0D00FF]/50"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 1.9 }}
          />
          <motion.div
            className="absolute bottom-8 right-8 w-8 h-8 border-r-2 border-b-2 border-[#0D00FF]/50"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 2.1 }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}