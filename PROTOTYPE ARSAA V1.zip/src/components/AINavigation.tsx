import React, { useState } from "react";
import { motion } from "motion/react";
import { Menu, X, Bot } from "lucide-react";
import ARSAALogo from "./ARSAALogo";

export default function AINavigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    { label: "Home", href: "#home" },
    { label: "Chat AI", href: "#chat" },
    { label: "Features", href: "#features" },
  ];

  return (
    <motion.nav
      className="fixed top-0 left-0 right-0 z-50 px-6 py-4"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
    >
      {/* Glassmorphism Background */}
      <div className="absolute inset-0 bg-[#0B0C10]/80 backdrop-blur-md border-b border-white/10" />
      
      <div className="relative z-10 max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.3 }}
        >
          <ARSAALogo size="md" variant="animated" showText={true} />
        </motion.div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          {menuItems.map((item) => (
            <motion.a
              key={item.label}
              href={item.href}
              className="text-gray-300 hover:text-[#0D00FF] transition-colors duration-300 relative group"
              whileHover={{ y: -2 }}
              transition={{ duration: 0.3 }}
            >
              {item.label}
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#0D00FF] transition-all duration-300 group-hover:w-full" />
            </motion.a>
          ))}
          
          {/* Start Chat Button */}
          <motion.a
            href="#chat"
            className="px-6 py-3 rounded-full bg-gradient-to-r from-[#0D00FF] to-blue-500 text-white flex items-center gap-2 hover:from-blue-500 hover:to-[#0D00FF] transition-all duration-300"
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
          >
            <Bot className="w-4 h-4" />
            Mulai Chat AI
          </motion.a>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center text-white"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <motion.div
          className="absolute top-full left-0 right-0 bg-[#0B0C10]/95 backdrop-blur-md border-b border-white/10 md:hidden"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="px-6 py-6 space-y-4">
            {menuItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="block text-gray-300 hover:text-[#0D00FF] transition-colors duration-300"
                onClick={() => setIsMenuOpen(false)}
              >
                {item.label}
              </a>
            ))}
            <a
              href="#chat"
              className="block px-6 py-3 rounded-full bg-gradient-to-r from-[#0D00FF] to-blue-500 text-white text-center mt-4"
              onClick={() => setIsMenuOpen(false)}
            >
              Mulai Chat AI
            </a>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
}