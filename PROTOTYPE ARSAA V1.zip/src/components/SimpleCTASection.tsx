import React from "react";
import { motion } from "motion/react";
import { ArrowRight, Smartphone, Globe } from "lucide-react";

export default function SimpleCTASection() {
  return (
    <section className="py-20 px-6 relative">
      {/* Simple Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0D00FF]/10 via-transparent to-[#0D00FF]/5" />
      
      <div className="max-w-4xl mx-auto relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {/* Icons */}
          <div className="flex justify-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl bg-[#0D00FF]/20 flex items-center justify-center">
              <Smartphone className="w-6 h-6 text-[#0D00FF]" />
            </div>
            <div className="w-12 h-12 rounded-xl bg-[#0D00FF]/20 flex items-center justify-center">
              <Globe className="w-6 h-6 text-[#0D00FF]" />
            </div>
          </div>

          {/* Heading */}
          <motion.h2
            className="mb-6 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-4xl md:text-5xl font-bold"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            Ready to Explore?
          </motion.h2>

          {/* Description */}
          <motion.p
            className="mb-8 text-gray-300 max-w-2xl mx-auto text-lg leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Join the future of real estate today. Experience properties like never before with AR, AI, and blockchain technology.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center mb-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <button className="px-8 py-4 rounded-xl bg-[#0D00FF] hover:bg-[#0D00FF]/90 transition-all duration-300 font-medium flex items-center gap-3 justify-center text-lg">
              Start Exploring
              <ArrowRight className="w-5 h-5" />
            </button>
            
            <button className="px-8 py-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 hover:border-[#0D00FF]/50 transition-all duration-300 font-medium">
              Learn More
            </button>
          </motion.div>

          {/* Simple Stats */}
          <motion.div
            className="flex flex-wrap justify-center gap-8 pt-8 border-t border-white/10"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            {[
              { value: "500+", label: "Properties" },
              { value: "1000+", label: "Users" },
              { value: "50+", label: "Partners" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl font-bold text-[#0D00FF] mb-1">
                  {stat.value}
                </div>
                <div className="text-gray-400 text-sm">
                  {stat.label}
                </div>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}