import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import Enhanced3DPropertyCard from "./Enhanced3DPropertyCard";
import { Search, Filter, Grid, List, Map, MapPin, TrendingUp } from "lucide-react";

const SAMPLE_PROPERTIES = [
  {
    id: "1",
    title: "Premium Villa Serpong",
    location: "Serpong, Tangerang Selatan",
    price: "Rp 4.8B",
    beds: 5,
    baths: 4,
    sqft: "420m²",
    image: "",
    type: "Villa",
    featured: true,
    district: "BSD City",
    nearbyLandmarks: "Aeon Mall, ICE BSD"
  },
  {
    id: "2",
    title: "Luxury Apartment Alam Sutera",
    location: "Alam Sutera, Tangerang Selatan",
    price: "Rp 2.9B",
    beds: 3,
    baths: 2,
    sqft: "145m²",
    image: "",
    type: "Apartment",
    district: "Alam Sutera",
    nearbyLandmarks: "Living World, Mall @ Alam Sutera"
  },
  {
    id: "3",
    title: "Smart Home BSD City",
    location: "BSD City, Tangerang Selatan",
    price: "Rp 5.2B",
    beds: 4,
    baths: 3,
    sqft: "380m²",
    image: "",
    type: "House",
    featured: true,
    district: "The Breeze",
    nearbyLandmarks: "AEON Mall, Prasetiya Mulya University"
  },
  {
    id: "4",
    title: "Executive Penthouse SCBD",
    location: "SCBD, Jakarta Selatan",
    price: "Rp 12.5B",
    beds: 4,
    baths: 4,
    sqft: "285m²",
    image: "",
    type: "Penthouse",
    district: "Sudirman Central Business District",
    nearbyLandmarks: "Pacific Place, fX Sudirman"
  },
  {
    id: "5",
    title: "Garden Residence Bintaro",
    location: "Bintaro Jaya, Tangerang Selatan",
    price: "Rp 3.7B",
    beds: 4,
    baths: 3,
    sqft: "285m²",
    image: "",
    type: "Townhouse",
    district: "Bintaro Jaya Sektor 9",
    nearbyLandmarks: "Bintaro Plaza, South Quarter"
  },
  {
    id: "6",
    title: "Eco Villa Gading Serpong",
    location: "Gading Serpong, Tangerang",
    price: "Rp 4.1B",
    beds: 5,
    baths: 4,
    sqft: "365m²",
    image: "",
    type: "Villa",
    district: "Summarecon Serpong",
    nearbyLandmarks: "Summarecon Mall Serpong, SMS"
  },
  {
    id: "7",
    title: "Modern Apartment Kemang",
    location: "Kemang, Jakarta Selatan",
    price: "Rp 3.5B",
    beds: 2,
    baths: 2,
    sqft: "125m²",
    image: "",
    type: "Apartment",
    district: "Kemang Village",
    nearbyLandmarks: "Kemang Village Mall, Radio Dalam"
  },
  {
    id: "8",
    title: "Luxury House Pondok Indah",
    location: "Pondok Indah, Jakarta Selatan",
    price: "Rp 8.9B",
    beds: 6,
    baths: 5,
    sqft: "520m²",
    image: "",
    type: "House",
    featured: true,
    district: "Pondok Indah",
    nearbyLandmarks: "Pondok Indah Mall, JIS"
  },
];

export default function PropertyShowcase() {
  const [viewMode, setViewMode] = useState<"grid" | "list" | "map">("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  const filteredProperties = SAMPLE_PROPERTIES.filter(property => {
    const matchesSearch = property.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         property.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = selectedFilter === "all" || property.type.toLowerCase() === selectedFilter.toLowerCase();
    return matchesSearch && matchesFilter;
  });

  return (
    <section className="py-20 px-6 relative">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0D00FF]/3 to-transparent" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2
            className="mb-6 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-3xl sm:text-4xl lg:text-6xl text-display"
          >
            Explore Properties
          </motion.h2>
          
          <motion.p
            className="text-gray-300 max-w-3xl mx-auto text-lg sm:text-xl"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            Prime real estate opportunities in South Tangerang and Jakarta's most prestigious districts
          </motion.p>

          {/* Market Stats */}
          <motion.div
            className="flex flex-wrap justify-center gap-6 mt-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            {[
              { label: "Properties Available", value: "250+", icon: MapPin },
              { label: "Average ROI", value: "12.5%", icon: TrendingUp },
              { label: "Districts Covered", value: "8", icon: Map },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                className="flex items-center gap-3 px-4 py-2 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20"
                whileHover={{ scale: 1.05, y: -2 }}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.7 + index * 0.1 }}
              >
                <stat.icon className="w-5 h-5 text-[#0D00FF]" />
                <div className="text-left">
                  <div className="text-white font-semibold">{stat.value}</div>
                  <div className="text-gray-400 text-sm">{stat.label}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Search and Filter Controls */}
        <motion.div
          className="mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-2xl">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search properties by name or location..."
                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 focus:border-[#0D00FF]/50 text-white placeholder-gray-400 outline-none transition-all duration-300"
              />
            </div>

            {/* Filter and View Controls */}
            <div className="flex items-center gap-4">
              {/* Filter Dropdown */}
              <motion.select
                value={selectedFilter}
                onChange={(e) => setSelectedFilter(e.target.value)}
                className="px-4 py-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 focus:border-[#0D00FF]/50 text-white outline-none transition-all duration-300"
                whileHover={{ scale: 1.02 }}
              >
                <option value="all" className="bg-gray-900">All Types</option>
                <option value="villa" className="bg-gray-900">Villa</option>
                <option value="apartment" className="bg-gray-900">Apartment</option>
                <option value="house" className="bg-gray-900">House</option>
                <option value="penthouse" className="bg-gray-900">Penthouse</option>
                <option value="townhouse" className="bg-gray-900">Townhouse</option>
              </motion.select>

              {/* View Mode Toggle */}
              <div className="flex items-center bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-1">
                {[
                  { mode: "grid" as const, icon: Grid },
                  { mode: "list" as const, icon: List },
                  { mode: "map" as const, icon: Map },
                ].map(({ mode, icon: Icon }) => (
                  <motion.button
                    key={mode}
                    onClick={() => setViewMode(mode)}
                    className={`p-2 rounded-lg transition-all duration-300 ${
                      viewMode === mode
                        ? "bg-[#0D00FF]/20 text-[#0D00FF]"
                        : "text-gray-400 hover:text-white hover:bg-white/10"
                    }`}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Icon className="w-5 h-5" />
                  </motion.button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Properties Grid */}
        {viewMode === "grid" && (
          <motion.div
            className={`grid gap-6 ${
              isMobile 
                ? "grid-cols-1" 
                : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
            }`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            {filteredProperties.map((property, index) => (
              <Enhanced3DPropertyCard
                key={property.id}
                property={property}
                index={index}
              />
            ))}
          </motion.div>
        )}

        {/* List View */}
        {viewMode === "list" && (
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            {filteredProperties.map((property, index) => (
              <motion.div
                key={property.id}
                className="flex flex-col md:flex-row bg-white/5 backdrop-blur-md border border-white/10 hover:border-[#0D00FF]/50 rounded-2xl overflow-hidden group transition-all duration-300"
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ scale: 1.01, y: -2 }}
              >
                <div className="w-full md:w-64 h-48 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-12 h-12 mx-auto mb-2 rounded-xl bg-[#0D00FF]/20 flex items-center justify-center">
                      <Search className="w-6 h-6 text-[#0D00FF]" />
                    </div>
                    <p className="text-gray-400 text-sm">Property Image</p>
                  </div>
                </div>
                
                <div className="flex-1 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-[#0D00FF] transition-colors duration-300">
                        {property.title}
                      </h3>
                      <p className="text-gray-400 mb-2">{property.location}</p>
                      <p className="text-2xl font-bold bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent">
                        {property.price}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="px-3 py-1 rounded-full bg-[#0D00FF]/20 text-[#0D00FF] text-sm font-semibold">
                        {property.type}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6 text-sm text-gray-400 mb-4">
                    <span>{property.beds} Beds</span>
                    <span>{property.baths} Baths</span>
                    <span>{property.sqft}</span>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <motion.button
                      className="px-6 py-2 rounded-xl bg-[#0D00FF]/20 text-[#0D00FF] hover:bg-[#0D00FF]/30 transition-all duration-300"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      View in AR
                    </motion.button>
                    <motion.button
                      className="px-6 py-2 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      Details
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Map View Placeholder */}
        {viewMode === "map" && (
          <motion.div
            className="h-96 rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 flex items-center justify-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-center">
              <Map className="w-16 h-16 mx-auto mb-4 text-[#0D00FF]" />
              <h3 className="text-xl font-semibold text-white mb-2">Interactive Map View</h3>
              <p className="text-gray-400">
                3D property locations with AR preview integration coming soon
              </p>
            </div>
          </motion.div>
        )}

        {/* No Results */}
        {filteredProperties.length === 0 && (
          <motion.div
            className="text-center py-20"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Search className="w-16 h-16 mx-auto mb-4 text-gray-600" />
            <h3 className="text-xl font-semibold text-white mb-2">No Properties Found</h3>
            <p className="text-gray-400">
              Try adjusting your search criteria or filters
            </p>
          </motion.div>
        )}
      </div>
    </section>
  );
}