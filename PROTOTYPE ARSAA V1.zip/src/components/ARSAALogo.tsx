import React from "react";
import { motion } from "motion/react";
import logoImage from "figma:asset/de1df166b4d0cabcdbd81af35fb0122e9aa72cd3.png";

interface ARSAALogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  variant?: "default" | "glow" | "animated" | "minimal";
  showText?: boolean;
  className?: string;
}

export default function ARSAALogo({ 
  size = "md", 
  variant = "default", 
  showText = true, 
  className = "" 
}: ARSAALogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16",
    xl: "w-24 h-24"
  };

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-2xl",
    xl: "text-4xl"
  };

  const logoElement = (
    <div className={`${sizeClasses[size]} relative flex items-center justify-center ${className}`}>
      {/* Futuristic Background Glow */}
      {(variant === "glow" || variant === "animated") && variant !== "minimal" && (
        <>
          <motion.div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#0D00FF]/30 via-cyan-500/20 to-purple-500/30 blur-xl"
            animate={variant === "animated" ? {
              scale: [1, 1.1, 1],
              opacity: [0.5, 0.8, 0.5],
            } : {}}
            transition={variant === "animated" ? {
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut"
            } : {}}
          />
          <motion.div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#0D00FF]/20 to-transparent"
            animate={variant === "animated" ? {
              rotate: [0, 360],
            } : {}}
            transition={variant === "animated" ? {
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            } : {}}
          />
        </>
      )}

      {/* Clean Logo Container - No Background */}
      <motion.div
        className="relative z-10 p-1 flex items-center justify-center"
        whileHover={variant === "animated" ? { 
          scale: 1.05
        } : {}}
        transition={{ duration: 0.3 }}
      >

        {/* Clean Logo Image - White Logo Only */}
        <motion.div
          className="relative w-full h-full flex items-center justify-center"
          animate={variant === "animated" ? {
            scale: [1, 1.05, 1]
          } : {}}
          transition={variant === "animated" ? {
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          } : {}}
        >
          <img
            src={logoImage}
            alt="ARSAA"
            className="w-full h-full object-contain"
            style={{
              filter: variant === "glow" ? "drop-shadow(0 0 10px rgba(13, 0, 255, 0.6)) brightness(1.1)" : 
                     variant === "animated" ? "drop-shadow(0 0 15px rgba(13, 0, 255, 0.8)) brightness(1.2)" : 
                     variant === "minimal" ? "brightness(1) contrast(1.1)" :
                     "brightness(1)",
              mixBlendMode: "normal"
            }}
          />
          
          {/* Subtle Glow Effect for Enhanced Variants */}
          {(variant === "glow" || variant === "animated") && (
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-[#0D00FF]/10 to-transparent rounded-full"
              animate={variant === "animated" ? {
                opacity: [0, 0.3, 0],
                scale: [0.8, 1.2, 0.8]
              } : {}}
              transition={variant === "animated" ? {
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              } : {}}
            />
          )}
        </motion.div>
      </motion.div>

      {/* Energy Particles */}
      {variant === "animated" && (
        <>
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-[#0D00FF] rounded-full"
              animate={{
                scale: [0, 1, 0],
                x: [0, Math.cos(i * 60 * Math.PI / 180) * 40],
                y: [0, Math.sin(i * 60 * Math.PI / 180) * 40],
                opacity: [0, 1, 0]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.3,
                ease: "easeOut"
              }}
            />
          ))}
        </>
      )}
    </div>
  );

  if (!showText) {
    return logoElement;
  }

  return (
    <motion.div 
      className="flex items-center gap-3"
      whileHover={variant === "animated" ? { scale: 1.02 } : {}}
      transition={{ duration: 0.3 }}
    >
      {logoElement}
      
      <div className="flex flex-col">
        <motion.span 
          className={`${textSizeClasses[size]} font-bold bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent leading-none`}
          animate={variant === "animated" ? {
            backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"]
          } : {}}
          transition={variant === "animated" ? {
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          } : {}}
          style={variant === "animated" ? {
            backgroundSize: "200% 100%"
          } : {}}
        >
          ARSAA
        </motion.span>
        
        <motion.span 
          className={`${size === "sm" ? "text-xs" : size === "md" ? "text-sm" : size === "lg" ? "text-base" : "text-lg"} text-gray-400 tracking-wider leading-none mt-1`}
          animate={variant === "animated" ? {
            opacity: [0.6, 1, 0.6]
          } : {}}
          transition={variant === "animated" ? {
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          } : {}}
        >
          DIMENSION
        </motion.span>
      </div>

      {/* Futuristic Text Glow */}
      {(variant === "glow" || variant === "animated") && (
        <motion.div
          className="absolute -inset-2 bg-gradient-to-r from-[#0D00FF]/10 via-transparent to-[#0D00FF]/10 rounded-2xl blur-xl"
          animate={variant === "animated" ? {
            opacity: [0.3, 0.6, 0.3],
            scale: [0.98, 1.02, 0.98]
          } : {}}
          transition={variant === "animated" ? {
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          } : {}}
        />
      )}
    </motion.div>
  );
}