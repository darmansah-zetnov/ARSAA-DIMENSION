import React from "react";
import { motion } from "motion/react";
import { Bot, Eye, Shield, BarChart3, Smartphone, Globe, Zap, Brain, Lock, TrendingUp } from "lucide-react";
import { SectionWrapper, FeatureGroup, ContentCard } from "./StructuredLayout";

// Fitur Utama - Teknologi Inti
const CORE_FEATURES = [
  {
    icon: Brain,
    title: "ARSAA AI Navigator",
    description: "Navigator properti cerdas dengan analisis pasar real-time dan rekomendasi yang dipersonalisasi menggunakan teknologi AI GPT-4.",
    highlight: "AI Powered",
    color: "from-[#0D00FF] to-blue-400"
  },
  {
    icon: Eye,
    title: "AR Property Showcase",
    description: "Tur properti imersif dengan visualisasi augmented reality, virtual staging, dan pengalaman 360° yang interaktif.",
    highlight: "AR/VR Ready",
    color: "from-purple-500 to-pink-400"
  },
  {
    icon: Shield,
    title: "Blockchain Ledger",
    description: "Transaksi aman dan transparan dengan teknologi Web3, smart contracts, dan sistem keamanan blockchain terintegrasi.",
    highlight: "Web3 Secure",
    color: "from-green-500 to-emerald-400"
  }
];

// Fitur Teknis - Kemampuan Platform
const TECHNICAL_FEATURES = [
  {
    icon: BarChart3,
    title: "Analitik Cerdas",
    description: "Wawasan berbasis data untuk keputusan investasi dan analisis tren pasar dengan machine learning.",
    stats: "98% Akurasi"
  },
  {
    icon: Smartphone,
    title: "Mobile First Design",
    description: "Pengalaman seamless di semua perangkat dengan desain responsif dan nuansa native.",
    stats: "100% Responsif"
  },
  {
    icon: Globe,
    title: "Fokus Regional Indonesia",
    description: "Spesialisasi di pasar properti premium Tangerang Selatan, Jakarta, dan area strategis lainnya.",
    stats: "8 Kawasan"
  }
];

// Fitur Premium - Teknologi Canggih
const PREMIUM_FEATURES = [
  {
    icon: Zap,
    title: "Real-time Processing",
    description: "Pemrosesan data real-time dengan kecepatan tinggi untuk analisis pasar instant.",
    badge: "Ultra Fast"
  },
  {
    icon: Lock,
    title: "Enterprise Security",
    description: "Keamanan tingkat enterprise dengan enkripsi end-to-end dan perlindungan data canggih.",
    badge: "Bank Level"
  },
  {
    icon: TrendingUp,
    title: "Predictive Analytics",
    description: "Analisis prediktif untuk forecasting harga properti dan tren investasi masa depan.",
    badge: "AI Forecast"
  }
];

export default function EnhancedFeaturesSection() {
  return (
    <SectionWrapper id="features" backgroundVariant="mesh" className="py-32">
      <FeatureGroup 
        title="Teknologi Revolusioner" 
        subtitle="Platform real estate Indonesia paling canggih dengan teknologi AI, AR, dan Blockchain terintegrasi"
      >
        {/* Core Features - Fitur Utama */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-20">
          {CORE_FEATURES.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="group"
            >
              <ContentCard className="h-full text-center group-hover:border-[#0D00FF]/70" hover glow>
                {/* Feature Icon */}
                <motion.div 
                  className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center`}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                >
                  <feature.icon className="w-8 h-8 text-white" />
                </motion.div>

                {/* Feature Badge */}
                <div className="mb-4">
                  <span className="px-3 py-1 rounded-full bg-[#0D00FF]/20 text-[#0D00FF] text-sm font-medium">
                    {feature.highlight}
                  </span>
                </div>

                {/* Feature Content */}
                <h3 className="text-xl font-semibold text-white mb-4 group-hover:text-[#0D00FF] transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="text-gray-300 leading-relaxed">
                  {feature.description}
                </p>

                {/* Hover Effect */}
                <motion.div
                  className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#0D00FF]/5 via-transparent to-[#0D00FF]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  initial={false}
                />
              </ContentCard>
            </motion.div>
          ))}
        </div>

        {/* Technical Features Grid */}
        <motion.div
          className="mb-20"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <h3 className="text-2xl font-semibold text-center text-white mb-8">
            Kemampuan Platform
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {TECHNICAL_FEATURES.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <ContentCard className="p-6 h-full">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-[#0D00FF]/20 flex items-center justify-center flex-shrink-0">
                      <feature.icon className="w-6 h-6 text-[#0D00FF]" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-white">{feature.title}</h4>
                        <span className="text-xs font-medium text-[#0D00FF] bg-[#0D00FF]/10 px-2 py-1 rounded-full">
                          {feature.stats}
                        </span>
                      </div>
                      <p className="text-gray-300 text-sm leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </ContentCard>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Premium Features */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <h3 className="text-2xl font-semibold text-center text-white mb-8">
            Teknologi Premium
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            {PREMIUM_FEATURES.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                className="group"
              >
                <ContentCard className="text-center h-full group-hover:bg-[#0D00FF]/5">
                  <div className="relative mb-4">
                    <div className="w-14 h-14 mx-auto rounded-xl bg-gradient-to-br from-[#0D00FF]/30 to-purple-500/30 flex items-center justify-center">
                      <feature.icon className="w-7 h-7 text-[#0D00FF]" />
                    </div>
                    <div className="absolute -top-2 -right-2">
                      <span className="px-2 py-1 rounded-full bg-gradient-to-r from-[#0D00FF] to-purple-500 text-white text-xs font-medium">
                        {feature.badge}
                      </span>
                    </div>
                  </div>
                  <h4 className="font-semibold text-white mb-3">{feature.title}</h4>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    {feature.description}
                  </p>
                </ContentCard>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Stats Section */}
        <motion.div
          className="flex flex-wrap justify-center gap-8 pt-8 border-t border-white/10"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          {[
            { value: "500+", label: "Properti Premium", sublabel: "Database terkurasi" },
            { value: "50+", label: "Developer Terpercaya", sublabel: "Partner strategis" },
            { value: "12.5%", label: "Rata-rata ROI", sublabel: "Return investasi" },
            { value: "24/7", label: "AI Support", sublabel: "Dukungan ARSAA" },
          ].map((stat, index) => (
            <motion.div 
              key={stat.label} 
              className="text-center group"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              <div className="text-3xl font-bold text-[#0D00FF] mb-1 group-hover:text-white transition-colors">
                {stat.value}
              </div>
              <div className="text-white font-medium mb-1">
                {stat.label}
              </div>
              <div className="text-gray-400 text-sm">
                {stat.sublabel}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </FeatureGroup>
    </SectionWrapper>
  );
}