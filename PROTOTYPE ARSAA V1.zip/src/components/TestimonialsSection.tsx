import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Star, ChevronLeft, ChevronRight } from "lucide-react";

const TESTIMONIALS = [
  {
    id: 1,
    name: "Budi Santoso",
    role: "Property Investor",
    company: "Jakarta Investment Group",
    avatar: "BS",
    rating: 5,
    text: "ARSAA DIMENSION mengubah cara saya berinvestasi properti. AI ARSAN memberikan analisis ROI yang akurat dan AR showcase membantu saya melihat potensi properti tanpa perlu ke lokasi.",
    highlight: "ROI analysis sangat akurat",
  },
  {
    id: 2,
    name: "Sari Dewi",
    role: "First-time Buyer",
    company: "Marketing Executive",
    avatar: "SD",
    rating: 5,
    text: "Sebagai pembeli pertama, saya merasa terbantu sekali dengan ARSAN yang menjelaskan detail properti dengan mudah. Fitur AR membantu saya visualisasi rumah impian sebelum membeli.",
    highlight: "AR visualization sangat membantu",
  },
  {
    id: 3,
    name: "Ahmad Rahman",
    role: "Property Agent",
    company: "Premium Realty",
    avatar: "AR",
    rating: 5,
    text: "Platform ini revolusioner! Klien saya sangat terkesan dengan AR tours dan blockchain transparency. Closing rate meningkat 40% sejak menggunakan ARSAA DIMENSION.",
    highlight: "Closing rate naik 40%",
  },
  {
    id: 4,
    name: "Linda Chen",
    role: "Developer",
    company: "Modern Living Corp",
    avatar: "LC",
    rating: 5,
    text: "Marketing properti jadi lebih efektif dengan AR showcase. Calon pembeli bisa merasakan pengalaman unit sebelum konstruksi selesai. Web3 ledger juga meningkatkan trust.",
    highlight: "Marketing lebih efektif",
  },
  {
    id: 5,
    name: "Teguh Wijaya",
    role: "Real Estate Consultant",
    company: "Property Solutions",
    avatar: "TW",
    rating: 5,
    text: "ARSAN AI sangat membantu dalam memberikan konsultasi yang data-driven kepada klien. Blockchain ledger memberikan transparansi yang dibutuhkan dalam industri properti.",
    highlight: "Konsultasi data-driven",
  },
];

export default function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  // Auto-play carousel
  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
    setIsAutoPlaying(false);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
    setIsAutoPlaying(false);
  };

  const goToTestimonial = (index: number) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
  };

  const currentTestimonial = TESTIMONIALS[currentIndex];

  return (
    <section className="py-20 px-6 relative">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#0D00FF]/5 to-transparent" />
      <div className="absolute top-1/4 left-10 w-72 h-72 bg-[#0D00FF]/8 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-10 w-64 h-64 bg-[#0D00FF]/6 rounded-full blur-3xl animate-pulse delay-1000" />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2
            className="mb-6 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent"
            style={{ fontSize: "3rem", fontWeight: "bold" }}
          >
            Testimoni Pengguna
          </motion.h2>
          
          <motion.p
            className="text-gray-300 max-w-3xl mx-auto"
            style={{ fontSize: "1.2rem" }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            Dengar langsung pengalaman pengguna yang telah merasakan revolusi properti dengan ARSAA DIMENSION
          </motion.p>
        </motion.div>

        {/* Main Testimonial Card */}
        <motion.div
          className="relative mb-12"
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="relative p-8 md:p-12 rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-500 overflow-hidden">
            
            {/* Glassmorphism Effects */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#0D00FF]/10 to-transparent opacity-50" />
            <div className="absolute inset-0 rounded-3xl shadow-[0_0_60px_rgba(13,0,255,0.2)]" />

            {/* Content */}
            <div className="relative z-10">
              {/* Rating */}
              <motion.div
                className="flex justify-center mb-6"
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                key={currentTestimonial.id}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <div className="flex gap-1">
                  {[...Array(currentTestimonial.rating)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.3, delay: i * 0.1 }}
                    >
                      <Star className="w-6 h-6 fill-[#0D00FF] text-[#0D00FF] drop-shadow-[0_0_10px_rgba(13,0,255,0.8)]" />
                    </motion.div>
                  ))}
                </div>
              </motion.div>

              {/* Testimonial Text */}
              <motion.blockquote
                className="text-center mb-8 text-gray-100 leading-relaxed max-w-4xl mx-auto"
                style={{ fontSize: "1.25rem" }}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                key={`${currentTestimonial.id}-text`}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                "{currentTestimonial.text}"
              </motion.blockquote>

              {/* Highlight */}
              <motion.div
                className="text-center mb-8"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                key={`${currentTestimonial.id}-highlight`}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <div className="inline-flex items-center px-4 py-2 rounded-full bg-[#0D00FF]/20 border border-[#0D00FF]/50">
                  <span className="text-[#0D00FF] font-semibold text-sm">
                    ✨ {currentTestimonial.highlight}
                  </span>
                </div>
              </motion.div>

              {/* Author Info */}
              <motion.div
                className="flex items-center justify-center gap-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                key={`${currentTestimonial.id}-author`}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                {/* Avatar with Futuristic Effect */}
                <div className="relative">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#0D00FF] to-blue-400 flex items-center justify-center shadow-[0_0_30px_rgba(13,0,255,0.5)]">
                    <span className="text-white font-bold text-lg">
                      {currentTestimonial.avatar}
                    </span>
                  </div>
                  
                  {/* Digital Profile Effect */}
                  <motion.div
                    className="absolute inset-0 rounded-full border-2 border-[#0D00FF]/50"
                    animate={{ 
                      scale: [1, 1.1, 1], 
                      opacity: [0.5, 0.8, 0.5] 
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                </div>

                {/* Author Details */}
                <div className="text-left">
                  <h4 className="text-white font-semibold text-lg">
                    {currentTestimonial.name}
                  </h4>
                  <p className="text-[#0D00FF] text-sm font-medium">
                    {currentTestimonial.role}
                  </p>
                  <p className="text-gray-400 text-sm">
                    {currentTestimonial.company}
                  </p>
                </div>
              </motion.div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute top-6 left-6 w-3 h-3 rounded-full bg-[#0D00FF]/40 animate-pulse" />
            <div className="absolute top-6 right-6 w-2 h-2 rounded-full bg-[#0D00FF]/60 animate-ping" />
            <div className="absolute bottom-6 left-6 w-4 h-4 rounded-full bg-[#0D00FF]/30 animate-bounce" />
          </div>

          {/* Navigation Controls */}
          <div className="absolute top-1/2 -translate-y-1/2 left-4 right-4 flex justify-between pointer-events-none">
            <motion.button
              onClick={prevTestimonial}
              className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 hover:border-[#0D00FF]/50 flex items-center justify-center group transition-all duration-300 pointer-events-auto"
              whileHover={{ scale: 1.1, x: -5 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronLeft className="w-6 h-6 text-gray-400 group-hover:text-[#0D00FF] transition-colors duration-300" />
            </motion.button>

            <motion.button
              onClick={nextTestimonial}
              className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 hover:border-[#0D00FF]/50 flex items-center justify-center group transition-all duration-300 pointer-events-auto"
              whileHover={{ scale: 1.1, x: 5 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronRight className="w-6 h-6 text-gray-400 group-hover:text-[#0D00FF] transition-colors duration-300" />
            </motion.button>
          </div>
        </motion.div>

        {/* Testimonial Indicators */}
        <motion.div
          className="flex justify-center gap-3 mb-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          {TESTIMONIALS.map((_, index) => (
            <motion.button
              key={index}
              onClick={() => goToTestimonial(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentIndex
                  ? "bg-[#0D00FF] shadow-[0_0_15px_rgba(13,0,255,0.8)]"
                  : "bg-white/30 hover:bg-white/50"
              }`}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.8 }}
            />
          ))}
        </motion.div>

        {/* Enhanced 3D Testimonial Grid Preview */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          {TESTIMONIALS.filter((_, index) => index !== currentIndex).slice(0, 3).map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              className="relative p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300 cursor-pointer group overflow-hidden"
              onClick={() => goToTestimonial(TESTIMONIALS.findIndex(t => t.id === testimonial.id))}
              whileHover={{ 
                scale: 1.02, 
                y: -8,
                rotateY: 5,
                rotateX: 2,
              }}
              initial={{ opacity: 0, y: 30, rotateY: -10 }}
              whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              style={{
                transformStyle: "preserve-3d",
                perspective: "1000px",
              }}
            >
              {/* 3D Shadow Effect */}
              <div className="absolute inset-0 rounded-2xl bg-black/20 transform translate-y-2 translate-x-2 -z-10 group-hover:translate-y-3 group-hover:translate-x-3 transition-transform duration-300" />
              
              {/* Holographic Background */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#0D00FF]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl" />
              
              {/* Floating Orb */}
              <motion.div
                className="absolute top-2 right-2 w-3 h-3 rounded-full bg-[#0D00FF]/40 blur-sm"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.4, 0.8, 0.4],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: index * 0.3,
                }}
              />

              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-4">
                  {/* Enhanced 3D Avatar */}
                  <motion.div
                    className="relative w-12 h-12 rounded-full bg-gradient-to-br from-gray-600 to-gray-800 group-hover:from-[#0D00FF] group-hover:to-blue-400 flex items-center justify-center transition-all duration-300"
                    whileHover={{ 
                      scale: 1.1,
                      rotateY: 15,
                    }}
                  >
                    <span className="text-white font-semibold">
                      {testimonial.avatar}
                    </span>
                    
                    {/* 3D Ring Effect */}
                    <motion.div
                      className="absolute inset-0 rounded-full border-2 border-[#0D00FF]/30"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                    />
                    
                    {/* Hologram Rings */}
                    <motion.div
                      className="absolute inset-0 rounded-full border border-[#0D00FF]/20"
                      animate={{
                        scale: [1, 1.3, 1],
                        opacity: [0.2, 0.6, 0.2],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                    />
                  </motion.div>
                  
                  <div>
                    <h5 className="text-white font-semibold group-hover:text-[#0D00FF] transition-colors duration-300">
                      {testimonial.name}
                    </h5>
                    <p className="text-gray-400 text-sm">{testimonial.role}</p>
                  </div>
                </div>
                
                <p className="text-gray-300 group-hover:text-white text-sm leading-relaxed line-clamp-3 mb-4 transition-colors duration-300">
                  {testimonial.text}
                </p>
                
                {/* Enhanced Star Rating */}
                <div className="flex gap-1">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.3, delay: i * 0.1 }}
                      whileHover={{ scale: 1.2 }}
                    >
                      <Star className="w-4 h-4 fill-[#0D00FF]/60 text-[#0D00FF]/60 group-hover:fill-[#0D00FF] group-hover:text-[#0D00FF] transition-colors duration-300" />
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Interactive Glow Border */}
              <motion.div
                className="absolute inset-0 rounded-2xl pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  background: `conic-gradient(from 0deg, transparent, rgba(13, 0, 255, 0.3), transparent)`,
                  padding: "1px",
                }}
                animate={{ rotate: 360 }}
                transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
              />

              {/* Corner Accents */}
              <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-[#0D00FF]/10 to-transparent rounded-tr-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-0 left-0 w-12 h-12 bg-gradient-to-tr from-[#0D00FF]/8 to-transparent rounded-bl-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}