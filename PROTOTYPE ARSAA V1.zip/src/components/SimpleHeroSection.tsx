import React from "react";
import { motion } from "motion/react";
import { ArrowRight, Play } from "lucide-react";
import ARSAALogo from "./ARSAALogo";

export default function SimpleHeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Simple Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0B0C10] via-[#1a1a2e] to-[#0B0C10]" />
      
      {/* Minimal Geometric Elements */}
      <div className="absolute top-20 left-20 w-64 h-64 bg-[#0D00FF]/10 rounded-full blur-2xl" />
      <div className="absolute bottom-20 right-20 w-48 h-48 bg-[#0D00FF]/8 rounded-full blur-2xl" />
      
      {/* Simple Grid Pattern */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `
            linear-gradient(rgba(13, 0, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(13, 0, 255, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px'
        }}
      />

      {/* Hero Content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Simple Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-[#0D00FF]/30 mb-8 backdrop-blur-sm">
            <div className="w-2 h-2 rounded-full bg-[#0D00FF] animate-pulse" />
            <span className="text-[#0D00FF] text-sm font-medium">
              Platform Properti Generasi Terbaru
            </span>
          </div>

          {/* Enhanced Logo Display */}
          <motion.div
            className="flex justify-center mb-8"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            <ARSAALogo size="xl" variant="animated" showText={true} />
          </motion.div>

          <motion.h1
            className="mb-6 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-3xl md:text-5xl font-bold"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.4 }}
          >
            Masa Depan Real Estate Indonesia
          </motion.h1>
          
          <motion.p
            className="mb-8 text-gray-300 max-w-2xl mx-auto text-lg leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Jelajahi properti impian dengan teknologi AR, AI, dan blockchain dalam satu platform revolusioner untuk masa depan investasi real estate Indonesia.
          </motion.p>

          {/* Simple CTA Buttons */}
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <button className="px-8 py-4 rounded-xl bg-[#0D00FF] hover:bg-[#0D00FF]/90 transition-all duration-300 font-medium flex items-center gap-3 justify-center">
              Mulai Jelajahi
              <ArrowRight className="w-5 h-5" />
            </button>
            
            <button className="px-8 py-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 hover:border-[#0D00FF]/50 transition-all duration-300 font-medium flex items-center gap-3 justify-center">
              <Play className="w-5 h-5" />
              Lihat Demo
            </button>
          </motion.div>

          {/* Simple Feature Tags */}
          <motion.div
            className="flex flex-wrap justify-center gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            {["AI Navigator", "Pengalaman AR", "Blockchain", "Analitik"].map((feature) => (
              <div
                key={feature}
                className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-gray-300 text-sm"
              >
                {feature}
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Simple Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1 }}
      >
        <div className="w-6 h-10 border-2 border-[#0D00FF]/50 rounded-full flex justify-center">
          <motion.div
            className="w-1 h-3 bg-[#0D00FF] rounded-full mt-2"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>
      </motion.div>
    </section>
  );
}