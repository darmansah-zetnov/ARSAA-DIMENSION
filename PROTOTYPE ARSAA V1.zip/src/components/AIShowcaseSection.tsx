import React, { useState } from "react";
import { motion } from "motion/react";
import { 
  Eye, 
  Brain, 
  Shield, 
  Play, 
  Pause, 
  Volume2, 
  Maximize, 
  RotateCcw,
  Zap,
  TrendingUp,
  MapPin,
  Camera
} from "lucide-react";

const AI_DEMOS = [
  {
    id: "ar-viewer",
    title: "AR Property Viewer",
    description: "Tur properti augmented reality yang imersif dengan kustomisasi real-time",
    icon: Eye,
    color: "from-blue-500 to-cyan-500",
    features: ["Tur Virtual 360°", "Kustomisasi Real-time", "Tools Pengukuran", "Simulasi Pencahayaan"]
  },
  {
    id: "ai-assistant",
    title: "ARSAA AI Assistant",
    description: "Navigator properti cerdas dengan pemrosesan bahasa natural",
    icon: Brain,
    color: "from-purple-500 to-pink-500",
    features: ["Query Bahasa Natural", "Analisis Pasar", "Wawasan Investasi", "Rekomendasi Personal"]
  },
  {
    id: "blockchain-ledger",
    title: "Blockchain Ledger",
    description: "Transaksi properti aman dan transparan dengan smart contracts",
    icon: Shield,
    color: "from-green-500 to-emerald-500",
    features: ["Smart Contracts", "Riwayat Transaksi", "Verifikasi Kepemilikan", "Pembayaran Aman"]
  }
];

export default function AIShowcaseSection() {
  const [activeDemo, setActiveDemo] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const currentDemo = AI_DEMOS[activeDemo];

  const renderARViewer = () => (
    <div className="relative h-96 rounded-2xl bg-gradient-to-br from-gray-900 to-gray-800 overflow-hidden">
      {/* AR Interface Overlay */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center">
          <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-[#0D00FF]/20 flex items-center justify-center">
            <Camera className="w-12 h-12 text-[#0D00FF]" />
          </div>
          <p className="text-white font-semibold mb-2">AR Property Viewer</p>
          <p className="text-gray-400 text-sm">Point your device to view property in AR</p>
        </div>
      </div>

      {/* AR UI Elements */}
      <div className="absolute top-4 left-4 flex gap-2">
        <div className="px-3 py-1 rounded-full bg-black/50 text-white text-sm backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            AR ACTIVE
          </div>
        </div>
      </div>

      <div className="absolute top-4 right-4 flex gap-2">
        <button className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
          <Volume2 className="w-5 h-5 text-white" />
        </button>
        <button className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
          <Maximize className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* AR Measurement Tools */}
      <div className="absolute bottom-4 left-4 right-4">
        <div className="flex justify-between items-end">
          <div className="bg-black/50 backdrop-blur-sm rounded-lg p-3">
            <div className="text-white text-sm mb-1">Room Dimensions</div>
            <div className="text-[#0D00FF] font-bold">4.2m × 3.8m</div>
          </div>
          
          <div className="flex gap-2">
            <button className="w-12 h-12 rounded-full bg-[#0D00FF] flex items-center justify-center">
              <RotateCcw className="w-6 h-6 text-white" />
            </button>
            <button className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Eye className="w-6 h-6 text-white" />
            </button>
          </div>
        </div>
      </div>

      {/* AR Grid Overlay */}
      <div className="absolute inset-0 opacity-20">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(13, 0, 255, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(13, 0, 255, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px'
          }}
        />
      </div>
    </div>
  );

  const renderAIAssistant = () => (
    <div className="relative h-96 rounded-2xl bg-gradient-to-br from-purple-900/50 to-pink-900/50 overflow-hidden">
      {/* AI Chat Interface */}
      <div className="p-6 h-full flex flex-col">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">ARSAN AI</h3>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-gray-400 text-sm">Processing market data...</span>
            </div>
          </div>
        </div>

        <div className="flex-1 space-y-3 overflow-y-hidden">
          <div className="flex justify-start">
            <div className="max-w-xs p-3 rounded-2xl bg-white/10 text-white">
              <p className="text-sm">Based on your preferences, I found 3 properties in BSD City with high ROI potential.</p>
            </div>
          </div>
          
          <div className="flex justify-end">
            <div className="max-w-xs p-3 rounded-2xl bg-[#0D00FF] text-white">
              <p className="text-sm">Show me the investment analysis for each property</p>
            </div>
          </div>
          
          <div className="flex justify-start">
            <div className="max-w-xs p-3 rounded-2xl bg-white/10 text-white">
              <div className="text-sm mb-2">Here's the detailed analysis:</div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span>Villa Serpong</span>
                  <span className="text-green-400">18.5% ROI</span>
                </div>
                <div className="flex justify-between">
                  <span>Smart Home BSD</span>
                  <span className="text-green-400">16.2% ROI</span>
                </div>
                <div className="flex justify-between">
                  <span>Garden Residence</span>
                  <span className="text-green-400">15.8% ROI</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* AI Processing Indicator */}
        <div className="flex items-center gap-2 mt-4">
          <div className="flex gap-1">
            <div className="w-2 h-2 rounded-full bg-purple-500 animate-bounce" />
            <div className="w-2 h-2 rounded-full bg-pink-500 animate-bounce delay-100" />
            <div className="w-2 h-2 rounded-full bg-purple-500 animate-bounce delay-200" />
          </div>
          <span className="text-gray-400 text-sm">AI is analyzing market trends...</span>
        </div>
      </div>
    </div>
  );

  const renderBlockchainLedger = () => (
    <div className="relative h-96 rounded-2xl bg-gradient-to-br from-green-900/50 to-emerald-900/50 overflow-hidden">
      {/* Blockchain Interface */}
      <div className="p-6 h-full">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Blockchain Ledger</h3>
              <p className="text-gray-400 text-sm">Decentralized Property Records</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-400 animate-pulse" />
            <span className="text-green-400 text-sm font-medium">Secured</span>
          </div>
        </div>

        {/* Transaction Blocks */}
        <div className="space-y-3">
          {[
            { id: "0x3f8a...7b2c", type: "Property Transfer", status: "Confirmed", time: "2 min ago" },
            { id: "0x9d4e...1a5f", type: "Smart Contract", status: "Pending", time: "5 min ago" },
            { id: "0x7c2b...8e9d", type: "Ownership Verification", status: "Confirmed", time: "12 min ago" },
          ].map((block, index) => (
            <motion.div
              key={block.id}
              className="p-4 rounded-xl bg-white/5 border border-green-500/20"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.2 }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="text-white font-medium text-sm">{block.type}</div>
                <div className={`px-2 py-1 rounded-full text-xs ${
                  block.status === 'Confirmed' 
                    ? 'bg-green-500/20 text-green-400' 
                    : 'bg-yellow-500/20 text-yellow-400'
                }`}>
                  {block.status}
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-gray-400 text-xs font-mono">{block.id}</div>
                <div className="text-gray-500 text-xs">{block.time}</div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Network Stats */}
        <div className="mt-6 grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-green-400 font-bold text-lg">99.9%</div>
            <div className="text-gray-400 text-xs">Uptime</div>
          </div>
          <div className="text-center">
            <div className="text-green-400 font-bold text-lg">2.3s</div>
            <div className="text-gray-400 text-xs">Block Time</div>
          </div>
          <div className="text-center">
            <div className="text-green-400 font-bold text-lg">1,247</div>
            <div className="text-gray-400 text-xs">Transactions</div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderDemo = () => {
    switch (activeDemo) {
      case 0: return renderARViewer();
      case 1: return renderAIAssistant();
      case 2: return renderBlockchainLedger();
      default: return renderARViewer();
    }
  };

  return (
    <section className="py-20 px-6 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0D00FF]/5 via-transparent to-[#0D00FF]/5" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[#0D00FF]/20 flex items-center justify-center">
              <Zap className="w-8 h-8 text-[#0D00FF]" />
            </div>
          </div>
          
          <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-4xl md:text-5xl font-bold">
            Interactive AI Demos
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            Experience the power of our AI-driven platform with live interactive demonstrations.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Demo Navigation */}
          <motion.div
            className="space-y-4"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            {AI_DEMOS.map((demo, index) => (
              <motion.button
                key={demo.id}
                onClick={() => setActiveDemo(index)}
                className={`w-full p-6 rounded-2xl text-left transition-all duration-300 ${
                  activeDemo === index
                    ? "bg-white/10 border border-[#0D00FF]/50"
                    : "bg-white/5 border border-white/10 hover:border-white/30"
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${demo.color} flex items-center justify-center flex-shrink-0`}>
                    <demo.icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className={`font-semibold mb-2 transition-colors duration-300 ${
                      activeDemo === index ? "text-[#0D00FF]" : "text-white"
                    }`}>
                      {demo.title}
                    </h3>
                    <p className="text-gray-400 text-sm leading-relaxed mb-3">
                      {demo.description}
                    </p>
                    <div className="space-y-1">
                      {demo.features.map((feature, idx) => (
                        <div key={idx} className="text-xs text-gray-500 flex items-center gap-2">
                          <div className="w-1 h-1 rounded-full bg-gray-500" />
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.button>
            ))}
          </motion.div>

          {/* Demo Viewer */}
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative">
              {/* Demo Content */}
              <motion.div
                key={activeDemo}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
              >
                {renderDemo()}
              </motion.div>

              {/* Demo Controls */}
              <div className="mt-6 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="w-12 h-12 rounded-full bg-[#0D00FF] hover:bg-[#0D00FF]/90 flex items-center justify-center transition-all duration-300"
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5 text-white" />
                    ) : (
                      <Play className="w-5 h-5 text-white ml-1" />
                    )}
                  </button>
                  <div className="text-white font-semibold">
                    {currentDemo.title}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {AI_DEMOS.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setActiveDemo(index)}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        activeDemo === index ? "bg-[#0D00FF]" : "bg-white/30 hover:bg-white/50"
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Feature Statistics */}
        <motion.div
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          {[
            { icon: Eye, value: "98%", label: "AR Accuracy", desc: "Precise virtual tours" },
            { icon: Brain, value: "2.1s", label: "AI Response", desc: "Lightning fast queries" },
            { icon: Shield, value: "100%", label: "Secure", desc: "Blockchain protected" },
            { icon: TrendingUp, value: "85%", label: "Success Rate", desc: "Investment predictions" },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              className="text-center p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <stat.icon className="w-8 h-8 text-[#0D00FF] mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-[#0D00FF] font-medium text-sm mb-1">{stat.label}</div>
              <div className="text-gray-400 text-xs">{stat.desc}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}