import React, { useState } from "react";
import { motion } from "motion/react";
import { Bot, Eye, Shield, Play, Camera, Hash, MessageSquare } from "lucide-react";

const DEMO_TABS = [
  {
    id: "ai",
    title: "ARSAN AI Chatbot",
    icon: Bot,
    description: "Pengalaman AI Navigator dengan NLU",
  },
  {
    id: "ar",
    title: "AR Property Viewer",
    icon: Eye,
    description: "WebXR immersive property experience",
  },
  {
    id: "blockchain",
    title: "Blockchain Ledger",
    icon: Shield,
    description: "Transparent property transaction history",
  },
];

export default function ShowcaseSection() {
  const [activeTab, setActiveTab] = useState("ai");

  const renderDemo = () => {
    switch (activeTab) {
      case "ai":
        return <AIChatbotDemo />;
      case "ar":
        return <ARViewerDemo />;
      case "blockchain":
        return <BlockchainDemo />;
      default:
        return <AIChatbotDemo />;
    }
  };

  return (
    <section className="py-20 px-6 relative">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B0C10] via-[#0D00FF]/5 to-[#0B0C10]" />
      <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-96 h-96 bg-[#0D00FF]/10 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2
            className="mb-6 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent"
            style={{ fontSize: "3rem", fontWeight: "bold" }}
          >
            Demo Teknologi
          </motion.h2>
          
          <motion.p
            className="text-gray-300 max-w-3xl mx-auto"
            style={{ fontSize: "1.2rem" }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            Rasakan sendiri kekuatan teknologi AI, AR, dan Blockchain dalam satu platform terintegrasi
          </motion.p>
        </motion.div>

        {/* Demo Tabs */}
        <motion.div
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {DEMO_TABS.map((tab, index) => (
            <motion.button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`relative px-6 py-4 rounded-2xl backdrop-blur-md border transition-all duration-300 group ${
                activeTab === tab.id
                  ? "bg-[#0D00FF]/20 border-[#0D00FF] shadow-[0_0_30px_rgba(13,0,255,0.3)]"
                  : "bg-white/5 border-white/10 hover:border-[#0D00FF]/50"
              }`}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
                  activeTab === tab.id ? "bg-[#0D00FF]/30" : "bg-white/10 group-hover:bg-[#0D00FF]/20"
                }`}>
                  <tab.icon className={`w-5 h-5 transition-colors duration-300 ${
                    activeTab === tab.id ? "text-[#0D00FF]" : "text-gray-400 group-hover:text-[#0D00FF]"
                  }`} />
                </div>
                <div className="text-left">
                  <h4 className={`transition-colors duration-300 ${
                    activeTab === tab.id ? "text-[#0D00FF]" : "text-white group-hover:text-[#0D00FF]"
                  }`} style={{ fontSize: "1rem", fontWeight: "600" }}>
                    {tab.title}
                  </h4>
                  <p className="text-gray-400 text-sm">{tab.description}</p>
                </div>
              </div>
              
              {activeTab === tab.id && (
                <motion.div
                  className="absolute inset-0 rounded-2xl bg-gradient-to-r from-[#0D00FF]/10 via-[#0D00FF]/5 to-[#0D00FF]/10"
                  layoutId="activeTab"
                  transition={{ duration: 0.3 }}
                />
              )}
            </motion.button>
          ))}
        </motion.div>

        {/* Demo Container */}
        <motion.div
          className="relative rounded-3xl bg-white/5 backdrop-blur-md border border-[#0D00FF]/30 overflow-hidden"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-[#0D00FF]/10 to-transparent" />
          
          {/* Demo Content */}
          <div className="relative z-10 p-8">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.5 }}
            >
              {renderDemo()}
            </motion.div>
          </div>

          {/* Glow Effects */}
          <div className="absolute top-0 left-0 w-32 h-32 bg-[#0D00FF]/20 rounded-full blur-2xl animate-pulse" />
          <div className="absolute bottom-0 right-0 w-24 h-24 bg-[#0D00FF]/15 rounded-full blur-xl animate-pulse delay-1000" />
        </motion.div>
      </div>
    </section>
  );
}

// AI Chatbot Demo Component
function AIChatbotDemo() {
  const [messages, setMessages] = useState([
    { type: "bot", text: "👋 Halo! Saya ARSAN, AI Navigator ARSAA DIMENSION. Bagaimana saya bisa membantu Anda mencari properti impian?" },
  ]);

  const [inputValue, setInputValue] = useState("");

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const newMessages = [
      ...messages,
      { type: "user", text: inputValue },
    ];

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "🏡 Berdasarkan preferensi Anda, saya menemukan 12 properti yang cocok di area Jakarta Selatan dengan ROI proyeksi 15% per tahun.",
        "📊 Analisis pasar menunjukkan trend positif untuk investasi apartemen di area tersebut. Apakah Anda ingin melihat virtual tour 360°?",
        "🔍 Saya telah menganalisis 50+ faktor termasuk aksesibilitas, fasilitas, dan potensi appreciation. Properti terbaik tersedia untuk viewing AR.",
      ];
      
      setMessages(prev => [
        ...prev,
        { type: "bot", text: responses[Math.floor(Math.random() * responses.length)] }
      ]);
    }, 1000);

    setMessages(newMessages);
    setInputValue("");
  };

  return (
    <div className="space-y-6">
      {/* 3D Hologram Avatar */}
      <motion.div
        className="flex justify-center mb-8"
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#0D00FF] to-blue-400 flex items-center justify-center">
            <Bot className="w-12 h-12 text-white" />
            
            {/* Hologram Effects */}
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-[#0D00FF]/50"
              animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-[#0D00FF]/30"
              animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0, 0.3] }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
            />
          </div>
          
          <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 text-[#0D00FF] text-sm font-semibold">
            ARSAN
          </div>
        </div>
      </motion.div>

      {/* Chat Messages */}
      <div className="h-64 overflow-y-auto space-y-4 p-4 rounded-2xl bg-black/20 backdrop-blur-sm">
        {messages.map((message, index) => (
          <motion.div
            key={index}
            className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <div className={`max-w-[80%] p-4 rounded-2xl ${
              message.type === "user"
                ? "bg-[#0D00FF]/20 text-white rounded-br-md"
                : "bg-white/10 text-gray-100 rounded-bl-md"
            }`}>
              <p className="text-sm leading-relaxed">{message.text}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Input Area */}
      <div className="flex gap-3">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
          placeholder="Tanyakan tentang properti impian Anda..."
          className="flex-1 p-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 focus:border-[#0D00FF]/50 text-white placeholder-gray-400 outline-none transition-all duration-300"
        />
        <motion.button
          onClick={handleSendMessage}
          className="px-6 py-4 rounded-2xl bg-[#0D00FF]/20 border border-[#0D00FF]/50 hover:bg-[#0D00FF]/30 transition-all duration-300"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <MessageSquare className="w-5 h-5 text-[#0D00FF]" />
        </motion.button>
      </div>
    </div>
  );
}

// AR Viewer Demo Component
function ARViewerDemo() {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h3 className="text-2xl mb-4 text-[#0D00FF]">AR Property Experience</h3>
        <p className="text-gray-300">Lihat properti dalam realitas augmented langsung dari browser Anda</p>
      </div>

      {/* 3D Property Viewer */}
      <div className="relative h-96 rounded-2xl bg-black/30 backdrop-blur-sm border border-[#0D00FF]/30 overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            className="relative"
            animate={{ rotateY: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <div className="w-32 h-32 bg-gradient-to-br from-[#0D00FF] to-cyan-400 rounded-lg transform rotate-12 shadow-2xl">
              <div className="absolute inset-2 bg-white/10 rounded-md" />
              <div className="absolute inset-4 bg-white/20 rounded-sm" />
            </div>
          </motion.div>
        </div>

        {/* AR Controls */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-4">
          <motion.button
            className="px-4 py-2 rounded-xl bg-[#0D00FF]/20 border border-[#0D00FF]/50 text-white text-sm hover:bg-[#0D00FF]/30 transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Camera className="w-4 h-4 inline mr-2" />
            View in AR
          </motion.button>
          
          <motion.button
            className="px-4 py-2 rounded-xl bg-white/10 border border-white/20 text-white text-sm hover:bg-white/20 transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Play className="w-4 h-4 inline mr-2" />
            360° Tour
          </motion.button>
        </div>

        {/* Floating Info Cards */}
        <motion.div
          className="absolute top-4 left-4 p-3 rounded-xl bg-white/10 backdrop-blur-sm border border-[#0D00FF]/30"
          animate={{ y: [-10, 10, -10] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        >
          <p className="text-xs text-white">🏠 Villa Modern</p>
          <p className="text-xs text-[#0D00FF]">Rp 2.5M</p>
        </motion.div>

        <motion.div
          className="absolute top-4 right-4 p-3 rounded-xl bg-white/10 backdrop-blur-sm border border-[#0D00FF]/30"
          animate={{ y: [10, -10, 10] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        >
          <p className="text-xs text-white">📍 Jakarta Selatan</p>
          <p className="text-xs text-green-400">Available</p>
        </motion.div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {["Bedroom", "Bathroom", "Living Room"].map((room, index) => (
          <motion.button
            key={room}
            className="p-4 rounded-xl bg-white/10 hover:bg-[#0D00FF]/20 border border-white/20 hover:border-[#0D00FF]/50 transition-all duration-300 text-center"
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <p className="text-white text-sm">{room}</p>
            <p className="text-[#0D00FF] text-xs">View AR</p>
          </motion.button>
        ))}
      </div>
    </div>
  );
}

// Blockchain Demo Component
function BlockchainDemo() {
  const transactions = [
    { id: "0x1a2b", type: "Property Listed", time: "2024-01-15", status: "Verified" },
    { id: "0x2c3d", type: "Ownership Transfer", time: "2024-01-20", status: "Confirmed" },
    { id: "0x4e5f", type: "Price Update", time: "2024-01-25", status: "Verified" },
    { id: "0x6g7h", type: "Inspection Report", time: "2024-01-30", status: "Pending" },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h3 className="text-2xl mb-4 text-[#0D00FF]">Blockchain Property Ledger</h3>
        <p className="text-gray-300">Transparent and immutable property transaction history</p>
      </div>

      {/* Blockchain Visualization */}
      <div className="relative">
        <div className="flex items-center justify-between mb-6">
          {transactions.map((tx, index) => (
            <React.Fragment key={tx.id}>
              <motion.div
                className="relative"
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                {/* Block */}
                <div className={`w-16 h-16 rounded-lg flex items-center justify-center border-2 transition-all duration-300 ${
                  tx.status === "Verified" || tx.status === "Confirmed"
                    ? "bg-[#0D00FF]/20 border-[#0D00FF]"
                    : "bg-orange-500/20 border-orange-500"
                }`}>
                  <Hash className="w-6 h-6 text-white" />
                </div>

                {/* Hash */}
                <p className="text-xs text-center mt-2 text-gray-400">{tx.id}</p>

                {/* Connection Line */}
                {index < transactions.length - 1 && (
                  <motion.div
                    className="absolute top-8 left-16 w-8 h-0.5 bg-[#0D00FF]/50"
                    initial={{ width: 0 }}
                    animate={{ width: 32 }}
                    transition={{ duration: 0.5, delay: index * 0.2 + 0.3 }}
                  />
                )}

                {/* Animation Effects */}
                <motion.div
                  className="absolute inset-0 rounded-lg ring-2 ring-[#0D00FF]/30"
                  animate={{ 
                    scale: [1, 1.1, 1],
                    opacity: [0.3, 0.6, 0.3] 
                  }}
                  transition={{ 
                    duration: 2, 
                    repeat: Infinity, 
                    delay: index * 0.5 
                  }}
                />
              </motion.div>
            </React.Fragment>
          ))}
        </div>

        {/* Transaction Details */}
        <div className="space-y-3">
          {transactions.map((tx, index) => (
            <motion.div
              key={tx.id}
              className="p-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 hover:border-[#0D00FF]/50 transition-all duration-300"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-white text-sm font-semibold">{tx.type}</h4>
                  <p className="text-gray-400 text-xs">Hash: {tx.id} • {tx.time}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs ${
                  tx.status === "Verified" || tx.status === "Confirmed"
                    ? "bg-[#0D00FF]/20 text-[#0D00FF]"
                    : "bg-orange-500/20 text-orange-400"
                }`}>
                  {tx.status}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Real-time Mining Animation */}
        <motion.div
          className="mt-6 p-4 rounded-xl bg-green-500/10 border border-green-500/30"
          animate={{ 
            borderColor: ["rgba(34,197,94,0.3)", "rgba(34,197,94,0.6)", "rgba(34,197,94,0.3)"] 
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="flex items-center gap-3">
            <motion.div
              className="w-3 h-3 rounded-full bg-green-500"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <p className="text-green-400 text-sm">New block being mined... Estimated time: 2 minutes</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}