import React from "react";
import { motion } from "motion/react";
import { Bot, Eye, Shield, BarChart3, Smartphone, Globe } from "lucide-react";

const FEATURES = [
  {
    icon: Bot,
    title: "ARSAA AI",
    description: "Navigator properti cerdas dengan analisis pasar real-time dan rekomendasi yang dipersonalisasi.",
  },
  {
    icon: Eye,
    title: "AR Showcase",
    description: "Tur properti imersif dengan visualisasi augmented reality dan virtual staging.",
  },
  {
    icon: Shield,
    title: "Blockchain Ledger",
    description: "Transaksi aman dan transparan dengan teknologi Web3 dan smart contracts.",
  },
  {
    icon: BarChart3,
    title: "Analitik Cerdas",
    description: "Wawasan berbasis data untuk keputusan investasi dan analisis tren pasar.",
  },
  {
    icon: Smartphone,
    title: "Mobile First",
    description: "Pengalaman seamless di semua perangkat dengan desain responsif dan nuansa native.",
  },
  {
    icon: Globe,
    title: "Fokus Regional",
    description: "Spesialisasi di pasar properti premium Tangerang Selatan dan Jakarta.",
  },
];

export default function SimpleFeaturesSection() {
  return (
    <section className="py-20 px-6 relative">
      {/* Simple Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0D00FF]/3 to-transparent" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-4xl md:text-5xl font-bold">
            Fitur Platform
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            Teknologi canggih yang mendorong masa depan real estate Indonesia
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {FEATURES.map((feature, index) => (
            <motion.div
              key={feature.title}
              className="relative p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300 group"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              {/* Icon */}
              <div className="w-12 h-12 rounded-xl bg-[#0D00FF]/20 flex items-center justify-center mb-4 group-hover:bg-[#0D00FF]/30 transition-colors duration-300">
                <feature.icon className="w-6 h-6 text-[#0D00FF]" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-[#0D00FF] transition-colors duration-300">
                {feature.title}
              </h3>
              <p className="text-gray-300 leading-relaxed">
                {feature.description}
              </p>

              {/* Subtle Border Effect */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-transparent via-[#0D00FF]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
            </motion.div>
          ))}
        </div>

        {/* Bottom Stats */}
        <motion.div
          className="flex flex-wrap justify-center gap-8 mt-16 pt-8 border-t border-white/10"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          {[
            { value: "500+", label: "Properti" },
            { value: "50+", label: "Developer" },
            { value: "12.5%", label: "Rata-rata ROI" },
            { value: "8", label: "Kawasan" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl font-bold text-[#0D00FF] mb-1">
                {stat.value}
              </div>
              <div className="text-gray-400 text-sm">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}