import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Bot, MessageSquare, Search, TrendingUp, MapPin, DollarSign, Send, Mic, Home, Calendar } from "lucide-react";
import { projectId, publicAnonKey } from '../utils/supabase/info';

const AI_RESPONSES = [
  {
    query: "Cari properti mewah di BSD City di bawah 5M",
    response: "Saya menemukan 12 properti mewah di BSD City di bawah Rp 5M. Berikut rekomendasi terbaik berdasarkan preferensi Anda:",
    properties: ["Premium Villa Serpong - Rp 4.8M", "Smart Home BSD - Rp 4.2M", "Garden Residence - Rp 3.9M"]
  },
  {
    query: "Bagaimana potensi ROI untuk Alam Sutera?",
    response: "Alam Sutera menunjukkan potensi ROI yang kuat dengan pertumbuhan rata-rata 12.5% per tahun. Faktor kunci: kedekatan dengan kawasan bisnis, pengembangan infrastruktur, dan nilai properti yang terus naik.",
    insights: ["Area dengan permintaan tinggi", "Infrastruktur berkembang", "ROI rata-rata 12.5%"]
  },
  {
    query: "Tunjukkan peluang investasi di Jakarta",
    response: "Berdasarkan analisis pasar, saya merekomendasikan area berpotensi tinggi di Jakarta dengan proyeksi return 15-20%:",
    areas: ["Kawasan SCBD", "Area Kemang", "Pondok Indah"]
  }
];

export default function AINavigatorSection() {
  const [currentDemo, setCurrentDemo] = useState(0);
  const [isTyping, setIsTyping] = useState(false);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [propertyRecommendations, setPropertyRecommendations] = useState([]);
  const [marketInsights, setMarketInsights] = useState([]);
  const [chatMessages, setChatMessages] = useState([
    {
      type: "ai",
      message: "Halo! Saya ARSAA, navigator properti AI canggih Anda. Saya dapat menganalisis pasar real estate, memberikan wawasan investasi, dan menemukan properti yang sesuai dengan kriteria Anda. Bagaimana saya bisa membantu Anda hari ini?",
      timestamp: new Date().toLocaleTimeString(),
      enhanced: true
    }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentDemo((prev) => (prev + 1) % AI_RESPONSES.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  // Advanced AI chat handler
  const handleSendMessage = async () => {
    if (!userInput.trim() || isLoading) return;
    
    const newUserMessage = {
      type: "user",
      message: userInput,
      timestamp: new Date().toLocaleTimeString()
    };

    setChatMessages(prev => [...prev, newUserMessage]);
    const currentInput = userInput;
    setUserInput("");
    setIsTyping(true);
    setIsLoading(true);

    try {
      // Call advanced AI backend
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-58f5cb12/ai-chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          message: currentInput,
          chatHistory: chatMessages.slice(-5) // Send last 5 messages for context
        })
      });

      if (!response.ok) {
        throw new Error('AI service unavailable');
      }

      const data = await response.json();
      
      // Update chat with AI response
      const aiResponse = {
        type: "ai",
        message: data.response,
        timestamp: data.timestamp || new Date().toLocaleTimeString(),
        searchResults: data.searchResults,
        marketInsights: data.marketInsights,
        enhanced: true
      };

      setChatMessages(prev => [...prev, aiResponse]);
      
      // Update recommendations and insights if available
      if (data.searchResults?.length > 0) {
        setPropertyRecommendations(data.searchResults);
      }
      if (data.marketInsights?.length > 0) {
        setMarketInsights(data.marketInsights);
      }

    } catch (error) {
      console.error('AI Chat Error:', error);
      
      // Fallback response
      const fallbackResponse = {
        type: "ai",
        message: "I apologize, but I'm experiencing some connectivity issues. However, I can still help you with property searches and market analysis. Could you please rephrase your question?",
        timestamp: new Date().toLocaleTimeString(),
        error: true
      };
      
      setChatMessages(prev => [...prev, fallbackResponse]);
    } finally {
      setIsTyping(false);
      setIsLoading(false);
    }
  };

  // Load initial recommendations
  useEffect(() => {
    const loadRecommendations = async () => {
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-58f5cb12/recommendations?budget=5000000000&location=tangerang`, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          setPropertyRecommendations(data.recommendations.slice(0, 3));
        }
      } catch (error) {
        console.error('Failed to load recommendations:', error);
      }
    };

    loadRecommendations();
  }, []);

  return (
    <section className="py-20 px-6 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0D00FF]/5 via-transparent to-[#0D00FF]/5" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[#0D00FF]/20 flex items-center justify-center">
              <Bot className="w-8 h-8 text-[#0D00FF]" />
            </div>
          </div>
          
          <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent text-4xl md:text-5xl font-bold">
            Kenali ARSAA AI
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            Navigator properti cerdas Anda yang didukung AI canggih. Dapatkan rekomendasi personal, wawasan pasar, dan analisis investasi.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* AI Chat Interface */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
              {/* Chat Header */}
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/10">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0D00FF] to-blue-400 flex items-center justify-center">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">ARSAA AI</h3>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                    <span className="text-gray-400 text-sm">Aktif</span>
                  </div>
                </div>
              </div>

              {/* Enhanced Chat Messages */}
              <div className="h-64 overflow-y-auto mb-4 space-y-4">
                {chatMessages.map((msg, index) => (
                  <motion.div
                    key={index}
                    className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className={`max-w-sm px-4 py-3 rounded-2xl ${
                      msg.type === 'user' 
                        ? 'bg-[#0D00FF] text-white ml-4' 
                        : msg.enhanced 
                          ? 'bg-gradient-to-br from-white/10 to-white/5 border border-[#0D00FF]/20 text-gray-100 mr-4'
                          : 'bg-white/10 text-gray-100 mr-4'
                    }`}>
                      <p className="text-sm leading-relaxed">{msg.message}</p>
                      
                      {/* Show property results if available */}
                      {msg.searchResults && msg.searchResults.length > 0 && (
                        <div className="mt-3 space-y-2">
                          {msg.searchResults.slice(0, 2).map((property, idx) => (
                            <div key={idx} className="p-2 rounded-lg bg-[#0D00FF]/10 border border-[#0D00FF]/30">
                              <div className="flex items-center gap-2 mb-1">
                                <Home className="w-3 h-3 text-[#0D00FF]" />
                                <span className="text-xs font-medium text-[#0D00FF]">{property.name}</span>
                              </div>
                              <p className="text-xs text-gray-300">{property.location}</p>
                              <div className="flex justify-between mt-1">
                                <span className="text-xs text-gray-400">Rp {(property.price / 1000000000).toFixed(1)}B</span>
                                <span className="text-xs text-green-400">{property.roi}% ROI</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {/* Show market insights if available */}
                      {msg.marketInsights && msg.marketInsights.length > 0 && (
                        <div className="mt-3 space-y-1">
                          {msg.marketInsights.slice(0, 2).map((insight, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-xs">
                              <TrendingUp className="w-3 h-3 text-green-400" />
                              <span className="text-green-400">{insight.area}: {insight.growth}% growth</span>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      <span className="text-xs opacity-70 mt-2 block">{msg.timestamp}</span>
                    </div>
                  </motion.div>
                ))}
                
                {isTyping && (
                  <motion.div
                    className="flex justify-start"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    <div className="max-w-xs px-4 py-3 rounded-2xl bg-white/10 text-gray-100 mr-4">
                      <div className="flex gap-1 items-center">
                        <div className="w-2 h-2 rounded-full bg-[#0D00FF] animate-bounce" />
                        <div className="w-2 h-2 rounded-full bg-[#0D00FF] animate-bounce delay-100" />
                        <div className="w-2 h-2 rounded-full bg-[#0D00FF] animate-bounce delay-200" />
                        <span className="text-xs text-gray-400 ml-2">ARSAA sedang menganalisis...</span>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Chat Input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Tanya tentang properti, tren pasar, atau investasi..."
                  className="flex-1 px-4 py-3 rounded-xl bg-white/10 border border-white/20 focus:border-[#0D00FF]/50 text-white placeholder-gray-400 outline-none transition-all duration-300"
                />
                <button
                  onClick={handleSendMessage}
                  disabled={isLoading}
                  className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300 ${
                    isLoading 
                      ? 'bg-gray-500 cursor-not-allowed' 
                      : 'bg-[#0D00FF] hover:bg-[#0D00FF]/90'
                  }`}
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Send className="w-5 h-5 text-white" />
                  )}
                </button>
                <button className="w-12 h-12 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all duration-300">
                  <Mic className="w-5 h-5 text-gray-400" />
                </button>
              </div>
            </div>
          </motion.div>

          {/* AI Capabilities */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            {/* Live Demo */}
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
              <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-[#0D00FF]" />
                Live AI Demo
              </h3>
              
              <motion.div
                key={currentDemo}
                className="space-y-3"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="p-3 rounded-xl bg-[#0D00FF]/10 border border-[#0D00FF]/30">
                  <p className="text-gray-300 text-sm mb-2">Query:</p>
                  <p className="text-white">{AI_RESPONSES[currentDemo].query}</p>
                </div>
                
                <div className="p-3 rounded-xl bg-white/10">
                  <p className="text-gray-300 text-sm mb-2">AI Response:</p>
                  <p className="text-white text-sm leading-relaxed">{AI_RESPONSES[currentDemo].response}</p>
                  
                  {AI_RESPONSES[currentDemo].properties && (
                    <div className="mt-3 space-y-1">
                      {AI_RESPONSES[currentDemo].properties.map((prop, idx) => (
                        <div key={idx} className="text-[#0D00FF] text-sm">• {prop}</div>
                      ))}
                    </div>
                  )}
                  
                  {AI_RESPONSES[currentDemo].insights && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {AI_RESPONSES[currentDemo].insights.map((insight, idx) => (
                        <span key={idx} className="px-2 py-1 rounded-full bg-[#0D00FF]/20 text-[#0D00FF] text-xs">
                          {insight}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            </div>

            {/* Real-time Property Recommendations */}
            {propertyRecommendations.length > 0 && (
              <div className="mb-6 p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Home className="w-5 h-5 text-[#0D00FF]" />
                  Rekomendasi Properti AI
                </h3>
                <div className="space-y-3">
                  {propertyRecommendations.slice(0, 3).map((property, index) => (
                    <motion.div
                      key={property.id}
                      className="p-4 rounded-xl bg-gradient-to-r from-[#0D00FF]/5 to-transparent border border-[#0D00FF]/20 hover:border-[#0D00FF]/40 transition-all duration-300"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      whileHover={{ x: 4 }}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="text-white font-medium text-sm">{property.name}</h4>
                        <span className="text-[#0D00FF] text-xs font-semibold">{property.roi}% ROI</span>
                      </div>
                      <p className="text-gray-400 text-xs mb-2">{property.location}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-white text-sm">Rp {(property.price / 1000000000).toFixed(1)}B</span>
                        <div className="flex gap-1">
                          {property.features?.slice(0, 2).map((feature, idx) => (
                            <span key={idx} className="px-2 py-1 rounded-full bg-[#0D00FF]/20 text-[#0D00FF] text-xs">
                              {feature}
                            </span>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {/* Market Insights Panel */}
            {marketInsights.length > 0 && (
              <div className="mb-6 p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[#0D00FF]" />
                  Intelijen Pasar
                </h3>
                <div className="space-y-3">
                  {marketInsights.map((insight, index) => (
                    <motion.div
                      key={insight.area}
                      className="p-3 rounded-lg bg-gradient-to-r from-green-500/10 to-transparent border border-green-500/20"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-white font-medium text-sm">{insight.area}</span>
                        <span className="text-green-400 text-sm font-semibold">+{insight.growth}%</span>
                      </div>
                      <p className="text-gray-400 text-xs">{insight.demand} demand, {insight.infrastructure} infrastructure</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {/* Enhanced AI Features */}
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Search, title: "Pencarian Cerdas", desc: "Query properti dengan bahasa natural", status: "Aktif" },
                { icon: TrendingUp, title: "Analisis Pasar", desc: "Prediksi ROI real-time", status: "Aktif" },
                { icon: MapPin, title: "Intel Lokasi", desc: "Wawasan lingkungan & tren", status: "Ditingkatkan" },
                { icon: DollarSign, title: "Optimasi Harga", desc: "Strategi harga bertenaga AI", status: "Pro" },
              ].map((feature, index) => (
                <motion.div
                  key={feature.title}
                  className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300 relative"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ y: -2 }}
                >
                  <div className="absolute top-2 right-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      feature.status === 'Aktif' ? 'bg-green-500/20 text-green-400' :
                      feature.status === 'Ditingkatkan' ? 'bg-[#0D00FF]/20 text-[#0D00FF]' :
                      'bg-purple-500/20 text-purple-400'
                    }`}>
                      {feature.status}
                    </span>
                  </div>
                  <feature.icon className="w-6 h-6 text-[#0D00FF] mb-2" />
                  <h4 className="text-white font-semibold text-sm mb-1">{feature.title}</h4>
                  <p className="text-gray-400 text-xs">{feature.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Enhanced AI Stats */}
        <motion.div
          className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          {[
            { 
              value: "98%", 
              label: "Akurasi AI", 
              desc: "Presisi pencocokan properti",
              change: "+3%",
              trend: "up"
            },
            { 
              value: "1.2s", 
              label: "Waktu Respons", 
              desc: "Kecepatan pemrosesan AI rata-rata",
              change: "-0.8s",
              trend: "down"
            },
            { 
              value: `${propertyRecommendations.length + 47}`, 
              label: "Properti Dianalisis", 
              desc: "Ukuran database real-time",
              change: "+12",
              trend: "up"
            },
            { 
              value: "24/7", 
              label: "Ketersediaan AI", 
              desc: "Selalu belajar & berkembang",
              change: "Ditingkatkan",
              trend: "stable"
            },
          ].map((stat, index) => (
            <motion.div 
              key={stat.label} 
              className="text-center p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[#0D00FF]/30 transition-all duration-300 relative"
              whileHover={{ y: -2 }}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              {/* Trend indicator */}
              <div className={`absolute top-2 right-2 text-xs font-medium ${
                stat.trend === 'up' ? 'text-green-400' :
                stat.trend === 'down' ? 'text-blue-400' :
                'text-[#0D00FF]'
              }`}>
                {stat.change}
              </div>
              
              <motion.div 
                className="text-2xl font-bold text-[#0D00FF] mb-1"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 1, delay: index * 0.2 }}
              >
                {stat.value}
              </motion.div>
              <div className="text-white font-medium text-sm mb-1">{stat.label}</div>
              <div className="text-gray-400 text-xs">{stat.desc}</div>
              
              {/* Status indicator */}
              <div className="mt-2 flex justify-center">
                <div className={`w-2 h-2 rounded-full ${
                  stat.trend === 'up' ? 'bg-green-400 animate-pulse' :
                  stat.trend === 'down' ? 'bg-blue-400 animate-pulse' :
                  'bg-[#0D00FF] animate-pulse'
                }`} />
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          className="mt-8 flex flex-wrap justify-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          {[
            "Cari properti mewah di BSD",
            "Analisis ROI untuk Alam Sutera", 
            "Peluang investasi Jakarta",
            "Tren pasar Tangerang Selatan"
          ].map((suggestion, index) => (
            <motion.button
              key={suggestion}
              onClick={() => setUserInput(suggestion)}
              className="px-4 py-2 rounded-full bg-white/5 border border-white/10 hover:border-[#0D00FF]/50 text-gray-300 hover:text-white text-sm transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              {suggestion}
            </motion.button>
          ))}
        </motion.div>
      </div>
    </section>
  );
}