import React from "react";
import { motion } from "motion/react";
import { ArrowRight, Sparkles, Zap, Globe } from "lucide-react";

export default function CTASection() {
  return (
    <section className="py-20 px-6 relative">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0B0C10] via-[#0D00FF]/10 to-[#0B0C10]" />
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#0D00FF]/15 rounded-full blur-3xl animate-pulse" />
      
      {/* Floating Particles */}
      <div className="absolute top-20 left-20 w-4 h-4 rounded-full bg-[#0D00FF]/40 animate-bounce" />
      <div className="absolute top-32 right-32 w-3 h-3 rounded-full bg-[#0D00FF]/50 animate-pulse" />
      <div className="absolute bottom-20 left-32 w-2 h-2 rounded-full bg-[#0D00FF]/60 animate-ping" />
      <div className="absolute bottom-32 right-20 w-5 h-5 rounded-full bg-[#0D00FF]/30 animate-bounce delay-1000" />

      <div className="max-w-5xl mx-auto relative z-10">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {/* Main CTA Content */}
          <motion.div
            className="relative p-12 rounded-3xl bg-white/5 backdrop-blur-md border border-[#0D00FF]/30 overflow-hidden group"
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.3 }}
          >
            {/* Animated Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#0D00FF]/10 to-transparent group-hover:from-[#0D00FF]/20 transition-all duration-500" />
            
            {/* Neon Glow Effect */}
            <div className="absolute inset-0 rounded-3xl shadow-[0_0_80px_rgba(13,0,255,0.3)] group-hover:shadow-[0_0_100px_rgba(13,0,255,0.5)] transition-all duration-500" />

            {/* Corner Accent Lights */}
            <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-[#0D00FF]/20 to-transparent rounded-tl-3xl" />
            <div className="absolute bottom-0 right-0 w-24 h-24 bg-gradient-to-tl from-[#0D00FF]/15 to-transparent rounded-br-3xl" />

            {/* Floating Icons */}
            <motion.div
              className="absolute top-8 left-8"
              animate={{
                rotate: 360,
                scale: [1, 1.2, 1],
              }}
              transition={{
                rotate: { duration: 20, repeat: Infinity, ease: "linear" },
                scale: { duration: 4, repeat: Infinity, ease: "easeInOut" },
              }}
            >
              <Sparkles className="w-6 h-6 text-[#0D00FF]/60" />
            </motion.div>

            <motion.div
              className="absolute top-8 right-8"
              animate={{
                y: [-10, 10, -10],
                rotate: [0, 180, 360],
              }}
              transition={{
                y: { duration: 3, repeat: Infinity, ease: "easeInOut" },
                rotate: { duration: 5, repeat: Infinity, ease: "linear" },
              }}
            >
              <Zap className="w-6 h-6 text-[#0D00FF]/60" />
            </motion.div>

            <motion.div
              className="absolute bottom-8 left-8"
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.6, 1, 0.6],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <Globe className="w-6 h-6 text-[#0D00FF]/60" />
            </motion.div>

            <div className="relative z-10">
              {/* Badge */}
              <motion.div
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#0D00FF]/20 border border-[#0D00FF]/50 mb-6"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <motion.div
                  className="w-2 h-2 rounded-full bg-[#0D00FF]"
                  animate={{ scale: [1, 1.5, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                <span className="text-[#0D00FF] text-sm font-semibold">
                  Platform Terdepan
                </span>
              </motion.div>

              {/* Main Heading */}
              <motion.h2
                className="mb-6 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent"
                style={{ fontSize: "3.5rem", fontWeight: "bold", lineHeight: "1.1" }}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.3 }}
              >
                Jelajahi Masa Depan
                <br />
                <span className="text-[#0D00FF]">Properti Sekarang</span>
              </motion.h2>

              {/* Subheading */}
              <motion.p
                className="mb-8 text-gray-300 max-w-3xl mx-auto leading-relaxed"
                style={{ fontSize: "1.3rem" }}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                Bergabunglah dengan revolusi properti digital. Rasakan pengalaman AR immersive, 
                analisis AI yang cerdas, dan transparansi blockchain dalam satu platform eksklusif.
              </motion.p>

              {/* Feature Highlights */}
              <motion.div
                className="flex flex-wrap justify-center gap-6 mb-10"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.5 }}
              >
                {[
                  "🤖 AI Navigator ARSAN",
                  "🥽 AR Property Tours",
                  "🔗 Blockchain Ledger",
                  "📊 ROI Analytics"
                ].map((feature, index) => (
                  <motion.div
                    key={feature}
                    className="px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:border-[#0D00FF]/50 transition-all duration-300"
                    whileHover={{ scale: 1.05, y: -2 }}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                  >
                    <span className="text-gray-200 text-sm">{feature}</span>
                  </motion.div>
                ))}
              </motion.div>

              {/* Main CTA Button */}
              <motion.div
                className="flex flex-col sm:flex-row gap-4 justify-center"
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.7 }}
              >
                <motion.button
                  className="relative px-8 py-4 rounded-2xl bg-gradient-to-r from-[#0D00FF] to-blue-500 hover:from-[#0D00FF]/90 hover:to-blue-400 transition-all duration-300 group overflow-hidden"
                  style={{ fontSize: "1.1rem", fontWeight: "600" }}
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {/* Button Glow */}
                  <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  {/* Button Shadow */}
                  <div className="absolute inset-0 rounded-2xl shadow-[0_0_40px_rgba(13,0,255,0.6)] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  <span className="relative z-10 flex items-center gap-3 text-white">
                    Mulai Eksplorasi Gratis
                    <motion.div
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      <ArrowRight className="w-5 h-5" />
                    </motion.div>
                  </span>

                  {/* Animated Border */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl border-2 border-white/30 opacity-0 group-hover:opacity-100"
                    animate={{
                      borderColor: [
                        "rgba(255,255,255,0.3)",
                        "rgba(13,0,255,0.8)",
                        "rgba(255,255,255,0.3)",
                      ],
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                </motion.button>

                <motion.button
                  className="relative px-8 py-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 hover:border-[#0D00FF]/50 hover:bg-white/15 transition-all duration-300 group"
                  style={{ fontSize: "1.1rem", fontWeight: "600" }}
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className="text-white group-hover:text-[#0D00FF] transition-colors duration-300">
                    Pelajari Lebih Lanjut
                  </span>
                </motion.button>
              </motion.div>

              {/* Trust Indicators */}
              <motion.div
                className="flex flex-wrap justify-center items-center gap-8 mt-12 pt-8 border-t border-white/10"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.9 }}
              >
                <div className="text-center">
                  <p className="text-[#0D00FF] text-2xl font-bold">50K+</p>
                  <p className="text-gray-400 text-sm">Properti Listed</p>
                </div>
                <div className="text-center">
                  <p className="text-[#0D00FF] text-2xl font-bold">25K+</p>
                  <p className="text-gray-400 text-sm">Happy Clients</p>
                </div>
                <div className="text-center">
                  <p className="text-[#0D00FF] text-2xl font-bold">1M+</p>
                  <p className="text-gray-400 text-sm">AR Experiences</p>
                </div>
                <div className="text-center">
                  <p className="text-[#0D00FF] text-2xl font-bold">99.9%</p>
                  <p className="text-gray-400 text-sm">Uptime</p>
                </div>
              </motion.div>
            </div>

            {/* Animated Particles Inside Card */}
            <motion.div
              className="absolute top-1/4 left-1/4 w-2 h-2 rounded-full bg-[#0D00FF]/60"
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.6, 1, 0.6],
              }}
              transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
            />
            
            <motion.div
              className="absolute top-3/4 right-1/4 w-3 h-3 rounded-full bg-[#0D00FF]/40"
              animate={{
                y: [-10, 10, -10],
                opacity: [0.4, 0.8, 0.4],
              }}
              transition={{ duration: 4, repeat: Infinity, delay: 1 }}
            />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}