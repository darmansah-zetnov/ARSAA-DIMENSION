import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Bot, Send, User, Mic, Image, MapPin, TrendingUp, Home, DollarSign } from "lucide-react";

const SAMPLE_MESSAGES = [
  {
    type: "ai" as const,
    message: "Halo! Saya ARSAA, asisten properti AI Anda. Saya dapat membantu Anda mencari properti, menganalisis pasar, dan memberikan rekomendasi investasi. Ada yang bisa saya bantu hari ini?",
    timestamp: new Date()
  }
];

const QUICK_QUESTIONS = [
  { icon: Home, text: "Cari rumah di Jakarta Selatan", query: "Saya mencari rumah di Jakarta Selatan dengan budget 2-3 miliar" },
  { icon: TrendingUp, text: "Analisis pasar properti", query: "Bagaimana tren harga properti di Tangerang Selatan tahun ini?" },
  { icon: DollarSign, text: "Rekomendasi investasi", query: "Properti mana yang bagus untuk investasi jangka panjang?" },
  { icon: MapPin, text: "Area strategis", query: "Rekomendasikan area dengan potensi kenaikan harga tertinggi" }
];

interface Message {
  type: "user" | "ai";
  message: string;
  timestamp: Date;
  isLoading?: boolean;
}

export default function AIChatInterface() {
  const [messages, setMessages] = useState<Message[]>(SAMPLE_MESSAGES);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const simulateAIResponse = (userMessage: string) => {
    setIsTyping(true);
    
    // Simulate AI thinking time
    setTimeout(() => {
      setIsTyping(false);
      
      // Generate contextual AI responses based on keywords
      let aiResponse = "";
      const lowerMessage = userMessage.toLowerCase();
      
      if (lowerMessage.includes("rumah") || lowerMessage.includes("house")) {
        aiResponse = "Berdasarkan pencarian Anda, saya menemukan beberapa rumah yang sesuai. Di Jakarta Selatan, ada beberapa pilihan menarik di area Pondok Indah dan Kemang dengan harga 2-3 miliar. Apakah Anda ingin saya tampilkan detail properti atau analisis lebih lanjut tentang area tersebut?";
      } else if (lowerMessage.includes("harga") || lowerMessage.includes("tren") || lowerMessage.includes("pasar")) {
        aiResponse = "Analisis pasar terbaru menunjukkan bahwa harga properti di Tangerang Selatan mengalami kenaikan 8-12% year-over-year. Area seperti BSD, Gading Serpong, dan Alam Sutera menunjukkan pertumbuhan yang stabil. Mau saya berikan analisis lebih detail untuk area spesifik?";
      } else if (lowerMessage.includes("investasi") || lowerMessage.includes("ROI")) {
        aiResponse = "Untuk investasi properti, saya merekomendasikan area dengan infrastruktur berkembang seperti dekat stasiun MRT/LRT atau kawasan yang akan ada pengembangan mall/perkantoran. Berdasarkan data, properti di sekitar stasiun transit memiliki potensi capital gain 15-20% dalam 3-5 tahun. Ingin tahu area spesifik?";
      } else if (lowerMessage.includes("area") || lowerMessage.includes("lokasi") || lowerMessage.includes("daerah")) {
        aiResponse = "Area dengan potensi tertinggi saat ini adalah: 1) Sekitar stasiun MRT fase 2, 2) Kawasan TOD (Transit Oriented Development), 3) Area dengan pembangunan infrastruktur baru. Khusus untuk Jabodetabek, saya rekomendasikan Tangerang Selatan, Jakarta Selatan, dan sebagian Bekasi. Mau analisis detail area mana?";
      } else {
        aiResponse = "Terima kasih atas pertanyaan Anda! Sebagai AI properti, saya dapat membantu dengan berbagai hal seperti pencarian properti, analisis pasar, rekomendasi investasi, dan evaluasi lokasi. Bisa Anda spesifikkan lebih detail apa yang ingin Anda ketahui tentang properti?";
      }
      
      setMessages(prev => [...prev, {
        type: "ai",
        message: aiResponse,
        timestamp: new Date()
      }]);
    }, 1500 + Math.random() * 1000);
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    // Add user message
    const userMessage: Message = {
      type: "user",
      message: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    
    // Simulate AI response
    simulateAIResponse(inputMessage);
  };

  const handleQuickQuestion = (query: string) => {
    setInputMessage(query);
    setTimeout(() => {
      handleSendMessage();
    }, 100);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('id-ID', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <section className="py-20 px-6 min-h-screen">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent">
            Chat dengan ARSAA AI
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Konsultasi properti langsung dengan AI canggih. Dapatkan rekomendasi, analisis pasar, dan wawasan investasi secara real-time.
          </p>
        </motion.div>

        {/* Chat Container */}
        <motion.div
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {/* Chat Header */}
          <div className="p-6 border-b border-white/10 bg-gradient-to-r from-[#0D00FF]/10 to-transparent">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#0D00FF] to-blue-400 flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-white font-semibold">ARSAA AI Assistant</h3>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-gray-400 text-sm">Online - Siap membantu</span>
                </div>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="h-96 overflow-y-auto p-6 space-y-4">
            <AnimatePresence>
              {messages.map((msg, index) => (
                <motion.div
                  key={index}
                  className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <div className={`max-w-[80%] flex items-start gap-3 ${msg.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    {/* Avatar */}
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      msg.type === 'user' 
                        ? 'bg-gray-600' 
                        : 'bg-gradient-to-br from-[#0D00FF] to-blue-400'
                    }`}>
                      {msg.type === 'user' ? 
                        <User className="w-4 h-4 text-white" /> : 
                        <Bot className="w-4 h-4 text-white" />
                      }
                    </div>

                    {/* Message Bubble */}
                    <div className={`rounded-2xl px-4 py-3 ${
                      msg.type === 'user'
                        ? 'bg-[#0D00FF] text-white'
                        : 'bg-white/10 text-white border border-white/20'
                    }`}>
                      <p className="leading-relaxed">{msg.message}</p>
                      <div className={`text-xs mt-2 ${
                        msg.type === 'user' ? 'text-blue-100' : 'text-gray-400'
                      }`}>
                        {formatTime(msg.timestamp)}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Typing Indicator */}
            {isTyping && (
              <motion.div
                className="flex justify-start"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#0D00FF] to-blue-400 flex items-center justify-center">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-white/10 rounded-2xl px-4 py-3 border border-white/20">
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-[#0D00FF] rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-[#0D00FF] rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                      <div className="w-2 h-2 bg-[#0D00FF] rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Questions */}
          <div className="px-6 py-4 border-t border-white/10">
            <p className="text-gray-400 text-sm mb-3">Pertanyaan populer:</p>
            <div className="flex flex-wrap gap-2">
              {QUICK_QUESTIONS.map((question, index) => (
                <motion.button
                  key={index}
                  onClick={() => handleQuickQuestion(question.query)}
                  className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#0D00FF]/50 text-sm text-gray-300 hover:text-white transition-all duration-300"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <question.icon className="w-4 h-4" />
                  {question.text}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Input */}
          <div className="p-6 border-t border-white/10">
            <div className="flex items-center gap-4">
              <div className="flex-1 relative">
                <input
                  ref={inputRef}
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Tanyakan tentang properti, investasi, atau analisis pasar..."
                  className="w-full px-4 py-3 rounded-full bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:border-[#0D00FF] transition-colors duration-300"
                />
              </div>
              
              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <motion.button
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-gray-400 hover:text-white transition-all duration-300"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Mic className="w-5 h-5" />
                </motion.button>
                
                <motion.button
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-gray-400 hover:text-white transition-all duration-300"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Image className="w-5 h-5" />
                </motion.button>
                
                <motion.button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || isTyping}
                  className="w-10 h-10 rounded-full bg-gradient-to-r from-[#0D00FF] to-blue-500 hover:from-blue-500 hover:to-[#0D00FF] flex items-center justify-center text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Send className="w-5 h-5" />
                </motion.button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}