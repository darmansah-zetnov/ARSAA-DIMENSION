import React from "react";
import { motion } from "motion/react";
import { Bot, Mail, Phone, MapPin, MessageSquare, Github, Linkedin, Twitter } from "lucide-react";
import ARSAALogo from "./ARSAALogo";

export default function AIFooter() {
  return (
    <footer className="py-16 px-6 relative border-t border-white/10">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0D00FF]/5 to-transparent" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand & AI Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="md:col-span-1"
          >
            <div className="mb-6">
              <ARSAALogo size="md" variant="glow" showText={true} />
            </div>
            <p className="text-gray-400 leading-relaxed mb-6">
              AI Asisten Properti terdepan di Indonesia. Memberikan analisis cerdas, 
              rekomendasi personal, dan insight pasar untuk keputusan investasi yang tepat.
            </p>
            
            {/* AI Status */}
            <div className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0D00FF] to-blue-400 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-white font-medium">ARSAA AI Online</span>
                </div>
                <p className="text-gray-400 text-sm">Siap membantu 24/7</p>
              </div>
            </div>
          </motion.div>

          {/* AI Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h3 className="text-white font-semibold mb-6">Fitur AI</h3>
            <div className="space-y-3">
              {[
                "Smart Property Search",
                "Market Analysis AI",
                "Investment Predictions",
                "Location Recommendations",
                "24/7 AI Consultation",
                "Document Verification"
              ].map((feature) => (
                <div key={feature} className="flex items-center gap-3 text-gray-400 hover:text-[#0D00FF] transition-colors duration-300 cursor-pointer">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#0D00FF]" />
                  {feature}
                </div>
              ))}
            </div>
          </motion.div>

          {/* Contact & Support */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-white font-semibold mb-6">Kontak & Dukungan</h3>
            <div className="space-y-4 mb-6">
              <div className="flex items-center gap-3 text-gray-400">
                <Mail className="w-4 h-4" />
                <span className="text-sm">jamaludindarmansah.work@gmail.com</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <Phone className="w-4 h-4" />
                <span className="text-sm">+62 83866672100</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">Jakarta, Indonesia</span>
              </div>
            </div>

            {/* Quick Chat Button */}
            <motion.a
              href="#chat"
              className="flex items-center gap-3 px-4 py-3 rounded-xl bg-gradient-to-r from-[#0D00FF] to-blue-500 text-white hover:from-blue-500 hover:to-[#0D00FF] transition-all duration-300"
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
            >
              <MessageSquare className="w-4 h-4" />
              Chat dengan AI
            </motion.a>
          </motion.div>
        </div>

        {/* Bottom Section */}
        <motion.div
          className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <div className="text-gray-400 text-sm">
            © 2024 ARSAA AI. Powered by Advanced Machine Learning Technology.
          </div>
          
          <div className="flex items-center gap-4">
            {[
              { icon: Twitter, href: "#", label: "Twitter" },
              { icon: Linkedin, href: "#", label: "LinkedIn" },
              { icon: Github, href: "#", label: "GitHub" },
            ].map(({ icon: Icon, href, label }, index) => (
              <motion.a
                key={label}
                href={href}
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-[#0D00FF]/20 flex items-center justify-center transition-all duration-300 group"
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.9 }}
                title={label}
              >
                <Icon className="w-4 h-4 text-gray-400 group-hover:text-[#0D00FF] transition-colors duration-300" />
              </motion.a>
            ))}
          </div>
        </motion.div>

        {/* AI Disclaimer */}
        <motion.div
          className="mt-8 p-4 rounded-xl bg-white/5 border border-white/10"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <p className="text-gray-400 text-sm text-center">
            <Bot className="w-4 h-4 inline mr-2" />
            ARSAA AI menggunakan teknologi machine learning terdepan. 
            Semua analisis dan rekomendasi berdasarkan data real-time dan algoritma pembelajaran mendalam.
          </p>
        </motion.div>
      </div>
    </footer>
  );
}