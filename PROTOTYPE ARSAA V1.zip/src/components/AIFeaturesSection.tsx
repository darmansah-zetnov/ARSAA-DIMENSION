import React from "react";
import { motion } from "motion/react";
import { 
  Brain, 
  TrendingUp, 
  MapPin, 
  Search, 
  BarChart3, 
  Home, 
  DollarSign, 
  Zap,
  MessageSquare,
  Eye,
  Shield,
  Clock
} from "lucide-react";

const AI_FEATURES = [
  {
    icon: Brain,
    title: "AI Pencarian Cerdas",
    description: "Temukan properti yang tepat dengan algoritma AI yang memahami preferensi dan kebutuhan Anda secara detail.",
    color: "from-[#0D00FF] to-blue-400",
    stats: "99% Akurasi"
  },
  {
    icon: TrendingUp,
    title: "Analisis Pasar Real-time",
    description: "Data harga properti terupdate setiap hari dengan prediksi tren masa depan menggunakan machine learning.",
    color: "from-purple-500 to-pink-400",
    stats: "Data Realtime"
  },
  {
    icon: MapPin,
    title: "Rekomendasi Lokasi",
    description: "AI menganalisis faktor infrastruktur, aksesibilitas, dan potensi pertumbuhan untuk memberikan rekomendasi lokasi terbaik.",
    color: "from-green-500 to-emerald-400",
    stats: "50+ Parameter"
  },
  {
    icon: BarChart3,
    title: "Prediksi Investasi",
    description: "Analisis ROI dan capital gain dengan akurasi tinggi berdasarkan historical data dan tren pasar.",
    color: "from-orange-500 to-red-400",
    stats: "95% Akurat"
  },
  {
    icon: MessageSquare,
    title: "Konsultasi 24/7",
    description: "Chat dengan AI kapan saja untuk mendapatkan advice properti, evaluasi investasi, dan market insight.",
    color: "from-cyan-500 to-blue-500",
    stats: "24/7 Online"
  },
  {
    icon: Shield,
    title: "Verifikasi Otomatis",
    description: "AI memverifikasi legalitas properti, kredibilitas developer, dan kelengkapan dokumen secara otomatis.",
    color: "from-violet-500 to-purple-500",
    stats: "100% Aman"
  }
];

const AI_CAPABILITIES = [
  {
    icon: Search,
    title: "Smart Search",
    description: "Pencarian menggunakan bahasa natural"
  },
  {
    icon: Eye,
    title: "Computer Vision",
    description: "Analisis foto properti otomatis"
  },
  {
    icon: Clock,
    title: "Real-time Processing",
    description: "Respons instant dalam milliseconds"
  },
  {
    icon: Zap,
    title: "Auto-Learning",
    description: "Semakin pintar dari setiap interaksi"
  }
];

export default function AIFeaturesSection() {
  return (
    <section className="py-20 px-6 relative">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-full h-full opacity-5"
          style={{
            backgroundImage: `
              radial-gradient(circle at 25% 25%, #0D00FF 2px, transparent 2px),
              radial-gradient(circle at 75% 75%, #0D00FF 2px, transparent 2px)
            `,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[#0D00FF]/20 flex items-center justify-center">
              <Brain className="w-8 h-8 text-[#0D00FF]" />
            </div>
          </div>
          
          <h2 className="mb-4 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent">
            Kecerdasan AI untuk Properti
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Teknologi AI terdepan yang dirancang khusus untuk industri properti Indonesia. 
            Dapatkan insight mendalam dan keputusan investasi yang lebih cerdas.
          </p>
        </motion.div>

        {/* Main Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {AI_FEATURES.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="group"
            >
              <div className="relative p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-[#0D00FF]/50 transition-all duration-300 h-full">
                {/* Feature Icon */}
                <motion.div 
                  className={`w-14 h-14 mb-6 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center`}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                >
                  <feature.icon className="w-7 h-7 text-white" />
                </motion.div>

                {/* Stats Badge */}
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-1 rounded-full bg-[#0D00FF]/20 text-[#0D00FF] text-xs font-medium">
                    {feature.stats}
                  </span>
                </div>

                {/* Feature Content */}
                <h3 className="text-xl font-semibold text-white mb-4 group-hover:text-[#0D00FF] transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="text-gray-300 leading-relaxed">
                  {feature.description}
                </p>

                {/* Hover Effect */}
                <motion.div
                  className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#0D00FF]/5 via-transparent to-[#0D00FF]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  initial={false}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* AI Capabilities */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h3 className="text-2xl font-semibold text-center text-white mb-8">
            Kemampuan AI ARSAA
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {AI_CAPABILITIES.map((capability, index) => (
              <motion.div
                key={capability.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group"
              >
                <div className="p-6 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300 text-center">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-lg bg-[#0D00FF]/20 flex items-center justify-center group-hover:bg-[#0D00FF]/30 transition-colors duration-300">
                    <capability.icon className="w-6 h-6 text-[#0D00FF]" />
                  </div>
                  <h4 className="text-white font-semibold mb-2">{capability.title}</h4>
                  <p className="text-gray-400 text-sm">{capability.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Performance Stats */}
        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-8 p-8 rounded-2xl bg-gradient-to-r from-[#0D00FF]/10 via-purple-500/5 to-[#0D00FF]/10 border border-white/10"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {[
            { value: "99.9%", label: "Uptime AI", sublabel: "Selalu siap melayani" },
            { value: "<100ms", label: "Response Time", sublabel: "Respons super cepat" },
            { value: "50K+", label: "Properti Data", sublabel: "Database lengkap" },
            { value: "95%", label: "Akurasi Prediksi", sublabel: "Prediksi yang tepat" },
          ].map((stat, index) => (
            <motion.div 
              key={stat.label} 
              className="text-center group"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              <div className="text-3xl font-bold text-[#0D00FF] mb-1 group-hover:text-white transition-colors">
                {stat.value}
              </div>
              <div className="text-white font-medium mb-1">
                {stat.label}
              </div>
              <div className="text-gray-400 text-sm">
                {stat.sublabel}
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Section */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h3 className="text-2xl font-semibold text-white mb-4">
            Siap Mencoba AI Properti Terdepan?
          </h3>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Bergabunglah dengan ribuan investor cerdas yang sudah menggunakan ARSAA AI 
            untuk keputusan properti yang lebih menguntungkan.
          </p>
          <motion.a
            href="#chat"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-full bg-gradient-to-r from-[#0D00FF] to-blue-500 text-white hover:from-blue-500 hover:to-[#0D00FF] transition-all duration-300 shadow-lg shadow-[#0D00FF]/25"
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
          >
            <MessageSquare className="w-5 h-5" />
            Mulai Chat dengan ARSAA
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}