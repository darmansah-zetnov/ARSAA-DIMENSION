import React from "react";
import { motion } from "motion/react";
import { Bot, MessageSquare, Zap, ArrowDown } from "lucide-react";
import ARSAALogo from "./ARSAALogo";

export default function AIHeroSection() {
  return (
    <section className="min-h-screen flex items-center justify-center px-6 pt-20 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        {/* Gradient Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0B0C10] via-[#0D00FF]/5 to-[#0B0C10]" />
        
        {/* AI Particles */}
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-[#0D00FF]/30 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [-20, -40, -20],
              opacity: [0.3, 0.8, 0.3],
              scale: [1, 1.2, 1]
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
              ease: "easeInOut"
            }}
          />
        ))}

        {/* Neural Network Lines */}
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 1000 1000">
          <defs>
            <linearGradient id="neuralGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0D00FF" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#0D00FF" stopOpacity="0" />
            </linearGradient>
          </defs>
          {[...Array(15)].map((_, i) => (
            <motion.line
              key={i}
              x1={Math.random() * 1000}
              y1={Math.random() * 1000}
              x2={Math.random() * 1000}
              y2={Math.random() * 1000}
              stroke="url(#neuralGradient)"
              strokeWidth="1"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{
                duration: 2,
                delay: i * 0.1,
                repeat: Infinity,
                repeatType: "reverse"
              }}
            />
          ))}
        </svg>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto text-center">
        {/* Logo Animation */}
        <motion.div
          className="flex justify-center mb-8"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <ARSAALogo size="xl" variant="animated" showText={false} />
        </motion.div>

        {/* Main Heading */}
        <motion.h1
          className="mb-8 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent"
          style={{ fontSize: "4rem", lineHeight: "1.1", fontWeight: "800" }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
        >
          ARSAA AI
        </motion.h1>

        <motion.h2
          className="mb-8 text-white"
          style={{ fontSize: "2rem", fontWeight: "600" }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
        >
          Asisten Properti Cerdas Indonesia
        </motion.h2>

        {/* Description */}
        <motion.p
          className="text-gray-300 max-w-3xl mx-auto mb-12 leading-relaxed"
          style={{ fontSize: "1.25rem" }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.7 }}
        >
          AI canggih yang membantu Anda menemukan, menganalisis, dan berinvestasi di properti terbaik. 
          Dapatkan rekomendasi personal, analisis pasar real-time, dan wawasan investasi yang akurat.
        </motion.p>

        {/* AI Capabilities */}
        <motion.div
          className="flex flex-wrap justify-center gap-6 mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.9 }}
        >
          {[
            { icon: Bot, text: "AI Chat 24/7" },
            { icon: MessageSquare, text: "Konsultasi Real-time" },
            { icon: Zap, text: "Analisis Instant" }
          ].map((item, index) => (
            <motion.div
              key={index}
              className="flex items-center gap-3 px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20"
              whileHover={{ scale: 1.05, backgroundColor: "rgba(13, 0, 255, 0.1)" }}
              transition={{ duration: 0.3 }}
            >
              <item.icon className="w-5 h-5 text-[#0D00FF]" />
              <span className="text-white">{item.text}</span>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Button */}
        <motion.div
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.1 }}
        >
          <motion.a
            href="#chat"
            className="px-8 py-4 rounded-full bg-gradient-to-r from-[#0D00FF] to-blue-500 text-white flex items-center gap-3 hover:from-blue-500 hover:to-[#0D00FF] transition-all duration-300 shadow-lg shadow-[#0D00FF]/25"
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            style={{ fontSize: "1.1rem", fontWeight: "600" }}
          >
            <Bot className="w-5 h-5" />
            Mulai Chat dengan ARSAA
          </motion.a>

          <motion.button
            className="px-8 py-4 rounded-full border border-white/30 text-white hover:bg-white/10 transition-all duration-300"
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            style={{ fontSize: "1.1rem" }}
          >
            Pelajari Fitur AI
          </motion.button>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.5 }}
        >
          <motion.div
            className="flex flex-col items-center gap-2 text-gray-400"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <span className="text-sm">Scroll untuk chat</span>
            <ArrowDown className="w-5 h-5" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}