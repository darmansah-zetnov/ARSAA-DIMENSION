import React from "react";
import { motion } from "motion/react";
import { Bot, Eye, Shield, Target, MessageCircle } from "lucide-react";

const FEATURES = [
  {
    title: "ARSAN - AI Navigator",
    subtitle: "AI Advisor dengan NLU",
    description: "Asisten AI cerdas yang memahami kebutuhan properti Anda dengan Natural Language Understanding. Rekomendasi personal dan analisis mendalam.",
    icon: Bot,
    gradient: "from-[#0D00FF] to-blue-400",
    delay: 0.1,
  },
  {
    title: "AR Showcase",
    subtitle: "WebXR Experience",
    description: "Jelajahi properti dalam realitas augmented langsung di browser tanpa aplikasi tambahan. Teknologi WebXR terdepan untuk pengalaman immersive.",
    icon: Eye,
    gradient: "from-[#0D00FF] to-cyan-400",
    delay: 0.2,
  },
  {
    title: "Web3 Ledger",
    subtitle: "Blockchain Transparency",
    description: "Sistem pencatatan properti berbasis blockchain untuk transparansi maksimal. Riwayat kepemilikan dan transaksi yang tidak dapat dimanipulasi.",
    icon: Shield,
    gradient: "from-[#0D00FF] to-purple-400",
    delay: 0.3,
  },
  {
    title: "Smart Recommendation",
    subtitle: "AI-Powered Analysis",
    description: "Analisis ROI prediktif dan rekomendasi investasi cerdas berdasarkan data real-time pasar properti dan trend masa depan.",
    icon: Target,
    gradient: "from-[#0D00FF] to-indigo-400",
    delay: 0.4,
  },
];

export default function FeaturesSection() {
  return (
    <section className="py-20 px-6 relative">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0D00FF]/5 to-transparent" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#0D00FF]/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-[#0D00FF]/8 rounded-full blur-3xl animate-pulse delay-1000" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2
            className="mb-6 bg-gradient-to-r from-white via-[#0D00FF] to-white bg-clip-text text-transparent"
            style={{ fontSize: "3rem", fontWeight: "bold" }}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.3 }}
          >
            Fitur Revolusioner
          </motion.h2>
          
          <motion.p
            className="text-gray-300 max-w-3xl mx-auto"
            style={{ fontSize: "1.2rem" }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            Teknologi masa depan yang mengubah cara Anda menjelajahi, menganalisis, dan berinvestasi dalam properti
          </motion.p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {FEATURES.map((feature, index) => (
            <motion.div
              key={feature.title}
              className="group relative"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: feature.delay }}
              whileHover={{ scale: 1.02, y: -5 }}
            >
              {/* Card Background with Glassmorphism */}
              <div className="relative p-8 rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 group-hover:border-[#0D00FF]/70 transition-all duration-500 overflow-hidden">
                
                {/* Neon Glow Border */}
                <div className="absolute inset-0 rounded-3xl ring-1 ring-transparent group-hover:ring-[#0D00FF]/50 transition-all duration-500" />
                
                {/* Card Glow Effect */}
                <div className="absolute inset-0 rounded-3xl shadow-[0_0_40px_rgba(13,0,255,0.1)] group-hover:shadow-[0_0_40px_rgba(13,0,255,0.3)] transition-all duration-500" />

                {/* Animated Background Particles */}
                <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-[#0D00FF]/40 animate-pulse" />
                <div className="absolute bottom-6 left-6 w-1 h-1 rounded-full bg-[#0D00FF]/60 animate-ping" />

                {/* Icon Container */}
                <motion.div
                  className="relative mb-6"
                  whileHover={{ 
                    rotateY: 360,
                    scale: 1.1,
                  }}
                  transition={{ duration: 0.8, ease: "easeInOut" }}
                >
                  <div className={`relative w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.gradient} p-4 group-hover:shadow-[0_0_30px_rgba(13,0,255,0.5)] transition-all duration-500`}>
                    {/* Icon Glow */}
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    
                    <feature.icon 
                      className="w-full h-full text-white relative z-10"
                      strokeWidth={2}
                    />

                    {/* Rotating Ring */}
                    <motion.div
                      className="absolute inset-0 border-2 border-[#0D00FF]/30 rounded-2xl"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    />
                  </div>

                  {/* Floating Elements */}
                  <motion.div
                    className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-[#0D00FF]/20 blur-sm"
                    animate={{
                      scale: [1, 1.2, 1],
                      opacity: [0.2, 0.6, 0.2],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: index * 0.5,
                    }}
                  />
                </motion.div>

                {/* Content */}
                <div className="relative z-10">
                  <motion.h3
                    className="mb-2 bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent group-hover:from-[#0D00FF] group-hover:to-white transition-all duration-500"
                    style={{ fontSize: "1.5rem", fontWeight: "600" }}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: feature.delay + 0.2 }}
                  >
                    {feature.title}
                  </motion.h3>

                  <motion.p
                    className="mb-4 text-[#0D00FF] group-hover:text-[#0D00FF]/80"
                    style={{ fontSize: "0.9rem", fontWeight: "500" }}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: feature.delay + 0.3 }}
                  >
                    {feature.subtitle}
                  </motion.p>

                  <motion.p
                    className="text-gray-300 group-hover:text-white transition-colors duration-300 leading-relaxed"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: feature.delay + 0.4 }}
                  >
                    {feature.description}
                  </motion.p>
                </div>

                {/* Interactive Hover Elements */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-[#0D00FF]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl"
                  initial={false}
                />

                {/* Corner Accents */}
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-[#0D00FF]/10 to-transparent rounded-tr-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute bottom-0 left-0 w-16 h-16 bg-gradient-to-tr from-[#0D00FF]/10 to-transparent rounded-bl-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Live Chat Feature - Special Treatment */}
        <motion.div
          className="mt-12 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <div className="inline-flex items-center gap-4 p-6 rounded-2xl bg-white/5 backdrop-blur-md border border-[#0D00FF]/30 hover:border-[#0D00FF]/70 transition-all duration-300 group cursor-pointer">
            <motion.div
              className="w-12 h-12 rounded-full bg-[#0D00FF]/20 flex items-center justify-center"
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              <MessageCircle className="w-6 h-6 text-[#0D00FF]" />
            </motion.div>
            
            <div className="text-left">
              <h4 className="text-white group-hover:text-[#0D00FF] transition-colors duration-300" style={{ fontSize: "1.1rem", fontWeight: "600" }}>
                Live Chat Terenkripsi
              </h4>
              <p className="text-gray-400 text-sm">
                Komunikasi aman antara pembeli, penjual, dan agen
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}