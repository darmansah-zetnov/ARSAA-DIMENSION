import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Menu, X, Home, Search, User, Settings, ChevronDown } from "lucide-react";

const NAV_ITEMS = [
  { name: "Home", icon: Home, href: "#home" },
  { name: "Explore AR", icon: Search, href: "#explore" },
  { name: "AI Navigator", icon: User, href: "#ai" },
  { name: "Web3 Ledger", icon: Settings, href: "#web3" },
];

export default function Enhanced3DNavigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [activeSection, setActiveSection] = useState("home");
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Mobile detection and performance optimization
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener("resize", checkMobile);

    const handleScroll = () => {
      // Throttle scroll updates for better mobile performance
      if (!isMobile || Date.now() % 3 === 0) {
        setScrollY(window.scrollY);
      }
    };
    
    window.addEventListener("scroll", handleScroll, { passive: true });
    
    return () => {
      window.removeEventListener("resize", checkMobile);
      window.removeEventListener("scroll", handleScroll);
    };
  }, [isMobile]);

  return (
    <>
      {/* Main Navigation */}
      <motion.nav
        className="fixed top-0 left-0 right-0 z-50 px-6 py-4"
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        <div className="max-w-7xl mx-auto">
          <motion.div
            className="relative rounded-2xl bg-black/20 backdrop-blur-xl border border-[#0D00FF]/30 px-6 py-4 overflow-hidden"
            style={{
              transform: `translateY(${scrollY * 0.1}px)`,
            }}
            whileHover={{ 
              boxShadow: "0 0 40px rgba(13, 0, 255, 0.3)",
              borderColor: "rgba(13, 0, 255, 0.5)"
            }}
          >
            {/* Animated background */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#0D00FF]/5 via-transparent to-[#0D00FF]/5" />
            
            {/* Navigation content */}
            <div className="relative z-10 flex items-center justify-between">
              {/* Logo */}
              <motion.div
                className="flex items-center gap-3"
                whileHover={{ scale: 1.05 }}
              >
                <motion.div
                  className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#0D00FF] to-blue-400 flex items-center justify-center relative overflow-hidden"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent" />
                  <span className="text-white font-bold text-lg relative z-10">A</span>
                </motion.div>
                
                <motion.h1
                  className="text-lg sm:text-xl font-bold bg-gradient-to-r from-white to-[#0D00FF] bg-clip-text text-transparent tracking-wider"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                >
                  <span className="hidden sm:inline">ARSAA DIMENSION</span>
                  <span className="sm:hidden">ARSAA</span>
                </motion.h1>
              </motion.div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center gap-8">
                {NAV_ITEMS.map((item, index) => (
                  <motion.a
                    key={item.name}
                    href={item.href}
                    className="relative group"
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    whileHover={{ scale: 1.05, y: -2 }}
                  >
                    <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 hover:bg-[#0D00FF]/20 border border-transparent hover:border-[#0D00FF]/50 transition-all duration-300 group">
                      <item.icon className="w-4 h-4 text-gray-400 group-hover:text-[#0D00FF] transition-colors duration-300" />
                      <span className="text-gray-300 group-hover:text-white transition-colors duration-300 text-sm font-medium">
                        {item.name}
                      </span>
                    </div>
                    
                    {/* Hover glow effect */}
                    <div className="absolute inset-0 rounded-xl bg-[#0D00FF]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-sm -z-10" />
                  </motion.a>
                ))}
              </div>

              {/* Mobile menu button */}
              <motion.button
                onClick={() => setIsOpen(!isOpen)}
                className="md:hidden w-10 h-10 rounded-xl bg-white/10 hover:bg-[#0D00FF]/20 border border-white/20 hover:border-[#0D00FF]/50 flex items-center justify-center transition-all duration-300"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  animate={{ rotate: isOpen ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  {isOpen ? (
                    <X className="w-5 h-5 text-[#0D00FF]" />
                  ) : (
                    <Menu className="w-5 h-5 text-gray-400" />
                  )}
                </motion.div>
              </motion.button>
            </div>

            {/* Animated border */}
            <motion.div
              className="absolute inset-0 rounded-2xl"
              style={{
                background: `conic-gradient(from 0deg, transparent, rgba(13, 0, 255, 0.3), transparent)`,
                padding: "1px",
              }}
              animate={{ rotate: 360 }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            />
          </motion.div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <motion.div
        className="fixed inset-0 z-40 md:hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: isOpen ? 1 : 0 }}
        transition={{ duration: 0.3 }}
        style={{ pointerEvents: isOpen ? "auto" : "none" }}
      >
        {/* Backdrop */}
        <motion.div
          className="absolute inset-0 bg-black/50 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: isOpen ? 1 : 0 }}
          onClick={() => setIsOpen(false)}
        />

        {/* Menu content */}
        <motion.div
          className="absolute top-20 left-6 right-6 rounded-2xl bg-black/80 backdrop-blur-xl border border-[#0D00FF]/30 overflow-hidden"
          initial={{ y: -20, opacity: 0, scale: 0.95 }}
          animate={{ 
            y: isOpen ? 0 : -20, 
            opacity: isOpen ? 1 : 0, 
            scale: isOpen ? 1 : 0.95 
          }}
          transition={{ duration: 0.3 }}
        >
          <div className="p-6 space-y-4">
            {NAV_ITEMS.map((item, index) => (
              <motion.a
                key={item.name}
                href={item.href}
                className="flex items-center gap-4 p-4 rounded-xl bg-white/5 hover:bg-[#0D00FF]/20 border border-transparent hover:border-[#0D00FF]/50 transition-all duration-300 group"
                onClick={() => setIsOpen(false)}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: isOpen ? 1 : 0, x: isOpen ? 0 : -20 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                whileHover={{ scale: 1.02, x: 5 }}
              >
                <div className="w-12 h-12 rounded-xl bg-[#0D00FF]/20 group-hover:bg-[#0D00FF]/40 flex items-center justify-center transition-all duration-300">
                  <item.icon className="w-6 h-6 text-[#0D00FF] group-hover:text-white transition-colors duration-300" />
                </div>
                
                <div>
                  <h3 className="text-white group-hover:text-[#0D00FF] transition-colors duration-300 font-semibold">
                    {item.name}
                  </h3>
                  <p className="text-gray-400 text-sm">
                    {item.name === "Explore AR" ? "Virtual property tours" :
                     item.name === "AI Navigator" ? "Smart property assistant" :
                     item.name === "Web3 Ledger" ? "Blockchain transparency" :
                     "Welcome to the future"}
                  </p>
                </div>
              </motion.a>
            ))}
          </div>
        </motion.div>
      </motion.div>

      {/* Floating Action Button */}
      <motion.div
        className="fixed bottom-8 right-8 z-50"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, delay: 1 }}
      >
        <motion.button
          className="w-14 h-14 rounded-full bg-gradient-to-br from-[#0D00FF] to-blue-400 shadow-[0_0_30px_rgba(13,0,255,0.5)] flex items-center justify-center group relative overflow-hidden"
          whileHover={{ 
            scale: 1.1, 
            boxShadow: "0 0 40px rgba(13, 0, 255, 0.8)" 
          }}
          whileTap={{ scale: 0.9 }}
          animate={{
            y: [0, -10, 0],
          }}
          transition={{
            y: { duration: 3, repeat: Infinity, ease: "easeInOut" },
          }}
        >
          {/* Button glow */}
          <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <ChevronDown className="w-6 h-6 text-white transform rotate-180 relative z-10" />
          
          {/* Ripple effect */}
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-white/30"
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.5, 0, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeOut",
            }}
          />
        </motion.button>
      </motion.div>
    </>
  );
}