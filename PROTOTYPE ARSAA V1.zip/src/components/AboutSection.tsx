import React from "react";
import { motion } from "motion/react";
import { Target, Users, Award, Zap, Shield, Globe, TrendingUp, Brain } from "lucide-react";
import { SectionWrapper, FeatureGroup, ContentCard } from "./StructuredLayout";
import ARSAALogo from "./ARSAALogo";

const COMPANY_VALUES = [
  {
    icon: Target,
    title: "Visi Revolusioner",
    description: "Mentransformasi industri real estate Indonesia dengan teknologi AI, AR, dan blockchain terdepan.",
    color: "from-[#0D00FF] to-blue-400"
  },
  {
    icon: Users,
    title: "Customer-Centric",
    description: "Mengutamakan kepuasan pelanggan dengan solusi properti yang personal dan inovatif.",
    color: "from-purple-500 to-pink-400"
  },
  {
    icon: Award,
    title: "Standar Premium",
    description: "Menyediakan properti berkualitas tinggi dengan standar internasional untuk investasi terbaik.",
    color: "from-green-500 to-emerald-400"
  }
];

const TECHNOLOGY_PILLARS = [
  {
    icon: Brain,
    title: "Artificial Intelligence",
    description: "ARSAA AI Navigator dengan GPT-4 untuk analisis pasar dan rekomendasi cerdas",
    progress: 95
  },
  {
    icon: Shield,
    title: "Blockchain Security",
    description: "Transaksi aman dengan teknologi Web3 dan smart contracts terintegrasi",
    progress: 88
  },
  {
    icon: Globe,
    title: "Augmented Reality",
    description: "Pengalaman virtual tour dan visualisasi properti yang immersive",
    progress: 92
  },
  {
    icon: TrendingUp,
    title: "Data Analytics",
    description: "Analisis prediktif untuk investasi properti dan tren pasar masa depan",
    progress: 90
  }
];

const MILESTONES = [
  { year: "2024", event: "Peluncuran ARSAA DIMENSION", desc: "Platform AI pertama di Indonesia" },
  { year: "2024", event: "Integrasi AR Technology", desc: "Virtual tour properti dengan AR" },
  { year: "2024", event: "Blockchain Implementation", desc: "Sistem keamanan Web3 terintegrasi" },
  { year: "2024", event: "Regional Expansion", desc: "Ekspansi ke Jakarta & Tangerang Selatan" }
];

export default function AboutSection() {
  return (
    <SectionWrapper id="about" backgroundVariant="gradient" className="py-32">
      <FeatureGroup 
        title="Tentang ARSAA DIMENSION" 
        subtitle="Pelopor transformasi digital real estate Indonesia dengan teknologi revolusioner"
      >
        {/* Company Introduction */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex justify-center mb-8">
            <ARSAALogo size="xl" variant="animated" showText={true} />
          </div>
          
          <motion.p
            className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed mb-8"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            ARSAA DIMENSION adalah platform real estate revolusioner yang mengintegrasikan kecerdasan buatan (AI), 
            augmented reality (AR), dan teknologi blockchain untuk menghadirkan pengalaman properti yang belum pernah ada sebelumnya. 
            Kami berkomitmen mentransformasi cara Indonesia berinvestasi dan menjelajahi properti premium.
          </motion.p>

          <motion.div
            className="flex flex-wrap justify-center gap-4"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            {["AI-Powered", "AR-Enhanced", "Blockchain-Secured", "Indonesia-Focused"].map((tag) => (
              <span
                key={tag}
                className="px-4 py-2 rounded-full bg-[#0D00FF]/20 text-[#0D00FF] border border-[#0D00FF]/30 font-medium"
              >
                {tag}
              </span>
            ))}
          </motion.div>
        </motion.div>

        {/* Company Values */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-20">
          {COMPANY_VALUES.map((value, index) => (
            <motion.div
              key={value.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="group"
            >
              <ContentCard className="h-full text-center group-hover:border-[#0D00FF]/70" hover>
                <motion.div 
                  className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br ${value.color} flex items-center justify-center`}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                >
                  <value.icon className="w-8 h-8 text-white" />
                </motion.div>

                <h3 className="text-xl font-semibold text-white mb-4 group-hover:text-[#0D00FF] transition-colors duration-300">
                  {value.title}
                </h3>
                <p className="text-gray-300 leading-relaxed">
                  {value.description}
                </p>
              </ContentCard>
            </motion.div>
          ))}
        </div>

        {/* Technology Pillars */}
        <motion.div
          className="mb-20"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h3 className="text-2xl font-semibold text-center text-white mb-12">
            Fondasi Teknologi Kami
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {TECHNOLOGY_PILLARS.map((pillar, index) => (
              <motion.div
                key={pillar.title}
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
              >
                <ContentCard className="p-8">
                  <div className="flex items-start gap-6">
                    <div className="w-14 h-14 rounded-xl bg-[#0D00FF]/20 flex items-center justify-center flex-shrink-0">
                      <pillar.icon className="w-7 h-7 text-[#0D00FF]" />
                    </div>
                    
                    <div className="flex-1">
                      <h4 className="text-xl font-semibold text-white mb-3">{pillar.title}</h4>
                      <p className="text-gray-300 mb-4 leading-relaxed">
                        {pillar.description}
                      </p>
                      
                      {/* Progress Bar */}
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Implementation Progress</span>
                          <span className="text-[#0D00FF] font-medium">{pillar.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <motion.div
                            className="h-2 rounded-full bg-gradient-to-r from-[#0D00FF] to-blue-400"
                            initial={{ width: 0 }}
                            whileInView={{ width: `${pillar.progress}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 1, delay: 0.5 }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </ContentCard>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Timeline Milestones */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h3 className="text-2xl font-semibold text-center text-white mb-12">
            Pencapaian & Roadmap 2024
          </h3>
          
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-[#0D00FF] to-purple-500 rounded-full" />
            
            <div className="space-y-12">
              {MILESTONES.map((milestone, index) => (
                <motion.div
                  key={index}
                  className={`flex items-center gap-8 ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? 'text-right' : 'text-left'}`}>
                    <ContentCard className="p-6">
                      <div className="text-2xl font-bold text-[#0D00FF] mb-2">{milestone.year}</div>
                      <h4 className="text-lg font-semibold text-white mb-2">{milestone.event}</h4>
                      <p className="text-gray-300">{milestone.desc}</p>
                    </ContentCard>
                  </div>
                  
                  {/* Timeline Node */}
                  <div className="w-6 h-6 rounded-full bg-[#0D00FF] border-4 border-[#0B0C10] relative z-10 flex-shrink-0">
                    <div className="absolute inset-0 rounded-full bg-[#0D00FF] animate-ping opacity-75" />
                  </div>
                  
                  <div className="flex-1">
                    {index % 2 !== 0 && <div />}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </FeatureGroup>
    </SectionWrapper>
  );
}