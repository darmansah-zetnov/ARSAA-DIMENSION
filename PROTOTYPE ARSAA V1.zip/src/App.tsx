import React from "react";
import AINavigation from "./components/AINavigation";
import AIHeroSection from "./components/AIHeroSection";
import AIChatInterface from "./components/AIChatInterface";
import AIFeaturesSection from "./components/AIFeaturesSection";
import AIFooter from "./components/AIFooter";

export default function App() {
  return (
    <div className="min-h-screen bg-[#0B0C10] text-white overflow-x-hidden">
      {/* AI Navigation */}
      <AINavigation />

      {/* Main AI Content */}
      <main className="relative">
        {/* AI Hero Section */}
        <section id="home">
          <AIHeroSection />
        </section>

        {/* AI Chat Interface - Core Feature */}
        <section id="chat" className="relative">
          <AIChatInterface />
        </section>

        {/* AI Features for Real Estate */}
        <section id="features" className="relative">
          <AIFeaturesSection />
        </section>
      </main>

      {/* AI Footer */}
      <AIFooter />
    </div>
  );
}